"""Onglet « Parcourir » : trouver un produit dans le catalogue hors ligne par catégorie,
marque ou mot, sans chercher son code sur le site."""
from __future__ import annotations

import re

from PySide6.QtCore import QSize, Qt
from PySide6.QtGui import QColor, QIcon, QPixmap
from PySide6.QtWidgets import (QAbstractItemView, QComboBox, QHBoxLayout, QHeaderView, QLabel, QLineEdit,
                               QListWidget, QListWidgetItem, QMessageBox, QPushButton, QTableWidget,
                               QTableWidgetItem, QVBoxLayout, QWidget, QCheckBox, QStyledItemDelegate, QApplication)

from .. import energie
from ..paths import retrouver_photo

from ..hors_ligne import GROUPES
CATEGORIES = [("tout", "🗂️ Tout le catalogue")] + [(cle, lib) for cle, lib, _ in GROUPES]
from ..hors_ligne import SANS_AFFICHE
# rayon du site -> catégorie, déduit des mêmes GROUPES (jamais désynchronisé)
_CAT_ENERGIE = {r: cle for cle, _, rayons in GROUPES for r in rayons if r in SANS_AFFICHE}


def etiquette_seulement(a: dict) -> bool:
    """TV, électroménager, stockage… : pas d'affiche."""
    return (a.get("rayon") or "") in _CAT_ENERGIE


def categorie(a: dict) -> str:
    r = a.get("rayon") or ""
    if r in _CAT_ENERGIE:
        return _CAT_ENERGIE[r]
    recond = (a.get("attributs") or {}).get("flap_reconditionne") == "Oui" or "reconditionn" in a["nom"].lower()
    if r == "ipad_recond":
        return "ipad_recond"
    if r == "tablettes":
        return "tablettes"
    if r == "mobiles":
        return "mobiles"
    if r == "consoles":
        return "consoles"
    return "recond" if (recond or r == "smartphones_recond") else "neufs"


def _nom_court(nom: str) -> str:
    """« Smartphone SAMSUNG Galaxy A17 4G 128Go Noir » → « SAMSUNG A17 128 GO 4G » (sous l'étiquette)."""
    from ..noms import nom_court
    return nom_court(nom) or nom


def _noter_erreur(quoi: str) -> None:
    """Erreur dans un bouton : écrite dans erreurs.log et expliquée, sans fermer le logiciel."""
    import traceback
    texte = traceback.format_exc()
    try:
        from ..paths import data_dir
        with (data_dir() / "erreurs.log").open("a", encoding="utf-8") as f:
            f.write(f"--- {quoi} ---\n{texte}\n")
    except Exception:
        pass
    QMessageBox.warning(None, "Dépôt Print", f"« {quoi} » n'a pas fonctionné.\n"
                        "(détails enregistrés dans erreurs.log)")


def _mots(texte: str) -> list[str]:
    import re
    return [m for m in re.split(r"[^0-9a-zàâäéèêëîïôöùûüç+]+", texte.lower()) if m]


def correspond(a: dict, mot: str) -> bool:
    """« 13 » trouve « iPhone 13 » mais pas « 128Go » ; un code se tape en entier ou par le début ;
    « iphone13 » ou « 128go » collés marchent aussi."""
    mot = mot.lower()
    if a["code"].startswith(mot):
        return True
    mots = _mots(a["nom"] + " " + (a.get("coloris") or ""))
    if any(m.startswith(mot) for m in mots):
        return True
    return any((x + y).startswith(mot) for x, y in zip(mots, mots[1:]))


def marque(a: dict) -> str:
    m = ((a.get("attributs") or {}).get("brand") or "").strip()
    if m:
        import re
        return re.sub(r"\s+(RECOND\w*|RECONDITIONN\w*)$", "", m.upper()).strip()
    mots = [x for x in a["nom"].split() if x.isupper() and len(x) > 1]
    return mots[0] if mots else "—"


_DETAILS = Qt.ItemDataRole.UserRole + 1
_PAIRE = Qt.ItemDataRole.UserRole + 2
_RESERVE = Qt.ItemDataRole.UserRole + 3
_COUPE = re.compile(r"\s+(?=(?:-\s*)?(?:reconditionn|etat\b|état\b|grade\b|excellent\b|\+\s|avec\b|batterie\b))",
                    re.IGNORECASE)


def decouper_nom(nom: str) -> tuple[str, str]:
    """« APPLE iPhone 12 Mini 64 Go Noir reconditionné Etat correct Batterie Neuve »
    -> (« APPLE iPhone 12 Mini 64 Go Noir », « Reconditionné · État correct · Batterie neuve »)."""
    nom = " ".join((nom or "").split())
    m = _COUPE.search(nom)
    if not m:
        return nom, ""
    titre, reste = nom[:m.start()].strip(" -"), nom[m.end():].strip(" -")
    morceaux = re.split(r"(?<!excellent)\s+(?=(?:etat|état|grade|batterie|excellent)\b)|\s*\+\s*", reste,
                        flags=re.IGNORECASE)
    propre = []
    for x in morceaux:
        x = x.strip(" -")
        if x:
            x = x[0].upper() + x[1:].lower()
            propre.append(re.sub(r"^Etat\b", "État", x))
    return titre, " · ".join(propre)


class _DelegueNom(QStyledItemDelegate):
    """Nom du produit en gras, précisions en petit gris dessous, trait bleu à gauche si 2 produits
    sont sur la même affiche."""

    def paint(self, painter, option, index):
        from PySide6.QtGui import QFont
        from PySide6.QtWidgets import QStyle, QStyleOptionViewItem
        opt = QStyleOptionViewItem(option)
        self.initStyleOption(opt, index)
        titre, details = opt.text, index.data(_DETAILS) or ""
        opt.text = ""
        w = opt.widget
        (w.style() if w else QApplication.style()).drawControl(QStyle.ControlElement.CE_ItemViewItem, opt, painter, w)
        painter.save()
        r = opt.rect.adjusted(8, 0, -6 - int(index.data(_RESERVE) or 0), 0)   # place des boutons
        if index.data(_PAIRE):
            painter.fillRect(opt.rect.x(), opt.rect.y() + 4, 4, opt.rect.height() - 8, QColor("#2D8FE0"))
            r = r.adjusted(4, 0, 0, 0)
        f = QFont(opt.font)
        f.setBold(True)
        painter.setFont(f)
        fm = painter.fontMetrics()
        h1 = fm.height()
        f2 = QFont(opt.font)
        f2.setPointSizeF(max(7.0, opt.font.pointSizeF() - 1.5))
        from PySide6.QtGui import QFontMetrics
        h2 = QFontMetrics(f2).height() if details else 0
        y = r.y() + (r.height() - h1 - h2 - (2 if details else 0)) // 2
        painter.setPen(opt.palette.color(opt.palette.ColorRole.Text))
        painter.drawText(r.x(), y, r.width(), h1, int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
                         fm.elidedText(titre, Qt.TextElideMode.ElideRight, r.width()))
        if details:
            painter.setFont(f2)
            painter.setPen(QColor("#1F6FB8") if index.data(_PAIRE) else QColor("#6B7380"))
            painter.drawText(r.x(), y + h1 + 2, r.width(), h2,
                             int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter),
                             QFontMetrics(f2).elidedText(details, Qt.TextElideMode.ElideRight, r.width()))
        painter.restore()


class OngletParcourir(QWidget):
    def __init__(self, fenetre):
        super().__init__()
        self.fenetre = fenetre
        self.cat = fenetre.cat
        self.articles: list[dict] = []
        self.coches: set[str] = set()          # produits cochés (gardés quand on change de catégorie)
        self.paires: dict[str, str] = {}       # deux produits sur la même affiche (dans les deux sens)
        self._icones: dict[str, QIcon] = {}    # vignettes déjà préparées (sinon la liste rame)
        racine = QHBoxLayout(self)
        racine.setContentsMargins(22, 18, 22, 18)
        racine.setSpacing(16)

        # gauche : catégories
        g = QVBoxLayout()
        t = QLabel("Catégories")
        t.setObjectName("etiquette")
        g.addWidget(t)
        self.l_cat = QListWidget()
        self.l_cat.setObjectName("categories")
        self.l_cat.setFixedWidth(250)
        self.l_cat.setStyleSheet("QListWidget#categories { font-size: 11pt; } "
                                 "QListWidget#categories::item { padding: 9px 6px; }")
        for cle, lib in CATEGORIES:
            it = QListWidgetItem(lib)
            it.setData(Qt.ItemDataRole.UserRole, cle)
            if cle == "—":                         # titre de groupe : ni sélectionnable ni cliquable
                it.setFlags(Qt.ItemFlag.NoItemFlags)
                f = it.font()
                f.setBold(True)
                it.setFont(f)
            self.l_cat.addItem(it)
        self.l_cat.currentRowChanged.connect(lambda _: self.filtrer())
        self.l_cat.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.l_cat.customContextMenuRequested.connect(self._menu_categorie)
        g.addWidget(self.l_cat, 1)
        self.b_ajout_cat = QPushButton("➕  Ajouter une catégorie")
        self.b_ajout_cat.setObjectName("modifier")
        self.b_ajout_cat.setFixedWidth(250)
        self.b_ajout_cat.clicked.connect(self.ajouter_categorie)
        self.b_ajout_cat.setVisible(False)
        g.addWidget(self.b_ajout_cat)
        racine.addLayout(g)

        # droite : filtres + liste
        d = QVBoxLayout()
        h = QHBoxLayout()
        self.recherche = QLineEdit()
        self.recherche.setPlaceholderText("🔎 Un mot : A17, iPhone 13, 256, bleu…")
        self.recherche.setClearButtonEnabled(True)
        self.recherche.textChanged.connect(lambda _: self.filtrer())
        h.addWidget(self.recherche, 1)
        h.addWidget(QLabel("Marque"))
        self.c_marque = QComboBox()
        self.c_marque.setMinimumWidth(170)
        self.c_marque.currentIndexChanged.connect(lambda _: self.filtrer())
        h.addWidget(self.c_marque)
        self.c_retires = QCheckBox("Produits plus sur le site")
        self.c_retires.toggled.connect(lambda _: self.filtrer())
        h.addWidget(self.c_retires)
        d.addLayout(h)

        hc = QHBoxLayout()
        self.compte = QLabel("")
        self.compte.setObjectName("petit")
        hc.addWidget(self.compte)
        hc.addStretch()
        # un seul bouton : « Tout cocher » s'il n'y a rien de coché, sinon « Tout décocher »
        self.b_tout = QPushButton("☑️ Tout cocher")
        self.b_tout.setMinimumWidth(170)
        self.b_tout.clicked.connect(lambda: self.tout_decocher() if self.coches else self.tout_cocher())
        hc.addWidget(self.b_tout)
        d.addLayout(hc)
        self._barre_action()                    # (remplacée par les boutons sur les lignes cochées)

        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["✔", "", "Produit", "Code", "Couleur", "🍃"])
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(54)
        self.table.setIconSize(QSize(46, 46))
        hh = self.table.horizontalHeader()
        hh.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        for i, larg in ((0, 40), (1, 60), (3, 92), (4, 110), (5, 46)):   # largeurs fixes : liste rapide
            hh.setSectionResizeMode(i, QHeaderView.ResizeMode.Fixed)
            self.table.setColumnWidth(i, larg)
        hh.setMinimumSectionSize(40)
        # boutons des lignes cochées : posés à droite du nom, dans l'espace avant « Code »
        self._boutons_lignes: list[tuple[QWidget, int, int]] = []
        self.table.verticalScrollBar().valueChanged.connect(lambda _: self._placer_boutons())
        hh.sectionResized.connect(lambda *_: self._placer_boutons())
        self.table.viewport().installEventFilter(self)
        self.table.horizontalHeaderItem(5).setToolTip("Étiquette énergie déjà sur l'ordinateur")
        self.table.setItemDelegateForColumn(2, _DelegueNom(self.table))   # nom en gras + précisions en gris
        self.table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self._menu_produit)
        self.table.itemDoubleClicked.connect(lambda it: it.column() != 0 and self.ouvrir(it.row()))
        self.table.cellClicked.connect(self._clic)
        self.table.itemChanged.connect(self._coche_changee)
        self.table.itemSelectionChanged.connect(self._maj_boutons)
        d.addWidget(self.table, 1)

        self.aide = aide = QLabel("Cochez les produits (un clic sur la ligne), puis « Affiches » ou « Étiquettes énergie » :\n"
                      "le PDF s'ouvre tout de suite. Double-clic sur un produit : il s'ouvre dans « Un produit ».")
        aide.setObjectName("petit")
        d.addWidget(aide)
        hb = QHBoxLayout()
        self.b_ouvrir = QPushButton("🖼️  Faire l'affiche")
        self.b_ouvrir.setObjectName("principal")
        self.b_ouvrir.clicked.connect(lambda: self.ouvrir(self.table.currentRow()))
        self.b_lot = QPushButton("🖼️  Affiches")
        self.b_lot.setObjectName("principal")
        self.b_lot.setToolTip("Le PDF des affiches des produits cochés, ouvert tout de suite")
        self.b_lot.clicked.connect(self.vers_lot)
        self.b_energie = QPushButton("🍃  Étiquettes énergie")
        self.b_energie.setObjectName("energie")
        self.b_energie.clicked.connect(self.etiquettes)
        self.b_ouvrir.hide()                          # double-clic suffit : deux boutons seulement
        for b in (self.b_lot, self.b_energie):
            hb.addWidget(b)
        d.addLayout(hb)
        racine.addLayout(d, 1)
        for b in (self.b_lot, self.b_energie):         # remplacés par le panneau « Impression » à droite
            b.hide()
        self.b_lot.setVisible = self.b_energie.setVisible = lambda *_: None
        racine.addWidget(self._panneau_impression())
        self.charger()
        self.l_cat.setCurrentRow(0)

    # -- données ---------------------------------------------------------------
    # catégories utiles selon la carte choisie à l'accueil
    CAT_SANS_ENERGIE = {"consoles", "stockage", "recond", "ipad_recond"}   # pas d'étiquette énergie
    # affiches : pas les mobiles seniors (leurs étiquettes sont déjà en magasin)
    CAT_AFFICHES = {"neufs", "recond", "tablettes", "ipad_recond", "consoles"}

    def mode_energie(self, actif: bool) -> None:
        """Accueil : « Étiquettes énergie » = bouton 🍃 seul ; « Étiquettes produits » = bouton Affiches seul.
        Chaque mode ne montre que ses rayons."""
        self.mode = "energie" if actif else "produits"
        self.b_lot.setVisible(not actif)
        self.b_energie.setVisible(actif)
        self.table.setColumnHidden(5, not actif)            # colonne 🍃 : seulement pour les étiquettes énergie
        self._maj_categories()
        if hasattr(self, "_minuterie"):
            self._poser_options()
        self.aide.setText("Cochez les produits (un clic sur la ligne) : l'aperçu est à droite." if actif else
                          "Cochez les produits (un clic sur la ligne) : l'aperçu est à droite.\n"
                          "Double-clic sur un produit : il s'ouvre dans « Un produit ».")
        self.tout_decocher() if hasattr(self, "tout_decocher") else None
        self.filtrer()

    def _ajoutees(self) -> list[str]:
        """Catégories remises à la main dans ce mode (bouton « Ajouter une catégorie »)."""
        from ..reglages import lire_reglage
        return list(lire_reglage(f"categories_ajoutees_{getattr(self, 'mode', '')}", []) or [])

    def _cat_permise(self, cle: str) -> bool:
        mode = getattr(self, "mode", "")
        if cle == "tout" or not mode:
            return True
        if cle in self._ajoutees():
            return True
        return cle not in self.CAT_SANS_ENERGIE if mode == "energie" else cle in self.CAT_AFFICHES

    def _cachees(self) -> list[tuple[str, str]]:
        return [(cle, lib) for cle, lib in CATEGORIES if cle != "tout" and not self._cat_permise(cle)]

    def _maj_categories(self) -> None:
        for i in range(self.l_cat.count()):
            cle = self.l_cat.item(i).data(Qt.ItemDataRole.UserRole)
            self.l_cat.item(i).setHidden(not self._cat_permise(cle))
        if self.l_cat.currentItem() is not None and self.l_cat.currentItem().isHidden():
            self.l_cat.setCurrentRow(0)
        self.b_ajout_cat.setVisible(bool(getattr(self, "mode", "")) and bool(self._cachees()))

    def ajouter_categorie(self) -> None:
        """Remettre une catégorie enlevée de ce mode (ex. reconditionnés dans l'énergie)."""
        from PySide6.QtWidgets import QDialog, QDialogButtonBox, QCheckBox as _Case
        from ..reglages import enregistrer_reglage
        dlg = QDialog(self)
        dlg.setWindowTitle("➕ Ajouter une catégorie")
        v = QVBoxLayout(dlg)
        v.addWidget(QLabel("Catégories à ajouter ici :"))
        cases = []
        for cle, lib in self._cachees():
            c = _Case(lib)
            v.addWidget(c)
            cases.append((cle, c))
        b = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        b.button(QDialogButtonBox.StandardButton.Ok).setText("Ajouter")
        b.button(QDialogButtonBox.StandardButton.Cancel).setText("Annuler")
        b.accepted.connect(dlg.accept)
        b.rejected.connect(dlg.reject)
        v.addWidget(b)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        choix = [cle for cle, c in cases if c.isChecked()]
        if choix:
            enregistrer_reglage(f"categories_ajoutees_{self.mode}", self._ajoutees() + choix)
            self._maj_categories()
            self.filtrer()

    def _menu_categorie(self, pos) -> None:
        """Clic droit sur une catégorie ajoutée à la main : la retirer de ce mode."""
        it = self.l_cat.itemAt(pos)
        if it is None:
            return
        cle = it.data(Qt.ItemDataRole.UserRole)
        if cle not in self._ajoutees():
            return
        from PySide6.QtWidgets import QMenu
        from ..reglages import enregistrer_reglage
        m = QMenu(self)
        a = m.addAction("➖  Retirer cette catégorie d'ici")
        if m.exec(self.l_cat.mapToGlobal(pos)) is a:
            enregistrer_reglage(f"categories_ajoutees_{self.mode}", [c for c in self._ajoutees() if c != cle])
            self._maj_categories()
            self.filtrer()

    def charger(self) -> None:
        self.articles = self.cat.base.catalogue_complet()
        self._icones = {}
        for a in self.articles:
            a["_cat"] = categorie(a)
            a["_marque"] = marque(a)
        actuelle = self.c_marque.currentText()
        self.c_marque.blockSignals(True)
        self.c_marque.clear()
        self.c_marque.addItem("Toutes")
        for m in sorted({a["_marque"] for a in self.articles if a["_marque"] != "—"}):
            self.c_marque.addItem(m)
        i = self.c_marque.findText(actuelle)
        self.c_marque.setCurrentIndex(max(0, i))
        self.c_marque.blockSignals(False)
        self.filtrer()

    def filtrer(self) -> None:
        it = self.l_cat.currentItem()
        cle = it.data(Qt.ItemDataRole.UserRole) if it else "tout"
        mq = self.c_marque.currentText()
        mots = self.recherche.text().lower().split()
        liste = []
        permises = {c for c, _ in CATEGORIES if self._cat_permise(c)}   # lu une fois (pas à chaque produit)
        ajoutees = set(self._ajoutees())
        for a in self.articles:
            if a.get("retire") and not self.c_retires.isChecked():
                continue
            if cle != "tout" and a["_cat"] != cle:
                continue
            if a["_cat"] not in permises:                   # rayons de l'autre mode : cachés
                continue
            if (getattr(self, "mode", "") == "energie" and energie._reconditionne(a)
                    and a["_cat"] not in ajoutees):
                continue                                     # reconditionnés : jamais d'étiquette énergie
            if mq and mq != "Toutes" and a["_marque"] != mq:
                continue
            if not all(correspond(a, m) for m in mots):
                continue
            liste.append(a)
        if not self._energie_active() and self.paires:     # deux produits ensemble : l'un sous l'autre
            par_code = {a["code"]: a for a in liste}
            ordre, vus = [], set()
            for a in liste:
                if a["code"] in vus:
                    continue
                ordre.append(a)
                vus.add(a["code"])
                autre = self.paires.get(a["code"])
                if autre in par_code and autre not in vus:
                    ordre.append(par_code[autre])
                    vus.add(autre)
            liste = ordre
        self.visibles = liste
        self.table.blockSignals(True)
        self.table.setUpdatesEnabled(False)
        self.table.setRowCount(0)
        self.table.setRowCount(len(liste))
        for i, a in enumerate(liste):
            c = QTableWidgetItem()
            c.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsUserCheckable)
            c.setCheckState(Qt.CheckState.Checked if a["code"] in self.coches else Qt.CheckState.Unchecked)
            c.setData(Qt.ItemDataRole.UserRole, a["code"])
            self.table.setItem(i, 0, c)
            ph = QTableWidgetItem()
            ic = self._icone(a)
            if ic is not None:
                ph.setIcon(ic)
            self.table.setItem(i, 1, ph)
            titre, details = decouper_nom(a["nom"])
            if a.get("retire"):
                details = (details + " · " if details else "") + "plus sur le site"
            paire = a["code"] in self.paires and not self._energie_active()
            if paire:
                details = f"🔗 Même étiquette que {self.paires[a['code']]}"
            nom = QTableWidgetItem(titre)
            nom.setData(Qt.ItemDataRole.UserRole, a["code"])
            nom.setData(_DETAILS, details)
            nom.setData(_PAIRE, paire)
            nom.setToolTip(a["nom"])
            self.table.setItem(i, 2, nom)
            cc = QTableWidgetItem(a["code"])
            co = QTableWidgetItem(a.get("coloris") or "")
            self.table.setItem(i, 3, cc)
            self.table.setItem(i, 4, co)
            if paire:                                       # même affiche : les deux lignes en bleu clair
                for it in (c, ph, nom, cc, co):
                    it.setBackground(QColor("#EAF3FD"))
            e = QTableWidgetItem()
            mini = self._mini_etiquette(a["code"]) if self._energie_active() else None
            if mini is not None:                            # la vraie étiquette, en miniature
                e.setIcon(mini)
                e.setToolTip("Étiquette énergie déjà sur l'ordinateur")
            self.table.setItem(i, 5, e)
        self.table.setUpdatesEnabled(True)
        self.table.blockSignals(False)
        self._maj_boutons()

    def _codes(self) -> list[str]:
        """Produits cochés (dans l'ordre du catalogue) ; sinon la ligne sélectionnée."""
        if self.coches:
            return [a["code"] for a in self.articles if a["code"] in self.coches]
        rangs = sorted({i.row() for i in self.table.selectedIndexes()})
        return [self.table.item(r, 2).data(Qt.ItemDataRole.UserRole) for r in rangs]

    def _clic(self, rang: int, col: int) -> None:
        """Un clic sur la ligne (hors bouton) coche ou décoche le produit."""
        if col == 0:
            return
        it = self.table.item(rang, 0)
        if it is not None:
            it.setCheckState(Qt.CheckState.Unchecked if it.checkState() == Qt.CheckState.Checked
                             else Qt.CheckState.Checked)

    def _coche_changee(self, it) -> None:
        if it.column() != 0:
            return
        code = it.data(Qt.ItemDataRole.UserRole)
        if it.checkState() == Qt.CheckState.Checked:
            self.coches.add(code)
        else:
            self.coches.discard(code)
        self._maj_boutons()

    def _icone(self, a: dict):
        """Vignette du produit, préparée une seule fois (petite image en mémoire)."""
        code = a["code"]
        if code not in self._icones:
            ic = None
            f = retrouver_photo(a.get("photo") or "")
            if f:
                from PySide6.QtGui import QImageReader
                lecteur = QImageReader(f)
                taille = lecteur.size()
                if taille.isValid() and max(taille.width(), taille.height()) > 0:
                    r = 92 / max(taille.width(), taille.height())
                    lecteur.setScaledSize(taille * r)          # lit directement en petit : rapide
                img = lecteur.read()
                if not img.isNull():
                    ic = QIcon(QPixmap.fromImage(img))
            self._icones[code] = ic
        return self._icones[code]

    # -- boutons sur les lignes cochées : ✏️ Modifier · 🔗 Fusionner · Séparer ------------------------
    def _bouton(self, texte: str, bleu: bool, action, gros: bool = False, court: str = "") -> QPushButton:
        b = QPushButton(texte)
        b.setProperty("long", texte)
        b.setProperty("court", court or texte)          # fenêtre étroite : texte plus court
        if bleu:
            b.setObjectName("bleu")
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        if gros:
            b.setStyleSheet("padding: 8px 18px; font-size: 11pt;")
        from PySide6.QtCore import QTimer
        # l'action passe après le clic : on ne détruit jamais un bouton pendant qu'on clique dessus
        b.clicked.connect(lambda _=False: QTimer.singleShot(0, action))
        return b

    def _groupe(self, *boutons) -> QWidget:
        w = QWidget(self.table.viewport())
        w.setObjectName("boutonsLigne")
        w.setStyleSheet("QWidget#boutonsLigne { background: transparent; }")
        h = QHBoxLayout(w)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(8)
        for b in boutons:
            h.addWidget(b)
        for x in (w, *boutons):
            x.ensurePolished()
        w.resize(w.sizeHint())
        return w

    def eventFilter(self, obj, ev):
        from PySide6.QtCore import QEvent
        if obj is self.table.viewport() and ev.type() == QEvent.Type.Resize:
            from PySide6.QtCore import QTimer
            QTimer.singleShot(0, self._placer_boutons)        # après la mise à jour des colonnes
        return super().eventFilter(obj, ev)

    def _placer_boutons(self) -> None:
        """Boutons à droite du nom ; pour 2 produits fusionnés : au milieu des deux lignes."""
        t = self.table
        for w, r, k in self._boutons_lignes:
            haut = t.rowViewportPosition(r)
            if haut < -t.rowHeight(r) * k or haut > t.viewport().height():
                w.hide()
                continue
            h = sum(t.rowHeight(r + i) for i in range(k))
            w.show()
            place = t.columnWidth(2) - 150                       # on garde au moins le début du nom
            for mode in ("long", "court"):
                for b in w.findChildren(QPushButton):
                    b.setText(b.property(mode))
                w.adjustSize()                                   # vraie taille, une fois le style appliqué
                if w.width() <= place:
                    break
            x = t.columnViewportPosition(2) + t.columnWidth(2) - w.width() - 10
            w.move(max(t.columnViewportPosition(2) + 120, x), haut + (h - w.height()) // 2)
            for i in range(k):
                it = t.item(r + i, 2)
                if it is not None and it.data(_RESERVE) != w.width() + 16:
                    it.setData(_RESERVE, w.width() + 16)

    def _maj_actions(self) -> None:
        """Seules les lignes cochées ont des boutons (la liste reste propre)."""
        t = self.table
        for w, _, _ in self._boutons_lignes:
            w.hide()
            w.deleteLater()
        t.viewport().update()                  # efface tout de suite l'ancien emplacement des boutons
        self._boutons_lignes = []
        if not hasattr(self, "visibles") or self._energie_active():
            return
        n = t.rowCount()
        codes = [t.item(r, 2).data(Qt.ItemDataRole.UserRole) if t.item(r, 2) else None for r in range(n)]
        seuls = {a["code"] for a in self.visibles if etiquette_seulement(a)}
        precedent = None                      # dernier produit coché seul (pour « Fusionner »)
        r = 0
        while r < n:
            code = codes[r]
            autre = self.paires.get(code)
            for k in (r, r + 1):
                if k < n and t.item(k, 2) is not None:
                    t.item(k, 2).setData(_RESERVE, 0)
            if autre and r + 1 < n and codes[r + 1] == autre:          # paire : boutons au milieu des 2 lignes
                if code in self.coches or autre in self.coches:
                    w = self._groupe(
                        self._bouton("✏️  Modifier", True, lambda _=False, c=code: self._modifier(c),
                                     gros=True, court="✏️"),
                        self._bouton("Séparer", False, lambda _=False, c=code: self._separer(c)))
                    self._boutons_lignes.append((w, r, 2))
                    for k in (r, r + 1):
                        t.item(k, 2).setData(_RESERVE, w.width() + 16)
                precedent = None
                r += 2
                continue
            if code in self.coches and code not in seuls:
                boutons = []
                if precedent:
                    nom = next((a["nom"] for a in self.visibles if a["code"] == precedent), precedent)
                    f = self._bouton("🔗  Fusionner", False,
                                     lambda _=False, a=precedent, b=code: self._mettre_ensemble(a, b), court="🔗")
                    f.setToolTip(f"Mettre ce produit sur la même étiquette que :\n{nom}")
                    boutons.append(f)
                boutons.append(self._bouton("✏️  Modifier", True, lambda _=False, c=code: self._modifier(c),
                                            court="✏️"))
                w = self._groupe(*boutons)
                self._boutons_lignes.append((w, r, 1))
                t.item(r, 2).setData(_RESERVE, w.width() + 16)
                precedent = None if autre else code
            r += 1
        gardes = {id(w) for w, _, _ in self._boutons_lignes}
        for w in t.viewport().findChildren(QWidget, "boutonsLigne"):   # sécurité : aucun ancien bouton ne reste
            if id(w) not in gardes:
                w.hide()
                w.deleteLater()
        t.viewport().update()
        self._placer_boutons()

    # -- barre d'action : n'apparaît que quand elle sert ------------------------------------------
    def _barre_action(self) -> QWidget:
        from PySide6.QtWidgets import QFrame
        f = QFrame()
        f.setObjectName("barreAction")
        f.setStyleSheet("QFrame#barreAction { background: white; border: 1px solid #D5DBE3; border-radius: 8px; }"
                        "QFrame#barreAction QLabel { border: none; background: transparent; }")
        h = QHBoxLayout(f)
        h.setContentsMargins(14, 8, 10, 8)
        f.setFixedHeight(54)
        h.setSpacing(10)
        self.l_action = QLabel("")
        self.l_action.setStyleSheet("font-weight: 600;")
        self.l_astuce = QLabel("")
        self.l_astuce.setObjectName("petit")
        h.addWidget(self.l_action)
        h.addWidget(self.l_astuce)
        h.addStretch(1)
        self.b_modif = QPushButton("✏️  Modifier ce produit")
        self.b_modif.setObjectName("bleu")
        self.b_modif.clicked.connect(lambda: self._modifier(self._coches_affiches()[0]))
        self.b_ensemble = QPushButton("🔗  Mettre les 2 sur la même affiche")
        self.b_ensemble.setObjectName("bleu")
        self.b_ensemble.clicked.connect(lambda: self._mettre_ensemble(*self._coches_affiches()[:2]))
        self.b_separer = QPushButton("Séparer")
        self.b_separer.setToolTip("Chaque produit retrouve sa propre affiche")
        self.b_separer.clicked.connect(lambda: self._separer(self._coches_affiches()[0]))
        for b in (self.b_modif, self.b_ensemble, self.b_separer):
            h.addWidget(b)
        f.hide()
        self.w_action = f
        return f

    def _coches_affiches(self) -> list[str]:
        seuls = {a["code"] for a in self.articles if etiquette_seulement(a)}
        return [a["code"] for a in self.articles if a["code"] in self.coches and a["code"] not in seuls]

    def _maj_barre(self) -> None:
        if not hasattr(self, "w_action"):
            return
        if self._energie_active():
            self.w_action.hide()
            return
        codes = self._coches_affiches()
        n = len(codes)
        ensemble = n == 2 and self.paires.get(codes[0]) == codes[1]
        if n == 1:
            c = codes[0]
            seul = c not in self.paires
            self.l_action.setText("1 produit coché")
            self.l_astuce.setText("Coche un 2e produit pour les mettre\nsur la même affiche." if seul else "")
            self.b_modif.setText("✏️  Modifier ce produit")
            vis = (True, False, not seul)
        elif n == 2 and ensemble:
            self.l_action.setText("🔗 Ces 2 produits sont sur la même affiche")
            self.l_astuce.setText("")
            self.b_modif.setText("✏️  Modifier l'affiche")
            vis = (True, False, True)
        elif n == 2:
            self.l_action.setText("2 produits cochés")
            self.l_astuce.setText("")
            vis = (False, True, False)
        else:                         # toujours là (la liste ne saute pas) : elle explique quoi faire
            self.l_action.setText("")
            self.l_astuce.setText("Coche 1 produit pour le modifier,\nou 2 pour les mettre sur la même affiche."
                                  if n == 0 else f"{n} produits cochés.")
            vis = (False, False, False)
        for b, v in zip((self.b_modif, self.b_ensemble, self.b_separer), vis):
            b.setVisible(v)
        self.w_action.show()

    def _mettre_ensemble(self, a: str, b: str) -> None:
        for c in (a, b):
            old = self.paires.pop(c, None)
            if old:
                self.paires.pop(old, None)
        self.paires[a], self.paires[b] = b, a
        self.coches.update((a, b))
        self.filtrer()

    def _separer(self, code: str) -> None:
        autre = self.paires.pop(code, None)
        if autre:
            self.paires.pop(autre, None)
        self.filtrer()

    def _menu_produit(self, pos) -> None:
        """Clic droit sur un produit : Modifier (affiches) ou choisir l'étiquette énergie."""
        from PySide6.QtWidgets import QMenu
        it = self.table.itemAt(pos)
        if it is None:
            return
        code = self.table.item(it.row(), 2).data(Qt.ItemDataRole.UserRole)
        a = next((x for x in self.articles if x["code"] == code), None)
        if a is None:
            return
        m = QMenu(self)
        if self._energie_active():
            m.addAction("🍃  Choisir l'étiquette énergie…", lambda: self._choisir_eprel(code, a["nom"]))
        elif not etiquette_seulement(a):
            m.addAction("✏️  Modifier", lambda: self._modifier(code))
            if code in self.paires:
                m.addAction("Séparer", lambda: self._separer(code))
        if not m.isEmpty():
            m.exec(self.table.viewport().mapToGlobal(pos))

    def _mini_etiquette(self, code: str):
        """Miniature de l'étiquette énergie (EPREL si elle est choisie et téléchargée, sinon celle du site)."""
        if not hasattr(self, "_minis"):
            self._minis = {}
        if code in self._minis:
            return self._minis[code]
        ic = None
        try:
            f = energie.fichier_local(code)
            if f is not None:
                from PySide6.QtGui import QImageReader
                lecteur = QImageReader(str(f))
                t = lecteur.size()
                if t.isValid() and t.height() > 0:
                    lecteur.setScaledSize(t * (92 / t.height()))
                img = lecteur.read()
                if not img.isNull():
                    ic = QIcon(QPixmap.fromImage(img))
        except Exception:
            ic = None
        self._minis[code] = ic
        return ic

    def _modifier(self, code: str) -> None:
        """✏️ Modifier : la fenêtre « Modifier » s'ouvre directement (avec le 2e produit s'il y en a un)."""
        from PySide6.QtWidgets import QApplication
        from .edition import FenetreEdition
        from .icones import appliquer
        texte = f"{code} + {self.paires[code]}" if code in self.paires else code
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            p = self.cat.obtenir(texte).produit
        except Exception as e:
            QApplication.restoreOverrideCursor()
            QMessageBox.warning(self, "Dépôt Print", f"Produit introuvable :\n{e}")
            return
        QApplication.restoreOverrideCursor()
        d = FenetreEdition(self, self.cat, p)
        appliquer(d)
        if d.exec():
            self.fenetre.rafraichir_historique()
            self._minuterie.start()

    def _choisir_eprel(self, code: str, nom: str) -> None:
        from .choix_eprel import ChoixEprel
        if ChoixEprel(self, self.cat, code, nom).exec():
            self._minuterie.start()

    def _cases_visibles(self, coche: bool) -> None:
        """Coche / décoche les lignes affichées sans reconstruire la liste (instantané)."""
        etat = Qt.CheckState.Checked if coche else Qt.CheckState.Unchecked
        self.table.blockSignals(True)
        for r in range(self.table.rowCount()):
            it = self.table.item(r, 0)
            if it is not None:
                it.setCheckState(etat)
        self.table.blockSignals(False)
        self._maj_boutons()

    def tout_cocher(self) -> None:
        self.coches.update(a["code"] for a in self.visibles)
        self._cases_visibles(True)

    def tout_decocher(self) -> None:
        self.coches.clear()
        self._cases_visibles(False)

    def _ajouter_un(self, code: str) -> None:
        self.fenetre.lot.ajouter_codes([code])
        nom = next((a["nom"] for a in self.articles if a["code"] == code), code)
        self.compte.setText(f"✅ Ajouté à « Plusieurs produits » :\n{nom}")

    def _maj_boutons(self) -> None:
        n = len(self._codes())
        nb = len(self.visibles) if hasattr(self, "visibles") else 0
        coche = len(self.coches)
        self.b_tout.setText("✖ Tout décocher" if coche else "☑️ Tout cocher")
        self._maj_actions()
        self.compte.setText(f"{nb} produit{'s' if nb > 1 else ''}"
                            + (f"  ·  ✔ {coche} coché{'s' if coche > 1 else ''}" if coche else ""))
        na = len(self._codes_affiches())
        self.b_ouvrir.setEnabled(n == 1)
        self.b_lot.setEnabled(na >= 1)
        self.b_energie.setEnabled(n >= 1)
        self.b_lot.setText("🖼️  Affiches" + (f" ({na})" if na else ""))
        self.b_energie.setText("🍃  Étiquettes énergie" + (f" ({n})" if n else ""))
        if hasattr(self, "_minuterie"):
            self._maj_panneau()
            self._minuterie.start()

    # -- actions ---------------------------------------------------------------
    def ouvrir(self, rang: int) -> None:
        if rang < 0 or rang >= self.table.rowCount() or getattr(self.fenetre, "mode", "") == "energie":
            return
        code = self.table.item(rang, 2).data(Qt.ItemDataRole.UserRole)
        if code not in self._codes_affiches() and any(a["code"] == code and etiquette_seulement(a)
                                                      for a in self.articles):
            return                                   # pas d'affiche pour une TV ou un frigo
        f = self.fenetre
        f.onglets.setCurrentIndex(0)
        f._deux_cases(False)
        f._mettre_code(code)
        f.rechercher()

    def vers_lot(self) -> None:
        try:
            self._vers_lot()
        except Exception:
            _noter_erreur("Affiches")

    def _codes_affiches(self) -> list[str]:
        """Codes cochés qui peuvent avoir une affiche (téléphonie : pas les TV ni l'électroménager)."""
        seuls = {a["code"] for a in self.articles if etiquette_seulement(a)}
        codes = [c for c in self._codes() if c not in seuls]
        res, faits = [], set()
        for c in codes:                      # deux produits jumelés et cochés : une seule affiche
            if c in faits:
                continue
            autre = self.paires.get(c)
            if autre and autre in codes:
                res.append(f"{c} + {autre}")
                faits.add(autre)
            else:
                res.append(c)
            faits.add(c)
        return res

    def _vers_lot(self) -> None:
        """« Affiches » : le PDF des affiches des produits cochés, ouvert tout de suite."""
        codes = self._codes_affiches()
        if not codes or not self._confirmer_beaucoup(len(codes), "affiches"):
            return
        from datetime import datetime
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QDesktopServices
        from PySide6.QtWidgets import QApplication
        from .. import affiche, paths
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        prets, rates = [], []
        try:
            for c in codes:
                try:
                    p = getattr(self.cat.obtenir(c), "produit", None)
                except Exception as e:
                    rates.append((c, str(e).split("\n")[0]))
                    continue
                if p is not None and p.pret:
                    prets.append(p)
                else:
                    rates.append((c, "photo ou nom manquant : à compléter dans « Un produit »"))
            if not prets:
                raise RuntimeError("aucune affiche n'a pu être faite")
            horo = datetime.now().strftime("%Y-%m-%d_%Hh%M")
            nom = (self.fenetre.nom_fichier(prets[0]) if len(prets) == 1
                   else f"Affiches_{horo}_{len(prets)}_produits.pdf")
            dest = affiche.creer_pdf(prets, paths.output_dir() / nom, f"Affiches rayon ({len(prets)})")
            for p in prets:
                self.cat.base.noter_affiche(p, "PDF", str(dest))
        except PermissionError:
            QApplication.restoreOverrideCursor()
            QMessageBox.warning(self, "Fichier ouvert", "Ce PDF est ouvert dans un autre programme.\n"
                                                        "Fermez-le puis réessayez.")
            return
        except RuntimeError as e:
            QApplication.restoreOverrideCursor()
            QMessageBox.warning(self, "Affiches", f"Le PDF n'a pas été créé :\n{e}.\n\n"
                                + "\n".join(f"{c} : {r}" for c, r in rates[:10]))
            return
        QApplication.restoreOverrideCursor()
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(dest)))
        self.fenetre.rafraichir_historique()
        self._bilan(f"✅ PDF des affiches ouvert ({len(prets)})", rates)
        self.tout_decocher()

    # -- panneau « Impression » (comme le relevé) -------------------------------------------------
    OPTIONS_ENERGIE = {"marges": False, "texte": True, "pointilles": True, "eprel": True}
    OPTIONS_AFFICHES = {"par_feuille": 2, "protection": True, "pointilles": True, "un_par_produit": False}

    def _panneau_impression(self) -> QWidget:
        from PySide6.QtCore import QTimer
        from PySide6.QtWidgets import QButtonGroup, QScrollArea
        w = QWidget()
        w.setFixedWidth(340)
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 0, 0, 0)
        t = QLabel("🖨️ Impression")
        t.setObjectName("etiquette")
        v.addWidget(t)
        hm = QHBoxLayout()
        self.groupe_modes = QButtonGroup(self)
        self.b_mode = []
        for k in range(2):
            b = QPushButton("")
            b.setCheckable(True)
            b.setObjectName("mode")
            self.groupe_modes.addButton(b, k)
            hm.addWidget(b)
            self.b_mode.append(b)
        self.groupe_modes.idClicked.connect(lambda _: self._options_changees())
        v.addLayout(hm)
        self.l_mode_aide = QLabel("")
        self.l_mode_aide.setObjectName("petit")
        v.addWidget(self.l_mode_aide)
        self.c_opt = []
        for _ in range(3):
            c = QCheckBox("")
            c.toggled.connect(lambda _: self._options_changees())
            v.addWidget(c)
            self.c_opt.append(c)
        from .apercu_feuilles import ZoneApercu
        zone = ZoneApercu(lambda: self._minuterie.start())
        self._zone_apercu = zone
        self.l_apercu = zone.label
        v.addWidget(zone, 1)
        self.l_pages = QLabel("")
        self.l_pages.setObjectName("petit")
        v.addWidget(self.l_pages)
        self.b_export = QPushButton("📄  EXPORTER EN PDF")
        self.b_export.clicked.connect(lambda: self._sortie(imprimer=False))
        v.addWidget(self.b_export)
        self.b_imprimer = QPushButton("🖨️  IMPRIMER")
        self.b_imprimer.setMinimumHeight(48)
        self.b_imprimer.clicked.connect(lambda: self._sortie(imprimer=True))
        v.addWidget(self.b_imprimer)
        self._minuterie = QTimer(self, singleShot=True, interval=450)
        self._minuterie.timeout.connect(self._apercu)
        self._poser_options()
        return w

    def _energie_active(self) -> bool:
        return getattr(self, "mode", "") == "energie"

    def _opts(self) -> dict:
        from ..reglages import lire_reglage
        if self._energie_active():
            return {**self.OPTIONS_ENERGIE, **(lire_reglage("impression_energie", {}) or {})}
        return {**self.OPTIONS_AFFICHES, **(lire_reglage("impression_affiches", {}) or {})}

    def _poser_options(self) -> None:
        o = self._opts()
        e = self._energie_active()
        modes = (("Taille réelle", "Avec marges") if e else ("2 par feuille", "1 par feuille"))
        for b, txt in zip(self.b_mode, modes):
            b.setText(txt)
        k = (1 if o["marges"] else 0) if e else (1 if o["par_feuille"] == 1 else 0)
        self.b_mode[k].setChecked(True)
        self.l_mode_aide.setText(
            "Taille réelle : collées en haut de la feuille.\nAvec marges : centrées, pour les imprimantes\n"
            "qui coupent les bords." if e else
            "2 par feuille : deux affiches côte à côte\n(A4 paysage).\n1 par feuille : une grande affiche par page.")
        libs = (("Code et nom sous l'étiquette", "texte"), ("Pointillés de coupe", "pointilles"),
                ("Étiquette nette EPREL si possible", "eprel")) if e else \
               (("Pointillés de coupe", "pointilles"), ("Un PDF par produit", "un_par_produit"))
        self._cles_opt = [c for _, c in libs]
        for c in self.c_opt[len(libs):]:                  # affiches : 2 options seulement
            c.hide()
        for c, (lib, cle) in zip(self.c_opt, libs):
            c.show()
            c.blockSignals(True)
            c.setText(lib)
            c.setChecked(bool(o[cle]))
            c.blockSignals(False)
        self.b_imprimer.setText("🖨️  IMPRIMER LES ÉTIQUETTES" if e else "🖨️  IMPRIMER LES AFFICHES")
        self.b_imprimer.setObjectName("energie" if e else "modifier")
        self.b_imprimer.style().unpolish(self.b_imprimer)
        self.b_imprimer.style().polish(self.b_imprimer)
        self._maj_panneau()
        self._minuterie.start()

    def _options_changees(self) -> None:
        from ..reglages import enregistrer_reglage
        o = self._opts()
        k = self.groupe_modes.checkedId()
        if self._energie_active():
            o["marges"] = k == 1
        else:
            o["par_feuille"] = 1 if k == 1 else 2
        for c, cle in zip(self.c_opt, self._cles_opt):
            o[cle] = c.isChecked()
        enregistrer_reglage("impression_energie" if self._energie_active() else "impression_affiches", o)
        self._minuterie.start()

    def _codes_sortie(self) -> list[str]:
        return self._codes() if self._energie_active() else self._codes_affiches()

    def _maj_panneau(self) -> None:
        n = len(self._codes_sortie())
        quoi = "étiquette" if self._energie_active() else "affiche"
        self.b_export.setText(f"📄  EXPORTER EN PDF" + (f" ({n})" if n else ""))
        for b in (self.b_export, self.b_imprimer):
            b.setEnabled(n > 0)
        if not n:
            self.l_pages.setText(f"Coche des produits pour voir les {quoi}s.")

    def _etiquettes_doc(self, codes: list[str], apercu: bool):
        """(document, étiquettes trouvées, ratés). Aperçu : seulement les étiquettes déjà sur l'ordinateur."""
        o = self._opts()
        noms = {a["code"]: a["nom"] for a in self.articles}
        articles = {a["code"]: a for a in self.articles}
        trouvees, rates = [], []
        for c in codes:
            art = articles.get(c)
            try:
                if apercu:
                    f = None
                    if o["eprel"]:
                        from .. import eprel
                        info = eprel.memoire().get(c) or {}
                        num = info.get("choix") if info.get("choix") not in (None, "", "site") else info.get("numero")
                        if num and energie.fichier_eprel(num).is_file():
                            f = energie.fichier_eprel(num)
                    f = f or energie.fichier_local(c)
                    if f is None:
                        rates.append((c, "pas encore téléchargée"))
                        continue
                elif o["eprel"]:
                    f = energie.obtenir(self.cat.client, c, article=art)
                else:
                    f = energie.obtenir_image_site(self.cat.client, c)
                trouvees.append(energie.Etiquette(c, _nom_court(noms.get(c, c)), f, energie.format_de(art)))
            except energie.SansEtiquette as e:
                rates.append((c, str(e)))
            except Exception as e:
                rates.append((c, str(e).split(".")[0]))
        doc = energie.creer_pdf(trouvees, marges=o["marges"], texte=o["texte"], pointilles=o["pointilles"]) \
            if trouvees else None
        return doc, trouvees, rates

    def _affiches_doc(self, codes: list[str], apercu: bool = False):
        from pathlib import Path
        from .. import affiche
        o = self._opts()
        prets, rates = [], []
        for c in codes:
            try:
                if apercu:                    # aperçu : jamais d'Internet, rien dans l'historique
                    morceaux = [x.strip() for x in c.split("+")]
                    arts = [self.cat.base.article(x) for x in morceaux]
                    if not all(a and a.get("photo") and Path(retrouver_photo(a["photo"])).is_file() for a in arts):
                        rates.append((c, "photo pas encore téléchargée"))
                        continue
                    import copy
                    p = copy.copy(self.cat._obtenir_un(morceaux[0]).produit)
                    if len(morceaux) == 2:
                        p.version2 = self.cat._obtenir_un(morceaux[1]).produit
                else:
                    p = getattr(self.cat.obtenir(c), "produit", None)
            except Exception as e:
                rates.append((c, str(e).split("\n")[0]))
                continue
            if p is not None and p.pret:
                prets.append(p)
            else:
                rates.append((c, "photo ou nom manquant : à compléter dans « Un produit »"))
        doc = affiche.pdf_affiches(prets, o["par_feuille"], o["pointilles"]) if prets else None
        return doc, prets, rates

    def _apercu(self) -> None:
        from PySide6.QtGui import QPixmap
        codes = self._codes_sortie()
        if not codes:
            self.l_apercu.setPixmap(QPixmap())
            self.l_apercu.setMinimumHeight(0)
            self.l_apercu.setText("")
            return
        try:
            if self._energie_active():
                doc, ok, rates = self._etiquettes_doc(codes, apercu=True)
                manque = sum(1 for _, r in rates if r == "pas encore téléchargée")
                n_txt = f"{len(ok)} étiquette{'s' if len(ok) > 1 else ''}"
                if manque:
                    n_txt += f"\n{manque} à télécharger au moment d'imprimer"
            else:
                doc, ok, rates = self._affiches_doc(codes[:12], apercu=True)
                par = self._opts()["par_feuille"]
                f = len(codes) if par == 1 else (len(codes) + 1) // 2
                n_txt = f"{len(codes)} affiche{'s' if len(codes) > 1 else ''} · {f} feuille{'s' if f > 1 else ''} A4"
            if doc is None:
                self.l_apercu.setPixmap(QPixmap())
                self.l_apercu.setMinimumHeight(0)
                self.l_apercu.setText("\nPas encore d'aperçu :\nles photos seront téléchargées\nau moment d'imprimer.")
                self.l_pages.setText(n_txt)
                return
            self._zone_apercu.montrer(doc)
            if self._energie_active():
                n_txt += f" · {doc.page_count} feuille{'s' if doc.page_count > 1 else ''} A4"
            self.l_pages.setText(n_txt)
        except Exception as e:
            self.l_apercu.setPixmap(QPixmap())
            self.l_apercu.setMinimumHeight(0)
            self.l_apercu.setText(f"Aperçu impossible :\n{e}")

    def _sortie(self, imprimer: bool) -> None:
        try:
            self._sortie_(imprimer)
        except Exception:
            _noter_erreur("Impression")

    def _sortie_(self, imprimer: bool) -> None:
        from datetime import datetime
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QDesktopServices
        from PySide6.QtWidgets import QApplication
        from .. import paths
        codes = self._codes_sortie()
        e = self._energie_active()
        quoi = "étiquettes énergie" if e else "affiches"
        if not codes or not self._confirmer_beaucoup(len(codes), quoi):
            return
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            doc, ok, rates = self._etiquettes_doc(codes, apercu=False) if e else self._affiches_doc(codes)
        finally:
            QApplication.restoreOverrideCursor()
        if doc is None:
            QMessageBox.information(self, "Dépôt Print", f"Aucune {quoi[:-1]} n'a pu être faite.\n\n"
                                    + "\n".join(f"{c} : " + r.replace(" (", "\n        (") for c, r in rates[:12]))
            return
        horo = datetime.now().strftime("%Y-%m-%d_%Hh%M")
        if imprimer:
            from . import impression
            try:
                impression.imprimer(self, doc, "Étiquettes énergie" if e else "Affiches")
            except Exception as ex:
                QMessageBox.critical(self, "Impression impossible", str(ex))
                return
            if not e:
                for p in ok:
                    self.cat.base.noter_affiche(p, "impression", "")
        else:
            try:
                if not e and self._opts()["un_par_produit"] and len(ok) > 1:
                    from .. import affiche
                    o = self._opts()
                    dest = None
                    for p in ok:
                        d1 = affiche.pdf_affiches([p], o["par_feuille"], o["pointilles"])
                        f = paths.output_dir() / self.fenetre.nom_fichier(p)
                        d1.save(f)
                        self.cat.base.noter_affiche(p, "PDF", str(f))
                        dest = f
                    QDesktopServices.openUrl(QUrl.fromLocalFile(str(dest.parent)))
                else:
                    if e:
                        nom = (f"Etiquette_energie_{ok[0].code}.pdf" if len(ok) == 1
                               else f"Etiquettes_energie_{horo}_{len(ok)}.pdf")
                    else:
                        nom = (self.fenetre.nom_fichier(ok[0]) if len(ok) == 1
                               else f"Affiches_{horo}_{len(ok)}_produits.pdf")
                    dest = paths.output_dir() / nom
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    doc.save(dest)
                    if not e:
                        for p in ok:
                            self.cat.base.noter_affiche(p, "PDF", str(dest))
                    QDesktopServices.openUrl(QUrl.fromLocalFile(str(dest)))
            except PermissionError:
                QMessageBox.warning(self, "Fichier ouvert", "Ce PDF est ouvert dans un autre programme.\n"
                                                            "Fermez-le puis réessayez.")
                return
        if not e:
            self.fenetre.rafraichir_historique()
        self._bilan(("✅ Envoyé à l'imprimante" if imprimer else "✅ PDF ouvert") + f" ({len(ok)})", rates)

    def _confirmer_beaucoup(self, n: int, quoi: str) -> bool:
        """Au-delà de 20 produits, on demande avant de lancer (ça peut prendre un moment)."""
        if n <= 20:
            return True
        r = QMessageBox.question(self, "Dépôt Print", f"Faire les {quoi} des {n} produits cochés ?\n"
                                 "(ça peut prendre un moment)")
        return r == QMessageBox.StandardButton.Yes

    def _bilan(self, titre: str, rates: list) -> None:
        if rates:
            QMessageBox.information(self, "Dépôt Print", titre + "\n\n"
                                    + f"Pas fait pour {len(rates)} produit{'s' if len(rates) > 1 else ''} :\n"
                                    # les précisions entre parenthèses : sur leur propre ligne
                                    + "\n".join(f"{c} : " + r.replace(" (", "\n        (") for c, r in rates[:12]))

    def etiquettes(self) -> None:
        try:
            self._etiquettes()
        except Exception:
            _noter_erreur("Étiquettes énergie")

    def _etiquettes(self) -> None:
        """« Étiquettes énergie » : le PDF des étiquettes des produits cochés, ouvert tout de suite."""
        codes = self._codes()
        if not codes or not self._confirmer_beaucoup(len(codes), "étiquettes énergie"):
            return
        from datetime import datetime
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QDesktopServices
        from PySide6.QtWidgets import QApplication, QProgressDialog
        from .. import paths
        noms = {a["code"]: a["nom"] for a in self.articles}
        articles = {a["code"]: a for a in self.articles}
        attente = QProgressDialog("Recherche des étiquettes énergie…", "Arrêter", 0, len(codes), self)
        attente.setWindowTitle("🍃 Étiquettes énergie")
        attente.setMinimumDuration(400)
        trouvees, rates = [], []
        for n, c in enumerate(codes):
            attente.setValue(n)
            QApplication.processEvents()
            if attente.wasCanceled():
                break
            try:
                f = energie.obtenir(self.cat.client, c, article=articles.get(c))
                trouvees.append(energie.Etiquette(c, _nom_court(noms.get(c, c)), f,
                                                  energie.format_de(articles.get(c))))
            except energie.SansEtiquette as e:
                rates.append((c, str(e)))
            except Exception as e:
                rates.append((c, str(e).split(".")[0]))
        attente.setValue(len(codes))
        if not trouvees:
            QMessageBox.information(self, "🍃 Étiquettes énergie", "Aucune étiquette énergie pour ces produits.\n"
                                    "(reconditionnés et modèles sortis avant juin 2025 n'en ont pas)\n\n"
                                    # les précisions entre parenthèses : sur leur propre ligne
                                    + "\n".join(f"{c} : " + r.replace(" (", "\n        (") for c, r in rates[:12]))
            return
        nom = (f"Etiquette_energie_{trouvees[0].code}.pdf" if len(trouvees) == 1
               else f"Etiquettes_energie_{datetime.now().strftime('%Y-%m-%d_%Hh%M')}_{len(trouvees)}.pdf")
        dest = paths.output_dir() / nom
        try:
            energie.creer_pdf(trouvees, dest)
        except PermissionError:
            QMessageBox.warning(self, "Fichier ouvert", "Ce PDF est ouvert dans un autre programme.\n"
                                                        "Fermez-le puis réessayez.")
            return
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(dest)))
        self._bilan(f"✅ PDF des étiquettes ouvert ({len(trouvees)})", rates)
        for r in range(self.table.rowCount()):           # met à jour la colonne 🍃
            it = self.table.item(r, 5)
            code = self.table.item(r, 2).data(Qt.ItemDataRole.UserRole)
            if it is not None and energie.fichier_local(code):
                it.setText("✔")
