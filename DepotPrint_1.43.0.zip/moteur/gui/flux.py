"""Mise en page « en flux » : les éléments vont à la ligne quand la place manque (jamais coupés)."""
from __future__ import annotations

from PySide6.QtCore import QPoint, QRect, QSize, Qt
from PySide6.QtWidgets import QLayout


class Flux(QLayout):
    def __init__(self, parent=None, espace: int = 8):
        super().__init__(parent)
        self._items = []
        self._espace = espace
        self.setContentsMargins(0, 0, 0, 0)

    def addItem(self, item):
        self._items.append(item)

    def insertWidget(self, index: int, w):
        self.addWidget(w)
        self._items.insert(index, self._items.pop())

    def count(self):
        return len(self._items)

    def itemAt(self, i):
        return self._items[i] if 0 <= i < len(self._items) else None

    def takeAt(self, i):
        return self._items.pop(i) if 0 <= i < len(self._items) else None

    def expandingDirections(self):
        return Qt.Orientation(0)

    def hasHeightForWidth(self):
        return True

    def heightForWidth(self, largeur):
        return self._placer(QRect(0, 0, largeur, 0), True)

    def setGeometry(self, rect):
        super().setGeometry(rect)
        self._placer(rect, False)

    def sizeHint(self):
        return self.minimumSize()

    def minimumSize(self):
        s = QSize()
        for it in self._items:
            s = s.expandedTo(it.minimumSize())
        m = self.contentsMargins()
        return s + QSize(m.left() + m.right(), m.top() + m.bottom())

    def _placer(self, rect, essai: bool) -> int:
        m = self.contentsMargins()
        zone = rect.adjusted(m.left(), m.top(), -m.right(), -m.bottom())
        x, y, haut = zone.x(), zone.y(), 0
        for it in self._items:
            if it.widget() is not None and not it.widget().isVisible() and not essai:
                pass
            t = it.sizeHint()
            if x + t.width() > zone.right() + 1 and haut > 0:
                x, y, haut = zone.x(), y + haut + self._espace, 0
            if not essai:
                it.setGeometry(QRect(QPoint(x, y), t))
            x += t.width() + self._espace
            haut = max(haut, t.height())
        return y + haut - rect.y() + m.bottom()
