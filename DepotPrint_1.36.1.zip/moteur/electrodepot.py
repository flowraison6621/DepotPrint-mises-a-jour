"""Recherche d'un produit sur www.electrodepot.fr à partir de son code article.

Source utilisée : le moteur de recherche public du site
(https://www.electrodepot.fr/catalogsearch/result/?q=<code>), exactement comme
le ferait un visiteur. Aucune protection n'est contournée : pas de connexion,
pas de résolution de captcha, requêtes espacées, identifiant d'application
honnête. Si le site refuse l'accès, l'application le signale et propose les
solutions de repli (adresse de fiche, catalogue CSV, saisie manuelle).

Garanties :
- le produit n'est retenu que si son « refCode » est EXACTEMENT le code saisi ;
- la fiche produit est ensuite contrôlée (« Code article ») quand c'est possible ;
- la photo retenue est la photo principale nommée P<code>.jpg ; une image de
  remplacement ou une vignette trop petite est refusée.
"""

from __future__ import annotations

import html
import json
import re
import threading
import time
from dataclasses import dataclass, field
from urllib.parse import quote, urljoin, urlparse

import requests

from . import APP_VERSION
from .models import Ambiguite, ErreurRecherche

BASE = "https://www.electrodepot.fr"
URL_RECHERCHE = BASE + "/catalogsearch/result/?q={q}"
URL_PHOTO = BASE + "/media/catalog/product/P{code}.jpg"
DELAI_MIN = 1.0           # secondes entre deux requêtes (respect du site)
TIMEOUT = (8, 20)

USER_AGENT = (
    f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) DepotPrint/{APP_VERSION} "
    "(outil interne d'affichage en magasin)"
)


@dataclass
class Resultat:
    code: str
    nom: str
    url_fiche: str
    url_image: str = ""
    coloris: str = ""
    marque: str = ""
    galerie: list[str] = field(default_factory=list)
    verifie_fiche: bool = False
    avertissement: str = ""
    attributs: dict = field(default_factory=dict)
    prix: float = 0.0           # interne : calcul du tarif de protection, jamais imprimé
    accessoires: str = ""       # ligne « Accessoires » de la fiche (contenu de la boîte)
    description_boite: str = "" # phrases de la description sur le contenu de la boîte
    fiche_lue: bool = False


class ClientElectroDepot:
    def __init__(self) -> None:
        self.s = requests.Session()
        self.s.headers.update({
            "User-Agent": USER_AGENT,
            "Accept-Language": "fr-FR,fr;q=0.9",
        })
        self._dernier = 0.0
        self._verrou = threading.Lock()

    # -- réseau -------------------------------------------------------------
    def _get(self, url: str, accept: str = "text/html") -> requests.Response:
        with self._verrou:            # jamais deux requêtes simultanées vers le site
            return self._get_seul(url, accept)

    def _get_seul(self, url: str, accept: str) -> requests.Response:
        attente = DELAI_MIN - (time.monotonic() - self._dernier)
        if attente > 0:
            time.sleep(attente)
        try:
            r = self.s.get(url, timeout=TIMEOUT, headers={"Accept": accept})
        except requests.ConnectionError as e:
            raise ErreurRecherche(
                "Pas de connexion Internet (ou le site ne répond pas). "
                "Les produits déjà enregistrés restent utilisables."
            ) from e
        except requests.Timeout as e:
            raise ErreurRecherche("Le site Electro Dépôt met trop de temps à répondre. Réessayez.") from e
        except requests.RequestException as e:
            raise ErreurRecherche(f"Erreur réseau : {e}") from e
        finally:
            self._dernier = time.monotonic()
        if r.status_code in (403, 429):
            raise ErreurRecherche(
                "Le site Electro Dépôt refuse pour l'instant les recherches automatiques "
                f"(code {r.status_code}). Utilisez « Depuis une fiche produit » ou la saisie manuelle."
            )
        if r.status_code >= 500:
            raise ErreurRecherche(f"Le site Electro Dépôt est momentanément indisponible ({r.status_code}).")
        return r

    # -- recherche ----------------------------------------------------------
    def rechercher(self, code: str) -> Resultat:
        code = normaliser_code(code)
        r = self._get(URL_RECHERCHE.format(q=quote(code)))
        if r.status_code == 404:
            raise ErreurRecherche(f"Référence {code} introuvable sur electrodepot.fr.")
        produits = extraire_produits(r.text)
        if not produits and "catalogsearch" not in r.url and "captcha" in r.text.lower():
            raise ErreurRecherche(
                "Le site demande une vérification humaine : recherche automatique impossible. "
                "Utilisez « Depuis une fiche produit » ou la saisie manuelle."
            )
        format_inconnu = not produits and "initialProducts" not in r.text
        indice = (" Si cela arrive pour toutes les références, le site a peut-être changé : "
                  "utilisez « Depuis une fiche produit » ou la saisie manuelle.") if format_inconnu else ""

        exacts = [p for p in produits if p.get("refCode", "").strip() == code]
        if not exacts:
            # même nombre sans les zéros initiaux : correspondance incertaine
            proches = [p for p in produits if p.get("refCode", "").strip().lstrip("0") == code.lstrip("0") and code.lstrip("0")]
            if proches:
                exacts = proches
                avert = (f"Le site indique le code {proches[0].get('refCode')} au lieu de {code} "
                         "(zéros initiaux différents). Vérifiez le produit.")
            else:
                if produits:
                    raise ErreurRecherche(
                        f"Aucun produit n'a exactement le code {code} "
                        f"(la recherche renvoie {len(produits)} produit(s) sans rapport). "
                        "Vérifiez la référence."
                    )
                raise ErreurRecherche(f"Référence {code} introuvable sur electrodepot.fr.{indice}")
        else:
            avert = ""

        # dédoublonnage par fiche
        uniques: dict[str, dict] = {}
        for p in exacts:
            uniques.setdefault(p.get("itemUrl", "") or p.get("name", ""), p)
        if len(uniques) > 1:
            cands = [{"nom": p.get("name", ""), "url": self._url_fiche(p)} for p in uniques.values()]
            raise Ambiguite(f"Plusieurs produits portent le code {code}. Choisissez le bon.", cands)

        p = next(iter(uniques.values()))
        res = Resultat(
            code=code,
            nom=p.get("name", "").strip(),
            url_fiche=self._url_fiche(p),
            url_image=p.get("imageUrl", ""),
            coloris=p.get("coloris", ""),
            marque=p.get("brand", ""),
            avertissement=avert,
            attributs=p,
            prix=lire_prix(p.get("price", "")),
        )
        if not res.nom:
            raise ErreurRecherche(f"Le produit {code} a été trouvé mais sans désignation.")
        self._controler_fiche(res)
        return res

    def lire_fiche(self, url: str) -> dict | None:
        try:
            r = self._get(url)
        except ErreurRecherche:
            return None
        return analyser_fiche(r.text) if r.status_code == 200 else None

    def chercher(self, texte: str) -> list[dict]:
        """Recherche libre sur le site (sert à trouver les autres coloris d'un modèle)."""
        r = self._get(URL_RECHERCHE.format(q=quote(texte)))
        return extraire_produits(r.text) if r.status_code == 200 else []

    def depuis_fiche(self, url: str, code_attendu: str = "") -> Resultat:
        """Solution de repli : l'utilisateur colle l'adresse de la fiche produit."""
        u = urlparse(url.strip())
        if not u.scheme:
            url = "https://" + url.strip()
            u = urlparse(url)
        if not (u.hostname or "").endswith("electrodepot.fr"):
            raise ErreurRecherche("L'adresse doit être une fiche produit de www.electrodepot.fr.")
        r = self._get(url)
        if r.status_code == 404:
            raise ErreurRecherche("Cette fiche produit n'existe plus (produit supprimé ?).")
        infos = analyser_fiche(r.text)
        if not infos["nom"]:
            raise ErreurRecherche("Cette page ne ressemble pas à une fiche produit.")
        code = infos["code"]
        if not code:
            raise ErreurRecherche("Le code article n'apparaît pas sur cette fiche : impossible de vérifier le produit.")
        if code_attendu and normaliser_code(code_attendu) != code:
            raise ErreurRecherche(
                f"Cette fiche correspond au code {code}, pas au code {normaliser_code(code_attendu)}."
            )
        return Resultat(
            code=code, nom=infos["nom"], url_fiche=r.url, url_image=infos["og_image"],
            galerie=infos["galerie"], verifie_fiche=True, prix=infos["prix"],
            accessoires=infos["accessoires"], description_boite=infos["description_boite"], fiche_lue=True,
        )

    def _url_fiche(self, p: dict) -> str:
        u = p.get("itemUrl", "")
        if not u:
            return ""
        if not u.startswith("http"):
            u = urljoin(BASE + "/", u if u.endswith(".html") else u + ".html")
        return u

    def _controler_fiche(self, res: Resultat) -> None:
        """Double vérification sur la fiche produit (non bloquante si la fiche est inaccessible)."""
        if not res.url_fiche:
            return
        try:
            r = self._get(res.url_fiche)
        except ErreurRecherche:
            return
        if r.status_code != 200:
            return
        infos = analyser_fiche(r.text)
        res.galerie = infos["galerie"]
        res.accessoires, res.description_boite, res.fiche_lue = infos["accessoires"], infos["description_boite"], True
        if infos["prix"] and not res.prix:
            res.prix = infos["prix"]
        if infos["code"]:
            if infos["code"] != res.code:
                raise ErreurRecherche(
                    f"Incohérence : la fiche trouvée porte le code {infos['code']} et non {res.code}. "
                    "Produit non retenu par sécurité."
                )
            res.verifie_fiche = True
        if infos["nom"] and not res.nom:
            res.nom = infos["nom"]

    # -- photo --------------------------------------------------------------
    def telecharger_photo(self, res: Resultat) -> bytes:
        """Photo principale du produit (jamais une photo d'un autre code)."""
        candidats = [URL_PHOTO.format(code=res.code)]
        if res.url_image and _photo_du_code(res.url_image, res.code):
            candidats.append(res.url_image)
        from .images import ImageInvalide, est_uni, ouvrir, TAILLE_MIN
        derniere = "aucune photo trouvée"
        for url in candidats:
            try:
                r = self._get(url, accept="image/avif,image/webp,image/png,image/jpeg,*/*;q=0.5")
            except ErreurRecherche as e:
                derniere = str(e)
                continue
            if r.status_code != 200 or not r.content:
                derniere = f"photo indisponible ({r.status_code})"
                continue
            try:
                im = ouvrir(r.content)
            except ImageInvalide as e:
                derniere = str(e)
                continue
            if max(im.size) < TAILLE_MIN or est_uni(r.content):
                derniere = "le site renvoie une image de remplacement (pas de vraie photo)"
                continue
            return r.content
        raise ErreurRecherche(f"Produit trouvé, mais photo indisponible : {derniere}. "
                              "Ajoutez une photo avec « Modifier ».")

    def telecharger_url(self, url: str) -> bytes:
        r = self._get(url, accept="image/avif,image/webp,image/png,image/jpeg,*/*;q=0.5")
        if r.status_code != 200:
            raise ErreurRecherche(f"Image indisponible ({r.status_code}).")
        return r.content


# --- analyse des pages ------------------------------------------------------------

def normaliser_code(code: str) -> str:
    """Le code reste du texte : on retire seulement espaces et caractères parasites."""
    c = re.sub(r"[\s .\-]", "", str(code or ""))
    if not c:
        raise ErreurRecherche("Saisissez un code produit.")
    if not c.isalnum() or len(c) > 20:
        raise ErreurRecherche(f"« {code} » n'est pas un code produit valide.")
    return c


def _valeur(attr: dict) -> str:
    vals = attr.get("vals") or []
    if not vals or not isinstance(vals[0], dict):
        return ""
    v0 = vals[0]
    v = v0.get("label") if attr.get("attributeType") == "ID" else v0.get("value")
    return html.unescape(str(v or ""))


def extraire_produits(page: str) -> list[dict]:
    """Lit les produits intégrés à la page de résultats.

    Structure observée : "initialProducts":[{"position":1,"item":{"sku":"…",
    "attributeInfo":[{"attributeName":"name","vals":[{"value":"…"}]}, …]}}, …]
    """
    dec = json.JSONDecoder()
    produits: list[dict] = []
    for m in re.finditer(r'"initialProducts"\s*:\s*\[', page):
        try:
            liste, _ = dec.raw_decode(page, m.end() - 1)
        except json.JSONDecodeError:
            continue
        for entree in liste if isinstance(liste, list) else []:
            item = entree.get("item", entree) if isinstance(entree, dict) else {}
            if not isinstance(item, dict):
                continue
            p = {a.get("attributeName"): _valeur(a)
                 for a in item.get("attributeInfo") or [] if isinstance(a, dict)}
            sku = str(item.get("sku") or "").strip()
            if sku:
                p["sku"] = sku
                # refCode et sku doivent concorder ; sinon le produit est ignoré
                if p.get("refCode") and p["refCode"].strip() != sku:
                    continue
                p.setdefault("refCode", sku)
            if p.get("refCode") or p.get("itemUrl"):
                produits.append(p)
    return produits


def analyser_fiche(page: str) -> dict:
    h1 = re.search(r"<h1[^>]*>(.*?)</h1>", page, re.S | re.I)
    nom = html.unescape(re.sub(r"<[^>]+>", "", h1.group(1))).strip() if h1 else ""
    nom = " ".join(nom.split())
    m = re.search(r"Code article\s*</t[dh]>\s*<td[^>]*>\s*([A-Za-z0-9]+)\s*<", page, re.I)
    code = m.group(1) if m else ""
    og = re.search(r'property="og:image"\s+content="([^"]+)"', page) or \
        re.search(r'content="([^"]+)"\s+property="og:image"', page)
    og_image = html.unescape(og.group(1)) if og else ""
    galerie = []
    if code:
        vus = set()
        for f in re.findall(rf"media/catalog/product/(?:cache/\w+/)?(P{re.escape(code)}(?:-\d+)?\.(?:jpg|png|webp))", page):
            if f not in vus:
                vus.add(f)
                galerie.append(f"{BASE}/media/catalog/product/{f}")
        galerie.sort(key=lambda u: (0 if re.search(rf"/P{re.escape(code)}\.", u) else 1, u))
    pm = re.search(r'product:price:amount"\s+content="([\d.,]+)"', page) or \
        re.search(r'content="([\d.,]+)"\s+property="product:price:amount"', page)
    from .boite import depuis_fiche
    acc, desc = depuis_fiche(page)
    return {"nom": nom, "code": code, "og_image": og_image, "galerie": galerie,
            "prix": lire_prix(pm.group(1)) if pm else 0.0, "accessoires": acc, "description_boite": desc}


def lire_prix(v) -> float:
    """« 229 », « 9.98 », « 1 299,99 € » → nombre (0 si illisible)."""
    t = re.sub(r"[^\d,.]", "", str(v or ""))
    if "," in t and "." in t:
        t = t.replace(".", "").replace(",", ".")
    else:
        t = t.replace(",", ".")
    try:
        return round(float(t), 2)
    except ValueError:
        return 0.0


def _photo_du_code(url: str, code: str) -> bool:
    return re.search(rf"/P{re.escape(code)}(?:-\d+)?\.(?:jpg|png|webp)", url) is not None
