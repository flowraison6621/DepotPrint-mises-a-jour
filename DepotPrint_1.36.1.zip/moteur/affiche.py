"""Génération des affiches au format PDF.

Principe de fidélité : le fond de l'affiche (cadres orange et jaune, rectangle
blanc arrondi, 5 pictogrammes, mention rouge) est la page du modèle d'origine,
dont seules la photo et la désignation ont été retirées. Ce fond est posé tel
quel, en vectoriel, sur chaque page : il ne peut donc jamais être modifié.
Seules la photo et la désignation sont ajoutées par-dessus.
"""

from __future__ import annotations

import io
import math
import re
from dataclasses import dataclass
from pathlib import Path

import pymupdf
from PIL import Image

from . import paths
from .models import Cadrage, Mentions, Produit

# --- Page A4 paysage ---------------------------------------------------------
A4_L, A4_H = 841.89, 595.28

# --- Cotes relevées sur « Copie de TRAME TEL.pdf » (repère du modèle, en pt) --
DECALAGE_MODELE_2 = 340.43            # dans le modèle : 2e affiche = 1re décalée vers la droite
# Bord extérieur du cadre orange de la 1re affiche (trait de 6 pt compris)
CADRE = (86.572, 122.954, 388.609, 494.487)
LARG_AFFICHE = CADRE[2] - CADRE[0]
# Sur la feuille : affiches collées l'une à l'autre, dans le coin haut-gauche (3 coupes)
DECALAGE_AFFICHE_2 = LARG_AFFICHE
CENTRE_X = 240.47                     # centre du nom dans le modèle
ZONE_PHOTO = (CENTRE_X - 120.0, 157.0, CENTRE_X + 120.0, 358.0)
NOM_BASE = 381.15                     # ligne de base du nom (1 ligne)
NOM_TAILLE = 13.0                     # Barlow Bold 13 pt, noir
NOM_TAILLE_MIN_1L = 10.5              # en dessous, on passe sur 2 lignes
NOM_TAILLE_MIN = 7.5                  # plancher absolu de lisibilité
NOM_LARGEUR_MAX = 244.0               # largeur utile dans le cadre blanc
NOM_ZONE_HAUT, NOM_ZONE_BAS = 362.0, 397.0   # entre photo et pictogrammes

RESOLUTION_PHOTO_DPI = 400

# --- Badges (produits reconditionnés, iPhone) ----------------------------------------
VERT_BADGE = (0x1E / 255, 0x7D / 255, 0x3A / 255)
VERT_CLAIR = (0x43 / 255, 0xA0 / 255, 0x47 / 255)
BANDEAU_HAUT, BANDEAU_BAS = 146.0, 163.0
BANDEAU_LARGEUR_MAX = 248.0
COULEURS_COLORIS = ["#E53935", "#FB8C00", "#FDD835", "#43A047", "#1E88E5", "#8E24AA", "#EC407A", "#26C6DA"]
COLORIS_CENTRE = (CENTRE_X + 96.0, 200.0)
COLORIS_RAYON = 28.0
BATTERIE_COIN = (CENTRE_X - 124.0, 178.0)   # coin haut gauche de la pastille (54 × 40)

# Étiquette « COLORIS DISPONIBLES » : vraies couleurs, groupées par réseau si 4G et 5G
ETIQ_X, ETIQ_Y, ETIQ_L = CENTRE_X + 60.0, 168.0, 64.0
ETIQ_LIGNE = 10.5
ETIQ_ENCRE = (0.11, 0.12, 0.14)

# Bandeau « PROTECTION CASSE · VOL · OXYDATION x€/MOIS » (style Electrosur, maquette validée)
PROTECTION_HAUT, PROTECTION_BAS = 342.0, 360.0
PROTECTION_TAILLE = 11.5
PROTECTION_FOND = (0x23 / 255, 0x23 / 255, 0x23 / 255)
PROTECTION_JAUNE = (1.0, 181 / 255, 47 / 255)
PROTECTION_TEXTE = "PROTECTION CASSE · VOL · OXYDATION  "            # au-delà, aucun gain visible à l'impression
TRANQUILLITE_TEXTE = "GARANTIE TRANQUILLITÉ · PANNE  "           # consoles et manettes (pas de casse / vol)


def texte_protection(p) -> str:
    return TRANQUILLITE_TEXTE if est_jeu(p) else PROTECTION_TEXTE


@dataclass
class _Mise:
    echelle: float
    ox: float
    oy: float

    def r(self, x0, y0, x1, y1) -> pymupdf.Rect:
        e = self.echelle
        return pymupdf.Rect(self.ox + x0 * e, self.oy + y0 * e, self.ox + x1 * e, self.oy + y1 * e)

    def p(self, x, y) -> pymupdf.Point:
        return pymupdf.Point(self.ox + x * self.echelle, self.oy + y * self.echelle)


_fond_cache: pymupdf.Document | None = None
_police: pymupdf.Font | None = None
_police_protection: pymupdf.Font | None = None


def police_protection() -> pymupdf.Font:
    global _police_protection
    if _police_protection is None:
        _police_protection = pymupdf.Font(fontfile=str(paths.FONT_PROTECTION_FILE))
    return _police_protection


def _fond() -> pymupdf.Document:
    global _fond_cache
    if _fond_cache is None:
        _fond_cache = pymupdf.open(paths.TEMPLATE_PDF)
    return _fond_cache


def police() -> pymupdf.Font:
    global _police
    if _police is None:
        _police = pymupdf.Font(fontfile=str(paths.FONT_NAME_FILE))
    return _police


def _mise_en_page() -> _Mise:
    """Même échelle qu'avant (modèle 824 × 595 pt ajusté à l'A4, sans déformation) ;
    la 1re affiche touche le haut et la gauche de la feuille."""
    src = _fond()[0].rect
    e = min(A4_L / src.width, A4_H / src.height)
    return _Mise(e, -CADRE[0] * e, -CADRE[1] * e)


# --- Repères de découpe ---------------------------------------------------------------
GRIS_COUPE = (0.55, 0.55, 0.55)


def _ciseaux(page: pymupdf.Page, x: float, y: float, vertical: bool = False) -> None:
    """Petits ciseaux vectoriels (deux anneaux + deux lames), gris clair."""
    def pt(a, b):
        return pymupdf.Point(x + b, y - a) if vertical else pymupdf.Point(x + a, y + b)
    sh = page.new_shape()
    for sens in (-1, 1):
        sh.draw_circle(pt(2.2, 2.4 * sens), 1.9)
        sh.draw_line(pt(3.8, 1.6 * sens), pt(11.5, -0.9 * sens))
    sh.finish(color=GRIS_COUPE, width=0.8, fill=None)
    sh.commit()


POINTILLES = True          # réglé par pdf_affiches() ; les pointillés de coupe peuvent être retirés


def _reperes_coupe(page: pymupdf.Page, m: _Mise) -> None:
    if not POINTILLES:
        return
    bas = m.p(0, CADRE[3]).y
    xs = [m.p(CADRE[0] + k * LARG_AFFICHE, 0).x for k in (1, 2)]
    for a, b in [((0, bas), (A4_L, bas))] + [((x, 0), (x, A4_H)) for x in xs]:
        page.draw_line(a, b, color=GRIS_COUPE, width=0.6, dashes="[4 3] 0")
    _ciseaux(page, xs[1] + 8, bas)                       # coupe du bas
    for x in xs:                                          # coupes verticales
        _ciseaux(page, x, A4_H - 14, vertical=True)
    tw = pymupdf.TextWriter(page.rect, color=GRIS_COUPE)
    centre = (xs[1] + A4_L) / 2
    for i, ligne in enumerate(("Découper le long des pointillés :", "1 coupe horizontale + 2 verticales")):
        lg = police().text_length(ligne, 8)
        tw.append((centre - lg / 2, A4_H - 30 + i * 10), ligne, font=police(), fontsize=8)
    tw.write_text(page)


# --- Désignation ---------------------------------------------------------------

@dataclass
class MiseEnFormeNom:
    lignes: list[str]
    taille: float
    reduit: bool          # le texte a dû être réduit ou coupé en deux lignes
    trop_long: bool       # même au plus petit, il dépasse : à raccourcir


def _couper_deux_lignes(mots: list[str], taille: float) -> tuple[str, str] | None:
    f = police()
    meilleur = None
    for i in range(1, len(mots)):
        a, b = " ".join(mots[:i]), " ".join(mots[i:])
        w = max(f.text_length(a, taille), f.text_length(b, taille))
        if meilleur is None or w < meilleur[0]:
            meilleur = (w, a, b)
    if meilleur and meilleur[0] <= NOM_LARGEUR_MAX:
        return meilleur[1], meilleur[2]
    return None


def mettre_en_forme_nom(nom: str) -> MiseEnFormeNom:
    """Taille et coupure du nom : jamais tronqué, jamais coupé au milieu d'un mot."""
    nom = " ".join(nom.split())
    f = police()
    largeur = f.text_length(nom, NOM_TAILLE)
    if largeur <= NOM_LARGEUR_MAX:
        return MiseEnFormeNom([nom], NOM_TAILLE, False, False)
    # 1) réduire un peu, sur une ligne
    t = NOM_TAILLE * NOM_LARGEUR_MAX / largeur
    if t >= NOM_TAILLE_MIN_1L:
        return MiseEnFormeNom([nom], round(t - 0.05, 2), True, False)
    # 2) deux lignes équilibrées
    mots = nom.split(" ")
    if len(mots) > 1:
        t = 12.0
        while t >= NOM_TAILLE_MIN:
            c = _couper_deux_lignes(mots, t)
            if c and 2 * t * 1.08 <= NOM_ZONE_BAS - NOM_ZONE_HAUT:
                return MiseEnFormeNom(list(c), t, True, False)
            t -= 0.25
    # 3) une ligne, au plus petit qui tienne (mot unique très long)
    t = max(NOM_TAILLE_MIN, NOM_TAILLE * NOM_LARGEUR_MAX / largeur - 0.05)
    trop = f.text_length(nom, t) > NOM_LARGEUR_MAX
    return MiseEnFormeNom([nom], t, True, trop)


def _ecrire_nom(page: pymupdf.Page, m: _Mise, dx: float, mf: MiseEnFormeNom) -> None:
    f = police()
    tw = pymupdf.TextWriter(page.rect, color=(0, 0, 0))
    if len(mf.lignes) == 1:
        bases = [NOM_BASE]
    else:
        inter = mf.taille * 1.08
        centre = (NOM_ZONE_HAUT + NOM_ZONE_BAS) / 2
        b1 = centre - inter / 2 + mf.taille * 0.35
        bases = [b1, b1 + inter]
    for ligne, base in zip(mf.lignes, bases):
        w = f.text_length(ligne, mf.taille)
        x = CENTRE_X + dx - w / 2
        tw.append(m.p(x, base), ligne, font=f, fontsize=mf.taille * m.echelle)
    tw.write_text(page)


# --- Photo -----------------------------------------------------------------------

def zone_photo(mentions: Mentions | None = None, protection: bool = False) -> tuple[float, float, float, float]:
    """Zone de la photo, réduite pour laisser la place aux badges éventuels."""
    x0, y0, x1, y1 = ZONE_PHOTO
    if protection:
        y1 = PROTECTION_HAUT - 3.0                  # au-dessus du bandeau protection
    if mentions is not None:
        if mentions.reconditionne:
            y0 = BANDEAU_BAS + 5.0                  # sous le bandeau vert
        if mentions.coloris or mentions.batterie_neuve:
            x0, x1 = CENTRE_X - 92.0, CENTRE_X + 92.0   # badges dans les coins hauts
        if avec_etiquette(mentions):
            x1 = ETIQ_X - 3.0                            # la photo ne passe jamais sous l'étiquette
            if mentions.batterie_neuve:
                x0 = BATTERIE_COIN[0] + 54 + 3.0         # ni sous la pastille batterie
    return x0, y0, x1, y1


def avec_etiquette(m: Mentions) -> bool:
    """Étiquette « COLORIS DISPONIBLES » (couleurs réelles). Le rond « PLUSIEURS COLORIS »
    ne sert plus que si les couleurs n'ont pas pu être vérifiées."""
    from .coloris import plusieurs
    return bool(m.coloris and plusieurs(m.variantes_affichees()))     # iPhones compris


def _placer_photo(im: Image.Image, cadrage: Cadrage,
                  zone: tuple[float, float, float, float] = ZONE_PHOTO,
                  ) -> tuple[tuple[float, float, float, float], Image.Image]:
    """Rectangle (repère modèle) et image recadrée à poser, proportions conservées."""
    zx0, zy0, zx1, zy1 = zone
    zw, zh = zx1 - zx0, zy1 - zy0
    e = min(zw / im.width, zh / im.height) * max(0.3, min(cadrage.zoom, 2.0))
    w, h = im.width * e, im.height * e
    libre_x, libre_y = (zw - w) / 2, (zh - h) / 2
    # décalage : sur l'espace libre si la photo est plus petite, sur le débord sinon
    x0 = zx0 + libre_x + cadrage.decal_x * abs(libre_x)
    y0 = zy0 + libre_y + cadrage.decal_y * abs(libre_y)
    x1, y1 = x0 + w, y0 + h
    # intersection avec la zone : on recadre l'image au lieu de déborder
    ix0, iy0, ix1, iy1 = max(x0, zx0), max(y0, zy0), min(x1, zx1), min(y1, zy1)
    crop = (
        round((ix0 - x0) / e), round((iy0 - y0) / e),
        round((ix1 - x0) / e), round((iy1 - y0) / e),
    )
    if crop != (0, 0, im.width, im.height):
        im = im.crop(crop)
    # pas de pixels inutiles dans le PDF
    px_max_w = int((ix1 - ix0) / 72 * RESOLUTION_PHOTO_DPI)
    if im.width > px_max_w > 0:
        im = im.resize((px_max_w, max(1, round(im.height * px_max_w / im.width))), Image.LANCZOS)
    return (ix0, iy0, ix1, iy1), im


def _image_en_octets(im: Image.Image) -> bytes:
    buf = io.BytesIO()
    im.convert("RGB").save(buf, "JPEG", quality=95, subsampling=0, optimize=True)
    return buf.getvalue()


# --- Badges ------------------------------------------------------------------------

def _hex(h: str) -> tuple[float, float, float]:
    return tuple(int(h[i:i + 2], 16) / 255 for i in (1, 3, 5))


def _texte_centre(page, m: _Mise, x: float, base: float, texte: str, taille: float, couleur) -> None:
    f = police()
    tw = pymupdf.TextWriter(page.rect, color=couleur)
    tw.append(m.p(x - f.text_length(texte, taille) / 2, base), texte, font=f, fontsize=taille * m.echelle)
    tw.write_text(page)


def texte_bandeau(mentions: Mentions) -> str:
    return "RECONDITIONNÉ" + (f" · {mentions.etat.upper()}" if mentions.etat.strip() else "")


def _dessiner_badges(page: pymupdf.Page, m: _Mise, dx: float, mentions: Mentions) -> None:
    cx = CENTRE_X + dx
    f = police()
    if mentions.reconditionne:
        texte = texte_bandeau(mentions)
        taille = 10.5
        while f.text_length(texte, taille) + 22 > BANDEAU_LARGEUR_MAX and taille > 7:
            taille -= 0.25
        w = f.text_length(texte, taille) + 22
        page.draw_rect(m.r(cx - w / 2, BANDEAU_HAUT, cx + w / 2, BANDEAU_BAS),
                       color=None, fill=VERT_BADGE, radius=0.5)
        hauteur = BANDEAU_BAS - BANDEAU_HAUT
        _texte_centre(page, m, cx, BANDEAU_HAUT + hauteur / 2 + taille * 0.36, texte, taille, (1, 1, 1))

    if avec_etiquette(mentions):
        _dessiner_etiquette_coloris(page, m, dx, mentions.variantes_affichees())
    elif mentions.coloris and not mentions.variantes:      # couleurs non vérifiées sur le site
        c = m.p(COLORIS_CENTRE[0] + dx, COLORIS_CENTRE[1])
        r = COLORIS_RAYON * m.echelle
        n = len(COULEURS_COLORIS)
        for i, coul in enumerate(COULEURS_COLORIS):
            a = math.radians(i * 360 / n - 90)
            page.draw_sector(c, pymupdf.Point(c.x + r * math.cos(a), c.y + r * math.sin(a)), 360 / n,
                             color=None, fill=_hex(coul), fullSector=True)
        page.draw_circle(c, r * 0.74, color=None, fill=(1, 1, 1))
        for j, mot in enumerate(("PLUSIEURS", "COLORIS", "DISPONIBLES")):
            _texte_centre(page, m, COLORIS_CENTRE[0] + dx, COLORIS_CENTRE[1] - 3.9 + j * 6.0, mot, 5.7, (0, 0, 0))

    if mentions.batterie_neuve:
        x0, y0 = BATTERIE_COIN[0] + dx, BATTERIE_COIN[1]
        page.draw_rect(m.r(x0, y0, x0 + 54, y0 + 40), color=VERT_BADGE, fill=(1, 1, 1), width=1.6, radius=0.18)
        bx, by = x0 + 17, y0 + 6
        page.draw_rect(m.r(bx, by, bx + 18, by + 10), color=VERT_BADGE, width=1.4, radius=0.2)
        page.draw_rect(m.r(bx + 18, by + 3, bx + 20.5, by + 7), color=None, fill=VERT_BADGE)
        page.draw_rect(m.r(bx + 2.5, by + 2.5, bx + 15.5, by + 7.5), color=None, fill=VERT_CLAIR)
        _texte_centre(page, m, x0 + 27, y0 + 25.5, "BATTERIE", 7.2, VERT_BADGE)
        _texte_centre(page, m, x0 + 27, y0 + 33.5, "NEUVE", 7.2, VERT_BADGE)


# lettres de « COLORIS » en couleurs vives (le reste reste en noir)
COULEURS_LETTRES = ["#E53935", "#FB8C00", "#F2B705", "#43A047", "#1E88E5", "#8E24AA", "#EC407A"]


def _texte_multicolore(page, m: _Mise, cx: float, base: float, texte: str, taille: float) -> None:
    """Texte centré, une couleur par lettre."""
    f = police()
    x = cx - f.text_length(texte, taille) / 2
    for i, lettre in enumerate(texte):
        tw = pymupdf.TextWriter(page.rect, color=_hex(COULEURS_LETTRES[i % len(COULEURS_LETTRES)]))
        tw.append(m.p(x, base), lettre, font=f, fontsize=taille * m.echelle)
        tw.write_text(page)
        x += f.text_length(lettre, taille)


def _dessiner_etiquette_coloris(page: pymupdf.Page, m: _Mise, dx: float, variantes: list) -> None:
    from .coloris import teinte
    f = police()
    x0, y0, w = ETIQ_X + dx, ETIQ_Y, ETIQ_L
    groupes = [(r, c) for r, c in variantes if c]
    avec_reseau = len(groupes) > 1
    nb = sum(len(c) for _, c in groupes) + (len(groupes) if avec_reseau else 0)
    bas_max = PROTECTION_HAUT - 4.0
    lh = min(ETIQ_LIGNE, (bas_max - y0 - 16) / max(1, nb))      # beaucoup de couleurs : lignes serrées
    h = 15 + lh * nb + 1.5
    page.draw_rect(m.r(x0, y0, x0 + w, y0 + h), color=ETIQ_ENCRE, fill=(1, 1, 1), width=1.1, radius=0.12)
    _texte_multicolore(page, m, x0 + w / 2, y0 + 7.2, "COLORIS", 5.8)
    _texte_centre(page, m, x0 + w / 2, y0 + 12.8, "DISPONIBLES", 5.8, ETIQ_ENCRE)
    y = y0 + 15
    taille = min(6.3, lh * 0.62)
    for res, couleurs in groupes:
        if avec_reseau:
            page.draw_rect(m.r(x0 + 5, y + 1.5, x0 + 22, y + lh - 1.5), color=None, fill=ETIQ_ENCRE, radius=0.3)
            _texte_centre(page, m, x0 + 13.5, y + lh / 2 + 2.3, res or "?", min(6.4, lh * 0.62), (1, 1, 1))
            y += lh
        for nom in couleurs:
            c = _hex(teinte(nom))
            clair = sum(c) > 2.6                      # blanc, crème… : petit contour gris
            page.draw_circle(m.p(x0 + 10, y + lh / 2), min(3.7, lh * 0.36) * m.echelle,
                             color=(0.55, 0.57, 0.6) if clair else None, fill=c, width=0.6 if clair else 0)
            t = nom.upper()
            tt = taille
            while f.text_length(t, tt) > w - 20 and tt > 4.2:
                tt -= 0.2
            tw = pymupdf.TextWriter(page.rect, color=ETIQ_ENCRE)
            tw.append(m.p(x0 + 16, y + lh / 2 + tt * 0.36), t, font=f, fontsize=tt * m.echelle)
            tw.write_text(page)
            y += lh


def _dessiner_protection(page: pymupdf.Page, m: _Mise, dx: float, tarif, texte_bandeau: str = PROTECTION_TEXTE) -> None:
    """Bandeau anthracite : texte blanc + tarif jaune, en Big Shoulders (style Electrosur)."""
    from .reglages import texte_tarif
    f = police_protection()
    morceaux = [(texte_bandeau, (1, 1, 1)), (f"{texte_tarif(tarif)}€/MOIS", PROTECTION_JAUNE)]
    taille = PROTECTION_TAILLE
    while sum(f.text_length(t, taille) for t, _ in morceaux) + 22 > BANDEAU_LARGEUR_MAX and taille > 8:
        taille -= 0.25
    largeur = sum(f.text_length(t, taille) for t, _ in morceaux)
    cx = CENTRE_X + dx
    w = largeur + 22
    page.draw_rect(m.r(cx - w / 2, PROTECTION_HAUT, cx + w / 2, PROTECTION_BAS),
                   color=None, fill=PROTECTION_FOND, radius=0.35)
    base = PROTECTION_HAUT + (PROTECTION_BAS - PROTECTION_HAUT) / 2 + taille * 0.36
    x = cx - largeur / 2
    for texte, couleur in morceaux:
        tw = pymupdf.TextWriter(page.rect, color=couleur)
        tw.append(m.p(x, base), texte, font=f, fontsize=taille * m.echelle)
        tw.write_text(page)
        x += f.text_length(texte, taille)


# --- Pages -------------------------------------------------------------------------

def ajouter_page(doc: pymupdf.Document, produit: Produit) -> MiseEnFormeNom:
    """Ajoute une page A4 avec deux affiches identiques du produit."""
    if produit.version2 is not None:
        from .reglages import disposition_deux_versions, genre_deux_versions
        if disposition_deux_versions(genre_deux_versions(produit, produit.version2)) != "simple":
            return _ajouter_page_deux_versions(doc, produit, produit.version2)
    if not produit.photo or not Path(produit.photo).is_file():
        raise ValueError(f"{produit.code} : aucune photo disponible")
    if not produit.nom_affiche.strip():
        raise ValueError(f"{produit.code} : aucun nom à afficher")
    if produit.version2 is None:                      # produit seul : couleurs de son réseau seulement
        import copy as _copy
        from .reseau import mentions_de_son_reseau
        mentions = mentions_de_son_reseau(produit)
        if mentions is not produit.mentions:
            produit = _copy.copy(produit)
            produit.mentions = mentions

    m = _mise_en_page()
    page = doc.new_page(width=A4_L, height=A4_H)
    poser_fond(page, m, produit.mentions.boite, sans_pictos=est_jeu(produit))

    from .reglages import tarif_affiche
    tarif = tarif_affiche(produit)
    with Image.open(produit.photo) as im:
        im.load()
        (x0, y0, x1, y1), im_pose = _placer_photo(im, produit.cadrage, zone_photo(produit.mentions, bool(tarif)))
    data = _image_en_octets(im_pose)
    nom = produit.nom_affiche
    if produit.version2 is None:                  # produit seul : le réseau est dans le nom
        from .reseau import nom_produit_seul
        nom = nom_produit_seul(produit)
    mf = mettre_en_forme_nom(nom)

    xref = 0
    for dx in (0.0, DECALAGE_AFFICHE_2):          # deux affiches strictement identiques
        rect = m.r(x0 + dx, y0, x1 + dx, y1)
        if xref:
            page.insert_image(rect, xref=xref)
        else:
            xref = page.insert_image(rect, stream=data)
        _ecrire_nom(page, m, dx, mf)
        _dessiner_badges(page, m, dx, produit.mentions)
        if tarif:
            _dessiner_protection(page, m, dx, tarif, texte_protection(produit))
        _dessiner_reference(page, m, dx, produit)
    _reperes_coupe(page, m)
    return mf


# --- Une affiche pour DEUX versions du même téléphone (une seule cloche) -------------------------------
#  Bandeau « RECONDITIONNÉ » commun, puis un encadré par version : état, batterie neuve, ses couleurs,
#  sa protection. Deux dispositions au choix (Réglages) : « cote » (photo en haut) ou « empile ».

ENCRE_DUO = (0.11, 0.12, 0.14)


def _texte(page, m, x, base, t, taille, coul, f=None, centre=False):
    f = f or police()
    if centre:
        x -= f.text_length(t, taille) / 2
    tw = pymupdf.TextWriter(page.rect, color=coul)
    tw.append(m.p(x, base), t, font=f, fontsize=taille * m.echelle)
    tw.write_text(page)


_CAPA = re.compile(r"\b\d+\s?(?:GO|TO)\b", re.I)


def _capacite(nom: str) -> str:
    m = _CAPA.search(nom or "")
    return m.group(0).upper().replace(" ", "") if m else ""


_RESEAU = re.compile(r"\b([45]G)\b", re.I)


def _reseau(p: Produit) -> str:
    """Réseau toujours connu pour un téléphone : écrit sur le site, déduit du modèle ou choisi à la main."""
    from .reseau import reseau
    return reseau(p)


def resume_version(p: Produit, majuscules: bool = False) -> str:
    """Même structure pour chaque version : état (ou neuf) · réseau · capacité · batterie neuve.
    Ex. « Excellent état · 5G · 256 Go · batterie neuve », « Neuf · 4G · 32 Go »."""
    mm = p.mentions
    morceaux = [((mm.etat or "RECONDITIONNÉ") if mm.reconditionne else "NEUF")]
    if _reseau(p):
        morceaux.append(_reseau(p))
    if _capacite(p.nom_affiche):
        morceaux.append(_capacite(p.nom_affiche))
    if not majuscules:
        morceaux = [morceaux[0].capitalize()] + [m.replace("GO", " Go").replace("TO", " To") for m in morceaux[1:]]
        if mm.batterie_neuve:
            morceaux.append("batterie neuve")
    return " · ".join(morceaux)


def _titre_version(p: Produit, *_ignores) -> str:
    """Titre de l'encadré : état (ou NEUF) · réseau · capacité, dans le même ordre pour chaque version."""
    return resume_version(p, majuscules=True)


def _couleurs_version(p: Produit) -> list[str]:
    """Couleurs de CETTE version : seulement celles de son réseau (4G ou 5G) quand le site les distingue."""
    groupes = p.mentions.variantes_affichees()
    r = _reseau(p)
    if r and any((g or "").upper() == r for g, _ in groupes):
        groupes = [(g, cs) for g, cs in groupes if (g or "").upper() == r]
    vus = []
    for _, cs in groupes:
        for c in cs:
            if c not in vus:
                vus.append(c)
    return vus


def _carte_version(page, m, x0, y0, x1, y1, p: Produit, avec_capacite: bool = False,
                   avec_reseau: bool = False, melange: bool = False) -> None:
    from .coloris import teinte
    from .reglages import tarif_affiche, texte_tarif
    w = x1 - x0
    page.draw_rect(m.r(x0, y0, x1, y1), color=ENCRE_DUO, fill=(1, 1, 1), width=1.1, radius=0.08)
    page.draw_rect(m.r(x0, y0, x1, y0 + 15), color=None, fill=VERT_BADGE, radius=0.25)
    page.draw_rect(m.r(x0, y0 + 8, x1, y0 + 15), color=None, fill=VERT_BADGE)
    titre, taille = _titre_version(p, avec_capacite, avec_reseau, melange), 7.6
    while police().text_length(titre, taille) > w - 8 and taille > 5:
        taille -= 0.2
    _texte(page, m, (x0 + x1) / 2, y0 + 10.4, titre, taille, (1, 1, 1), centre=True)
    y = y0 + 17
    if melange and p.mentions.reconditionne and p.mentions.etat:   # sans état, le titre le dit déjà
        _texte(page, m, (x0 + x1) / 2, y + 7.6, "RECONDITIONNÉ", 6.6, VERT_BADGE, centre=True)
        y += 10
    if p.mentions.batterie_neuve:
        lg = police().text_length("BATTERIE NEUVE", 6.2) + 18
        bx, by = (x0 + x1) / 2 - lg / 2, y + 2.2
        page.draw_rect(m.r(bx, by, bx + 13, by + 7), color=VERT_BADGE, width=0.9, radius=0.2)
        page.draw_rect(m.r(bx + 13, by + 2, bx + 14.6, by + 5), color=None, fill=VERT_BADGE)
        page.draw_rect(m.r(bx + 1.6, by + 1.6, bx + 11.4, by + 5.4), color=None, fill=VERT_CLAIR)
        _texte(page, m, bx + 18, y + 8.2, "BATTERIE NEUVE", 6.2, VERT_BADGE)
        y += 11
    tarif = tarif_affiche(p)
    bas = y1 - (17 if tarif else 3)
    couleurs = _couleurs_version(p)
    if couleurs:
        # « COLORIS » multicolore, « DISPONIBLES » en noir
        f, t = police(), 5.4
        suite = " DISPONIBLES" if len(couleurs) > 1 else ""
        lg = f.text_length("COLORIS" + suite, t)
        xg = (x0 + x1) / 2 - lg / 2
        _texte_multicolore(page, m, xg + f.text_length("COLORIS", t) / 2, y + 7.4, "COLORIS", t)
        if suite:
            _texte(page, m, xg + f.text_length("COLORIS", t), y + 7.4, suite, t, ENCRE_DUO)
        y += 9
        colonnes = 2 if len(couleurs) <= 8 else 3
        rangs = -(-len(couleurs) // colonnes)
        lh = min(11.0, (bas - y) / max(1, rangs))
        col_w = (w - 8) / colonnes
        for i, nom in enumerate(couleurs):
            cx = x0 + 6 + (i % colonnes) * col_w
            cy = y + 1 + (i // colonnes) * lh
            c = _hex(teinte(nom))
            clair = sum(c) > 2.6
            page.draw_circle(m.p(cx + 2.8, cy + lh / 2), min(2.7, lh * 0.3) * m.echelle,
                             color=(0.55, 0.57, 0.6) if clair else None, fill=c, width=0.5 if clair else 0)
            t, tt = nom.upper(), min(6.0, lh * 0.62)
            while police().text_length(t, tt) > col_w - 9 and tt > 4:
                tt -= 0.2
            _texte(page, m, cx + 7.5, cy + lh / 2 + tt * 0.35, t, tt, ENCRE_DUO)
    if tarif:
        f = police_protection()
        morceaux = [(texte_protection(p).rstrip() + " ", (1, 1, 1)), (f"{texte_tarif(tarif)}€/MOIS", PROTECTION_JAUNE)]
        taille = 8.2
        while sum(f.text_length(t, taille) for t, _ in morceaux) + 8 > w - 6 and taille > 4:
            taille -= 0.1
        lg = sum(f.text_length(t, taille) for t, _ in morceaux)
        py0, py1 = y1 - 15, y1 - 3.5
        page.draw_rect(m.r((x0 + x1) / 2 - lg / 2 - 4, py0, (x0 + x1) / 2 + lg / 2 + 4, py1), color=None,
                       fill=PROTECTION_FOND, radius=0.35)
        x = (x0 + x1) / 2 - lg / 2
        for t, coul in morceaux:
            _texte(page, m, x, (py0 + py1) / 2 + taille * 0.36, t, taille, coul, f)
            x += f.text_length(t, taille)


def differences_versions(p1: Produit, p2: Produit) -> tuple[bool, bool]:
    """(capacités différentes, réseaux différents) : ce qui passe dans le titre de chaque version."""
    capa = _capacite(p1.nom_affiche) != _capacite(p2.nom_affiche)
    res = bool(_reseau(p1) and _reseau(p2) and _reseau(p1) != _reseau(p2))
    return capa, res


LARG_NOM_COLONNE = 122.0              # nom sous chaque produit (affiche double, deux téléphones différents)


def _nom_colonne(nom: str) -> tuple[list[str], float]:
    """Nom pour une demi-largeur : une ligne si possible, sinon deux, jamais coupé dans un mot."""
    f = police()
    for t in (11.0, 10.5, 10.0, 9.5, 9.0):
        if f.text_length(nom, t) <= LARG_NOM_COLONNE:
            return [nom], t
    mots = nom.split()
    t = 10.0
    while t >= NOM_TAILLE_MIN:
        meilleur = None
        for i in range(1, len(mots)):
            a, b = " ".join(mots[:i]), " ".join(mots[i:])
            w = max(f.text_length(a, t), f.text_length(b, t))
            if w <= LARG_NOM_COLONNE and (meilleur is None or w < meilleur[0]):
                meilleur = (w, a, b)
        if meilleur:
            return [meilleur[1], meilleur[2]], t
        t -= 0.25
    return [nom], NOM_TAILLE_MIN


def _ecrire_lignes(page, m: _Mise, cx: float, lignes: list[str], t: float) -> None:
    """Lignes centrées sur cx dans la zone du nom (entre l'encadré et les pictogrammes)."""
    inter = t * 1.08
    centre = (NOM_ZONE_HAUT + NOM_ZONE_BAS) / 2
    b1 = centre - inter * (len(lignes) - 1) / 2 + t * 0.35
    for k, l in enumerate(lignes):
        _texte(page, m, cx, b1 + k * inter, l, t, (0, 0, 0), centre=True)


def modeles_differents(p1: Produit, p2: Produit) -> bool:
    """Deux téléphones différents (pas seulement deux versions du même) : chacun garde son nom."""
    from .coloris import cle_famille
    f1, f2 = cle_famille(p1.nom_site or p1.nom_affiche), cle_famille(p2.nom_site or p2.nom_affiche)
    return bool(f1 and f2 and f1 != f2)


def _sans_differences(nom: str, capa: bool, res: bool) -> str:
    if capa:
        nom = _CAPA.sub("", nom)
    if res:
        nom = _RESEAU.sub("", nom)
    return " ".join(nom.split())


def libelle_version(p1: Produit, p2: Produit, k: int) -> str:
    """« Version 1 / 2 » pour le même téléphone (ex. iPhone 13 128 et 256 Go),
    « Produit 1 / 2 » pour deux téléphones différents (ex. iPhone 13 et Galaxy S22)."""
    return ("Produit" if modeles_differents(p1, p2) else "Version") + f" {k + 1}"


def nom_deux_versions(p1: Produit, p2: Produit) -> str:
    """Nom imprimé sur l'affiche double, sans capacité ni réseau (ils sont dans le titre de chaque version) ;
    deux téléphones différents : les deux noms, un par ligne avec un tiret."""
    if modeles_differents(p1, p2):
        return "\n".join("– " + _sans_differences(p.nom_affiche, True, True) for p in (p1, p2))
    return _sans_differences(p1.nom_affiche, True, True)


REF_BASE = 473.5                      # « Réf. … » en petit, sous « RETIREZ VOTRE PRODUIT EN CAISSE »


def _dessiner_reference(page, m: _Mise, dx: float, produit: Produit) -> None:
    if not produit.mentions.afficher_code:
        return
    codes = [produit.code] + ([produit.version2.code] if produit.version2 is not None else [])
    _texte(page, m, CENTRE_X + dx, REF_BASE, "Réf. " + " · ".join(codes), 6.0, (0.42, 0.44, 0.48), centre=True)


def _ajouter_page_deux_versions(doc: pymupdf.Document, p1: Produit, p2: Produit) -> MiseEnFormeNom:
    from .reglages import disposition_deux_versions
    if not p1.photo or not Path(p1.photo).is_file():
        raise ValueError(f"{p1.code} : aucune photo disponible")
    if not p1.nom_affiche.strip():
        raise ValueError(f"{p1.code} : aucun nom à afficher")
    m = _mise_en_page()
    page = doc.new_page(width=A4_L, height=A4_H)
    poser_fond(page, m, p1.mentions.boite, sans_pictos=est_jeu(p1) and est_jeu(p2))
    # bandeau vert « RECONDITIONNÉ » au-dessus de CHAQUE téléphone reconditionné (case dans « Modifier »)
    # « RECONDITIONNÉ » : un bandeau au-dessus de chaque téléphone reconditionné
    r1, r2 = p1.mentions.reconditionne, p2.mentions.reconditionne
    recond = False                                    # toujours un bandeau par téléphone (même modèle aussi)
    haut = 167.0 if recond else 150.0
    from .reglages import genre_deux_versions
    empile = disposition_deux_versions(genre_deux_versions(p1, p2)) == "empile"
    milieu = haut + (361 - haut) / 2
    HB = BANDEAU_BAS - BANDEAU_HAUT + 3              # place prise par un bandeau au-dessus d'une photo
    bandeaux = []                                     # [(centre x, haut)] des bandeaux à dessiner
    # une photo par version, en face de son encadré (une seule si la 2e version n'a pas de photo)
    deux_photos = bool(p2.photo) and Path(p2.photo).is_file()
    if deux_photos and empile:
        zones = [(114, haut + (HB if r1 else 0), 226, milieu - 2), (114, milieu + 2 + (HB if r2 else 0), 226, 361)]
        bandeaux = [(170, y) for r, y in ((r1, haut), (r2, milieu + 2)) if r]
        sources = [p1, p2]
    elif deux_photos:
        h = haut + (HB if (r1 or r2) else 0)          # photos alignées, même si un seul bandeau
        zones = [(114, h, 236, 270), (245, h, 367, 270)]
        bandeaux = [(cx, haut) for r, cx in ((r1, 175), (r2, 306)) if r]
        sources = [p1, p2]
    else:
        h = haut + (HB if (r1 or r2) else 0)
        zones = [(114, h, 226, 360) if empile else (130, h, 352, 270)]
        bandeaux = [(170 if empile else CENTRE_X, haut)] if (r1 or r2) else []
        sources = [p1]
    photos = []                                       # [(rect modèle, octets)]
    for src, zone in zip(sources, zones):
        with Image.open(src.photo) as im:
            im.load()
            rect, im_pose = _placer_photo(im, src.cadrage, zone)
        photos.append((rect, _image_en_octets(im_pose)))
    capa, res = differences_versions(p1, p2)
    melange = False                                   # « Reconditionné » : bandeau au-dessus de chaque photo
    noms_sous = None
    if modeles_differents(p1, p2) and not empile:      # côte à côte : chaque nom sous son produit
        noms_sous = [_nom_colonne(_sans_differences(p.nom_affiche, True, True)) for p in (p1, p2)]
        mf = MiseEnFormeNom([n for l, _ in noms_sous for n in l], noms_sous[0][1], True, False)
    elif modeles_differents(p1, p2):                   # empilées : un nom par ligne, dans l'ordre des encadrés
        noms = [_sans_differences(p.nom_affiche, True, True) for p in (p1, p2)]
        t = 12.0
        while t > NOM_TAILLE_MIN and max(police().text_length(n, t) for n in noms) > NOM_LARGEUR_MAX:
            t -= 0.25
        mf = MiseEnFormeNom(noms, t, True, max(police().text_length(n, t) for n in noms) > NOM_LARGEUR_MAX)
    else:
        mf = mettre_en_forme_nom(nom_deux_versions(p1, p2))
    xrefs = [0] * len(photos)
    for dx in (0.0, DECALAGE_AFFICHE_2):
        for k, ((x0, y0, x1, y1), data) in enumerate(photos):
            rect = m.r(x0 + dx, y0, x1 + dx, y1)
            if xrefs[k]:
                page.insert_image(rect, xref=xrefs[k])
            else:
                xrefs[k] = page.insert_image(rect, stream=data)
        for bx, by in bandeaux:
            t, taille = "RECONDITIONNÉ", 10.5
            w = police().text_length(t, taille) + 26
            cx = bx + dx
            page.draw_rect(m.r(cx - w / 2, by, cx + w / 2, by + BANDEAU_BAS - BANDEAU_HAUT), color=None,
                           fill=VERT_BADGE, radius=0.5)
            _texte(page, m, cx, by + (BANDEAU_BAS - BANDEAU_HAUT) / 2 + taille * 0.36, t, taille,
                   (1, 1, 1), centre=True)
        if recond:
            t, taille = "RECONDITIONNÉ", 10.5
            w = police().text_length(t, taille) + 26
            cx = CENTRE_X + dx
            page.draw_rect(m.r(cx - w / 2, BANDEAU_HAUT, cx + w / 2, BANDEAU_BAS), color=None,
                           fill=VERT_BADGE, radius=0.5)
            _texte(page, m, cx, BANDEAU_HAUT + (BANDEAU_BAS - BANDEAU_HAUT) / 2 + taille * 0.36, t, taille,
                   (1, 1, 1), centre=True)
        if empile:
            _carte_version(page, m, 230 + dx, haut, 368 + dx, milieu - 2, p1, capa, res, melange)
            _carte_version(page, m, 230 + dx, milieu + 2, 368 + dx, 361, p2, capa, res, melange)
        else:
            _carte_version(page, m, 112 + dx, 274, 238 + dx, 361, p1, capa, res, melange)
            _carte_version(page, m, 243 + dx, 274, 369 + dx, 361, p2, capa, res, melange)
        if noms_sous:
            for (lignes, t), cx in zip(noms_sous, (175, 306)):
                _ecrire_lignes(page, m, cx + dx, lignes, t)
        else:
            _ecrire_nom(page, m, dx, mf)
        _dessiner_reference(page, m, dx, p1)
    _reperes_coupe(page, m)
    return mf


def creer_pdf(produits: list[Produit], destination: Path, titre: str = "Affiches") -> Path:
    doc = pymupdf.open()
    for p in produits:
        ajouter_page(doc, p)
    doc.set_metadata({"title": titre, "creator": "Dépôt Print", "producer": "Dépôt Print"})
    destination.parent.mkdir(parents=True, exist_ok=True)
    doc.save(destination, garbage=3, deflate=True)
    doc.close()
    return destination


def pdf_en_memoire(produits: list[Produit]) -> pymupdf.Document:
    doc = pymupdf.open()
    for p in produits:
        ajouter_page(doc, p)
    return doc


def pdf_affiches(produits: list[Produit], par_feuille: int = 2, pointilles: bool = True,
                 protection: bool = True) -> pymupdf.Document:
    """Le PDF des affiches avec les choix du panneau « Impression » :
    2 par feuille (A4 paysage, comme toujours) ou 1 par feuille (une grande affiche par A4 portrait),
    pointillés de coupe, bandeau protection / garantie (ou aucun)."""
    import copy as _copy
    global POINTILLES
    if not protection:
        sans = []
        for p in produits:
            q = _copy.deepcopy(p)
            for v in (q, q.version2):
                if v is not None:
                    v.mentions.protection = False
            sans.append(q)
        produits = sans
    POINTILLES = pointilles and par_feuille == 2
    try:
        doc = pdf_en_memoire(produits)
    finally:
        POINTILLES = True
    if par_feuille != 1:
        return doc
    grand = pymupdf.open()
    m = _mise_en_page()
    clip = m.r(*CADRE)
    W, H = A4_H, A4_L                                     # A4 portrait
    marge = 22
    k = min((W - 2 * marge) / clip.width, (H - 2 * marge) / clip.height)
    lw, lh = clip.width * k, clip.height * k
    zone = pymupdf.Rect((W - lw) / 2, (H - lh) / 2, (W + lw) / 2, (H + lh) / 2)
    for i in range(doc.page_count):
        pg = grand.new_page(width=W, height=H)
        pg.show_pdf_page(zone, doc, i, clip=clip)
        if pointilles:
            pg.draw_rect(zone, color=GRIS_COUPE, width=0.6, dashes="[4 3] 0")
    doc.close()
    return grand


# colonne de chaque version sur l'affiche à deux produits (photo + encadré), pour l'aide à la sélection
COLONNES_DUO = ((109.0, 146.0, 241.0, 365.0), (240.0, 146.0, 372.0, 365.0))


def apercu_png(produit: Produit, dpi: int = 90, une_seule: bool = False, surligner: int | None = None) -> bytes:
    """Image PNG de la feuille (ou d'une seule affiche) pour l'écran.
    surligner = 0 ou 1 : affiche à deux produits, la version en cours de modification est encadrée
    en orange et l'autre est estompée (écran seulement, jamais imprimé)."""
    doc = pdf_en_memoire([produit])
    page = doc[0]
    clip = None
    m = _mise_en_page()
    if surligner in (0, 1) and produit.version2 is not None:
        autre = COLONNES_DUO[1 - surligner]
        page.draw_rect(m.r(*autre), color=None, fill=(1, 1, 1), fill_opacity=0.6, overlay=True)
        x0, y0, x1, y1 = COLONNES_DUO[surligner]
        page.draw_rect(m.r(x0 + 1, y0 + 1, x1 - 1, y1 - 1), color=(1, 0.6, 0), width=3.2 * m.echelle,
                       radius=0.06, overlay=True)
    if une_seule:
        clip = m.r(*CADRE)
    png = page.get_pixmap(dpi=dpi, clip=clip, alpha=False).tobytes("png")
    doc.close()
    return png


# --- Fond et pictogrammes « dans la boîte » ---------------------------------------------
#
# Le fond reste la page du modèle. Pour colorer une case, on ne touche JAMAIS aux dessins :
#  1) fond aux cases blanches : seule la couleur de remplissage orange de la case « câble »
#     est remplacée par du blanc dans le modèle (même tracé, mêmes traits) ;
#  2) calque orange en mode « Produit » (Multiply) sur les cases incluses : le blanc devient
#     orange, les traits noirs restent noirs → rendu identique à la case orange d'origine.

ORANGE_MODELE = b"1 .67058828 .2509804 rg"
_fond_blanc_cache: pymupdf.Document | None = None
_calques: dict = {}


def _fond_cases_blanches() -> pymupdf.Document:
    global _fond_blanc_cache
    if _fond_blanc_cache is None:
        d = pymupdf.open(paths.TEMPLATE_PDF)
        for x in d[0].get_contents():
            flux = d.xref_stream(x)
            if ORANGE_MODELE in flux:
                d.update_stream(x, flux.replace(ORANGE_MODELE, b"1 1 1 rg"))
        _fond_blanc_cache = d
    return _fond_blanc_cache


def _cases_pictos(page: pymupdf.Page) -> list:
    """Les 10 cases (2 affiches × 5) : chargeur, câble, écouteurs, coque, écran."""
    c = [dr for dr in page.get_drawings()
         if dr.get("color") == (0.0, 0.0, 0.0) and abs((dr.get("width") or 0) - 1.5) < 0.01
         and 35 < dr["rect"].width < 38 and 37 < dr["rect"].height < 40 and dr["rect"].y0 > 395]
    c.sort(key=lambda d: (d["rect"].x0 > 420, d["rect"].x0))
    return c


def _chemin_pdf(dr, hauteur: float) -> str:
    out, pos = [], None
    f = lambda p: f"{p.x:.3f} {hauteur - p.y:.3f}"
    for it in dr["items"]:
        if it[0] in ("l", "c"):
            if pos is None or abs(pos.x - it[1].x) > 1e-3 or abs(pos.y - it[1].y) > 1e-3:
                out.append(f(it[1]) + " m")
            if it[0] == "l":
                out.append(f(it[2]) + " l")
                pos = it[2]
            else:
                out.append(f"{f(it[2])} {f(it[3])} {f(it[4])} c")
                pos = it[4]
        elif it[0] == "re":
            r = it[1]
            out.append(f"{r.x0:.3f} {hauteur - r.y1:.3f} {r.width:.3f} {r.height:.3f} re")
    return " ".join(out) + " h f"


def _calque_orange(inclus: tuple) -> pymupdf.Document:
    if inclus not in _calques:
        src = _fond_cases_blanches()[0]
        largeur, hauteur = src.rect.width, src.rect.height
        cases = _cases_pictos(src)
        ops = ["q /GM gs " + ORANGE_MODELE.decode()]
        ops += [_chemin_pdf(dr, hauteur) for k, dr in enumerate(cases) if (k % 5) in inclus]
        ops.append("Q")
        d = pymupdf.open()
        pg = d.new_page(width=largeur, height=hauteur)
        x = d.get_new_xref()
        d.update_object(x, "<<>>")
        d.update_stream(x, " ".join(ops).encode())
        d.xref_set_key(pg.xref, "Contents", f"{x} 0 R")
        d.xref_set_key(pg.xref, "Resources", "<</ExtGState <</GM <</Type /ExtGState /BM /Multiply>> >> >>")
        _calques[inclus] = d
    return _calques[inclus]


def est_jeu(p: Produit) -> bool:
    """Console ou manette : pas de pictogrammes « dans la boîte » (chargeur, écouteurs… de téléphone)."""
    import re as _re
    return bool(_re.match(r"\s*(console|manette)\b", p.nom_site or "", _re.I)
                or _re.match(r"\s*manette\b", p.nom_affiche or "", _re.I))


def poser_fond(page: pymupdf.Page, m: "_Mise", inclus=(1,), sans_pictos: bool = False) -> None:
    """Les deux affiches du modèle, découpées au bord du cadre et collées côte à côte.
    sans_pictos : consoles et manettes, la rangée de pictogrammes est recouverte de blanc."""
    fond = _fond_cases_blanches()
    inclus = tuple(sorted({int(k) for k in (inclus or []) if 0 <= int(k) <= 4}))
    calque = _calque_orange(inclus) if inclus else None
    for k in (0, 1):
        clip = pymupdf.Rect(CADRE[0] + k * DECALAGE_MODELE_2, CADRE[1], CADRE[2] + k * DECALAGE_MODELE_2, CADRE[3])
        cible = m.r(CADRE[0] + k * LARG_AFFICHE, CADRE[1], CADRE[2] + k * LARG_AFFICHE, CADRE[3])
        page.show_pdf_page(cible, fond, 0, clip=clip)
        if calque and not sans_pictos:
            page.show_pdf_page(cible, calque, 0, clip=clip)
        if sans_pictos:
            cases = [d["rect"] for d in _cases_pictos(fond[0]) if clip.x0 <= d["rect"].x0 < clip.x1]
            if cases:
                z = pymupdf.Rect(cases[0])
                for r in cases[1:]:
                    z |= r
                z = pymupdf.Rect(z.x0 - 3, z.y0 - 3, z.x1 + 3, z.y1 + 3)
                k_x, k_y = cible.width / clip.width, cible.height / clip.height
                page.draw_rect(pymupdf.Rect(cible.x0 + (z.x0 - clip.x0) * k_x, cible.y0 + (z.y0 - clip.y0) * k_y,
                                            cible.x0 + (z.x1 - clip.x0) * k_x, cible.y0 + (z.y1 - clip.y0) * k_y),
                               color=None, fill=(1, 1, 1), overlay=True)


def apercu_vide_png(dpi: int = 90) -> bytes:
    doc = pymupdf.open()
    m = _mise_en_page()
    page = doc.new_page(width=A4_L, height=A4_H)
    poser_fond(page, m, (1,))
    _reperes_coupe(page, m)
    png = page.get_pixmap(dpi=dpi, alpha=False).tobytes("png")
    doc.close()
    return png
