"""Nom affiché et mentions (reconditionné, état, batterie neuve, coloris).

Exemples tirés du site :
  « Smartphone SAMSUNG Galaxy A57 5G 128Go Graphite »
      → nom « SAMSUNG A57 5G 128 GO »
  « APPLE iPhone 15 128Go Noir Reconditionné Excellent état BATTERIE NEUVE »
      → nom « APPLE IPHONE 15 128 GO »
        + bandeau « RECONDITIONNÉ · EXCELLENT ÉTAT » + « BATTERIE NEUVE » + « PLUSIEURS COLORIS »
La capacité est toujours gardée. Le nom et les mentions restent modifiables à la main.
"""

from __future__ import annotations

import re

from .models import Mentions

_PREFIXES = re.compile(
    r"^\s*(smartphone|tablette(\s+tactile)?|t[ée]l[ée]phone(\s+mobile)?|mobile|portable)\s+", re.I
)
# « 8/256Go » ou « 8Go/256Go » → on garde le stockage (256)
_RAM_STOCKAGE = re.compile(r"\b\d+\s?(?:go|gb)?\s?/\s?(\d+)\s?(go|gb|to|tb)\b", re.I)
_CAPACITE = re.compile(r"\b(\d+)\s?(go|gb|to|tb)\b", re.I)

# États tels qu'écrits sur le site (du plus long au plus court)
_ETATS = [
    (r"comme\s+neuf", "COMME NEUF"),
    (r"parfait\s+[ée]tat", "PARFAIT ÉTAT"),
    (r"excellent\s+[ée]tat", "EXCELLENT ÉTAT"),
    (r"tr[èe]s\s+bon\s+[ée]tat", "TRÈS BON ÉTAT"),
    (r"bon\s+[ée]tat", "BON ÉTAT"),
    (r"[ée]tat\s+correct", "ÉTAT CORRECT"),
    # grades du site ramenés aux deux états utilisés en magasin
    (r"grade\s+a\s*\+", "EXCELLENT ÉTAT"),
    (r"grade\s+a\b", "EXCELLENT ÉTAT"),
    (r"grade\s+[ée]co\b", "ÉTAT CORRECT"),
    (r"\b[ée]co\b", "ÉTAT CORRECT"),
]
_BATTERIE = re.compile(r"\bbatterie\s+neuve\b", re.I)
_RECOND = re.compile(r"\breconditionn[ée]e?s?\b", re.I)

_COULEURS = [
    "lumière stellaire", "lumiere stellaire", "titane naturel", "titane noir",
    "titane blanc", "titane désert", "titane desert", "titane bleu", "titane gris",
    "bleu nuit", "bleu glacier", "bleu alpin", "vert menthe", "vert alpin", "vert d'eau",
    "gris sidéral", "gris sideral", "rose poudré", "(product)red", "product red",
    "noir", "blanc", "bleu", "vert", "rose", "gris", "graphite", "argent",
    "or", "doré", "violet", "lavande", "menthe", "jaune", "rouge", "minuit",
    "orange", "crème", "creme", "beige", "corail", "turquoise", "marine",
    "anthracite", "silver", "black", "white", "blue", "green", "gold",
    "purple", "pink", "grey", "gray", "titanium", "midnight", "starlight",
    "lime", "olive", "sable", "ivoire", "bronze", "cuivre", "ciel", "lilas",
    "aqua", "ocean", "océan", "sauge", "pêche", "peche", "prune", "titane",
]
_COULEURS.sort(key=len, reverse=True)
_NUANCES = ["clair", "claire", "foncé", "fonce", "foncée", "ciel", "nuit", "pastel", "mat", "glacier",
            "métallisé", "metallise", "intense", "profond", "sidéral", "sideral", "poudré", "light", "dark"]
_COUL = "(?:" + "|".join(re.escape(c) for c in sorted(_COULEURS + _NUANCES, key=len, reverse=True)) + ")"
_FIN_COULEUR = re.compile(r"(\s+" + _COUL + r")+\s*$", re.I)
_COULEUR_APRES_CAPACITE = re.compile(r"(\d+ (?:GO|TO))((?:\s+" + _COUL + r")+)(?=\s|$)", re.I)


def est_tablette(designation: str) -> bool:
    """Tablettes et iPad : pas de protection casse · vol · oxydation (réservée aux téléphones)."""
    return re.search(r"\b(tablette|ipad|galaxy\s+tab|tab\s+[a-z]?\d)", designation or "", re.I) is not None


def est_iphone(designation: str) -> bool:
    return re.search(r"\biphone\b", designation or "", re.I) is not None


def detecter_mentions(designation: str, attributs: dict | None = None) -> Mentions:
    """Lit la désignation du site (et ses attributs « reconditionné » s'il y en a)."""
    d = designation or ""
    a = attributs or {}
    attr_recond = any(str(a.get(k, "")).strip().lower() in ("1", "oui", "yes", "true", "reconditionné")
                      for k in ("reconditionne", "flap_reconditionne"))
    m = Mentions()
    m.reconditionne = bool(_RECOND.search(d)) or attr_recond
    if m.reconditionne:
        for motif, texte in _ETATS:
            if re.search(motif, d, re.I):
                m.etat = texte
                break
    m.batterie_neuve = bool(_BATTERIE.search(d))
    m.coloris = est_iphone(d)
    m.iphone = est_iphone(d)
    m.protection = not est_tablette(d)
    return m


_JEU = re.compile(r"^\s*(console|manette)\b", re.I)
_COULEURS_JEU = re.compile(r"\b(?:" + _COUL + r"|blanche|noire|verte|grise|violette|carbon|cosmic|"
                           r"galactic|midnight|volcanic|sterling|chroma|camouflage|camo)\b", re.I)


def _nom_jeu(s: str) -> str:
    """« Console de jeux SONY PS5 Digitale 825Go Blanc » → « SONY PS5 DIGITALE 825 GO » ;
    « Manette sans fil SONY DualSense Blanche PS5 » → « MANETTE SONY DUALSENSE PS5 »."""
    s = re.sub(r"^\s*console(\s+de\s+jeux?)?(\s+vid[ée]o)?(\s+portable)?\s+", "", s, flags=re.I)
    s = re.sub(r"^\s*manette(\s+de\s+jeux?)?(\s+sans\s+fil)?\s+", "MANETTE ", s, flags=re.I)
    s = re.sub(r"\bsans\s+fil\b", " ", s, flags=re.I)
    s = _COULEURS_JEU.sub(" ", s)
    return re.sub(r"\s{2,}", " ", s).strip()


def nom_court(designation: str) -> str:
    s = (designation or "").strip()
    if not s:
        return ""
    s = re.split(r"\s\+\s", s)[0]          # « … + Batterie de secours » (lot)
    s = _PREFIXES.sub("", s)
    if _JEU.match(s):                                 # consoles et manettes
        s = _nom_jeu(s)
    s = re.sub(r"\bSAMSUNG\s+Galaxy\b", "SAMSUNG", s, flags=re.I)
    # tablettes : taille d'écran et « Wi-fi » retirées (« Tablette 11\" … Wi-fi/6Go/128Go »)
    s = re.sub(r"\b\d{1,2}(?:[.,]\d{1,2})?\s?(?:\"|''|pouces\b)", " ", s, flags=re.I)
    s = re.sub(r"\bwi-?fi\b", " ", s, flags=re.I)
    # mentions affichées en badges : retirées du nom
    s = _BATTERIE.sub(" ", s)
    s = _RECOND.sub(" ", s)
    for motif, _ in _ETATS:
        if re.search(motif, s, re.I) and _RECOND.search(designation):
            s = re.sub(motif, " ", s, flags=re.I)
            break
    # capacité : gardée et écrite proprement (« 128Go » → « 128 GO »)
    s = _RAM_STOCKAGE.sub(lambda mm: f"{mm.group(1)} {mm.group(2)}", s)
    s = _CAPACITE.sub(lambda mm: f"{mm.group(1)} {_unite(mm.group(2))}", s)
    s = re.sub(r"(^|\s)/+|/+(\s|$)", " ", s)              # barres orphelines
    s = re.sub(r"\s{2,}", " ", s).strip(" -–,·")
    # couleur : juste après la capacité, ou en fin de nom
    s = _COULEUR_APRES_CAPACITE.sub(lambda mm: mm.group(1), s)
    s = _FIN_COULEUR.sub("", s)
    s = re.sub(r"\s{2,}", " ", s).strip(" -–,·")
    return s.upper() if s else designation.strip().upper()


def _unite(u: str) -> str:
    return "TO" if u.lower() in ("to", "tb") else "GO"
