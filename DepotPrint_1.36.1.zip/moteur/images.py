"""Préparation des photos produit (lecture, fond blanc, recadrage des marges)."""

from __future__ import annotations

import io
from pathlib import Path

from PIL import Image, ImageChops, ImageOps

TAILLE_MIN = 400      # en dessous : image de remplacement ou trop floue
TAILLE_MAX = 2000     # au-delà, inutile pour l'impression


class ImageInvalide(Exception):
    pass


def ouvrir(data: bytes) -> Image.Image:
    try:
        im = Image.open(io.BytesIO(data))
        im.load()
    except Exception as e:  # format illisible
        raise ImageInvalide(f"image illisible ({e})") from e
    return ImageOps.exif_transpose(im)


def sur_fond_blanc(im: Image.Image) -> Image.Image:
    if im.mode in ("RGBA", "LA") or (im.mode == "P" and "transparency" in im.info):
        im = im.convert("RGBA")
        fond = Image.new("RGB", im.size, (255, 255, 255))
        fond.paste(im, mask=im.getchannel("A"))
        return fond
    return im.convert("RGB")


def rogner_marges(im: Image.Image, seuil: int = 244, marge: float = 0.01) -> Image.Image:
    """Retire les bordures blanches pour que le produit remplisse la zone."""
    gris = im.convert("L")
    masque = gris.point(lambda v: 255 if v < seuil else 0)
    boite = masque.getbbox()
    if not boite:
        return im
    l, t, r, b = boite
    m = int(max(im.size) * marge)
    boite = (max(0, l - m), max(0, t - m), min(im.width, r + m), min(im.height, b + m))
    return im.crop(boite)


def preparer(data: bytes, destination: Path, verifier_taille: bool = True) -> Path:
    """Lit une photo, la vérifie, la nettoie et l'enregistre en PNG sans perte."""
    im = ouvrir(data)
    if verifier_taille and max(im.size) < TAILLE_MIN:
        raise ImageInvalide(
            f"image trop petite ({im.width}×{im.height} px) : probablement une image "
            "de remplacement du site ou une vignette"
        )
    im = sur_fond_blanc(im)
    im = rogner_marges(im)
    if max(im.size) > TAILLE_MAX:
        im.thumbnail((TAILLE_MAX, TAILLE_MAX), Image.LANCZOS)
    destination.parent.mkdir(parents=True, exist_ok=True)
    im.save(destination, "PNG", optimize=True)
    return destination


def preparer_fichier(source: Path, destination: Path) -> Path:
    return preparer(Path(source).read_bytes(), destination, verifier_taille=False)


def est_uni(data: bytes) -> bool:
    """Vrai si l'image est quasi uniforme (image vide de remplacement)."""
    im = sur_fond_blanc(ouvrir(data)).convert("L")
    extrema = ImageChops.difference(im, Image.new("L", im.size, im.getpixel((0, 0)))).getbbox()
    return extrema is None
