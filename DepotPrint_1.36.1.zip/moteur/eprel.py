"""EPREL : base officielle européenne des étiquettes énergie (règlement UE 2023/1669).

https://eprel.ec.europa.eu — publique, sans clé. On y trouve, pour chaque modèle de
smartphone ou de tablette, l'étiquette officielle en PDF vectoriel : bien plus nette à
l'impression que l'image du site Electro Dépôt.

Le site Electro Dépôt ne donne pas la référence exacte du modèle (ex. « XT2535-3 »).
On cherche donc par marque + nom du modèle, puis on ne garde que les fiches qui
correspondent au nom ET à la classe énergétique du catalogue. Une seule fiche possible :
elle est utilisée. Plusieurs (même modèle vendu sous plusieurs références) ou aucune :
on garde l'image Electro Dépôt, et le bon numéro peut être choisi dans « Modifier ».
Jamais de devinette : une étiquette qui n'est pas sûrement la bonne n'est pas imprimée.
"""
from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path

import requests

API = "https://eprel.ec.europa.eu/api/products/smartphonestablets20231669"
PAGE = "https://eprel.ec.europa.eu/screen/product/smartphonestablets20231669/{numero}"
TIMEOUT = (6, 20)
REESSAI_JOURS = 7          # « pas trouvé » : on retente une semaine plus tard (fiches ajoutées)

# mots qui changent de modèle : « G06 » n'est pas « G06 Power », « A56 » n'est pas « A56 Pro »
QUALIFICATIFS = {"power", "pro", "max", "plus", "ultra", "lite", "fe", "mini", "neo", "prime", "play",
                 "edge", "fusion", "stylus", "note", "air", "flip", "fold", "turbo", "gt", "se", "s", "x"}
MOTS_IGNORES = {"smartphone", "tablette", "telephone", "téléphone", "mobile", "galaxy", "redmi", "moto",
                "reconditionne", "reconditionné", "recond", "neuf", "dual", "sim", "wifi", "wi-fi",
                "cellular", "4g", "5g", "lte", "et", "avec", "+"}


class EprelInjoignable(Exception):
    """EPREL ne répond pas (pas d'Internet, site en maintenance, accès bloqué)."""


@dataclass
class Fiche:
    numero: str
    modele: str
    marque: str
    classe: str
    heures: float
    cycles: str
    chutes: str
    reparabilite: str
    ip: str
    type: str                  # SMARTPHONE / TABLET

    @property
    def libelle(self) -> str:
        h = f"{self.heures:g} h".replace(".", ",") if self.heures else ""
        return " · ".join(x for x in (self.modele, f"classe {self.classe}" if self.classe else "", h) if x)

    @property
    def contenu(self) -> tuple:
        """Ce qui est imprimé sur l'étiquette (hors référence du modèle)."""
        return (self.classe, self.heures, self.cycles, self.chutes, self.reparabilite, self.ip)


def _fiche(h: dict) -> Fiche:
    return Fiche(str(h.get("eprelRegistrationNumber") or ""), " ".join(str(h.get("modelIdentifier") or "").split()),
                 str(h.get("supplierOrTrademark") or ""), str(h.get("energyClass") or ""),
                 float(h.get("batteryEndurancePerCycleInHours") or 0), str(h.get("batteryEnduranceInCycles") or ""),
                 str(h.get("repeatedFreeFallReliabilityClass") or ""), str(h.get("repairabilityClass") or ""),
                 str(h.get("ingressProtectionRating") or ""), str(h.get("deviceType") or ""))


# -- accès au site -------------------------------------------------------------------------------
_session: requests.Session | None = None
_panne_jusqua = 0.0          # après une panne : on n'insiste pas pendant 10 minutes (lots de 50 produits)


def _get(url: str, params: dict | None = None, accept: str = "application/json") -> requests.Response:
    global _session, _panne_jusqua
    if time.monotonic() < _panne_jusqua:
        raise EprelInjoignable("EPREL injoignable pour l'instant")
    if _session is None:
        _session = requests.Session()
        from .electrodepot import USER_AGENT
        # sans « Referer », la recherche EPREL répond 403 (Forbidden) : le site l'exige
        _session.headers.update({"User-Agent": USER_AGENT, "Accept-Language": "fr-FR,fr;q=0.9",
                                 "Referer": "https://eprel.ec.europa.eu/screen/product/smartphonestablets20231669"})
    try:
        r = _session.get(url, params=params, timeout=TIMEOUT, headers={"Accept": accept})
    except requests.RequestException as e:
        _panne_jusqua = time.monotonic() + 600
        _journal(f"EPREL injoignable : {e!r}")
        raise EprelInjoignable(f"EPREL injoignable ({type(e).__name__})") from e
    if r.status_code in (401, 403, 429) or r.status_code >= 500:
        _panne_jusqua = time.monotonic() + 600
        _journal(f"EPREL refuse la demande ({r.status_code}) : {r.url} -> {r.text[:200]!r}")
        raise EprelInjoignable(f"EPREL refuse la demande ({r.status_code})")
    return r


def _journal(texte: str) -> None:
    """Problème EPREL : noté dans erreurs.log (jamais de plantage)."""
    try:
        from .paths import data_dir
        with (data_dir() / "erreurs.log").open("a", encoding="utf-8") as f:
            f.write(f"{datetime.now():%d/%m/%Y %H:%M:%S}  {texte}\n")
    except OSError:
        pass


def chercher(marque: str, modele: str = "") -> list[Fiche]:
    """Fiches publiées de la marque (dont la référence contient « modele », si donné)."""
    fiches: dict[str, Fiche] = {}
    for motif in ([modele.lower(), modele.upper()] if modele else [""]):
        for page in range(1, 6):
            params = {"_page": page, "_limit": 100, "supplierOrTrademark": marque.lower()}
            if motif:
                params["modelIdentifier"] = f"*{motif}*"
            r = _get(API, params)
            if r.status_code != 200:
                break
            try:
                hits = r.json().get("hits") or []
            except ValueError:
                break
            for h in hits:
                if h.get("status") in (None, "PUBLISHED") and not h.get("blocked"):
                    f = _fiche(h)
                    if f.numero:
                        fiches[f.numero] = f
            if len(hits) < 100:
                break
        if fiches:
            break
    return list(fiches.values())


def telecharger_pdf(numero: str, dest: Path) -> Path:
    """Étiquette officielle en PDF (vectoriel)."""
    numero = re.sub(r"\D", "", numero or "")
    if not numero:
        raise ValueError("numéro EPREL vide")
    r = _get(f"{API}/{numero}/labels", {"format": "PDF"}, accept="application/pdf")
    if r.status_code == 404:
        raise LookupError(f"aucune étiquette EPREL n° {numero}")
    if r.status_code != 200 or not r.content.startswith(b"%PDF"):
        raise LookupError(f"étiquette EPREL n° {numero} illisible ({r.status_code})")
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(".tmp")
    tmp.write_bytes(r.content)
    tmp.replace(dest)
    return dest


# -- correspondance produit Electro Dépôt -> fiche EPREL ---------------------------------------
def _mots(texte: str) -> list[str]:
    return [m for m in re.split(r"[^0-9a-zà-ÿ]+", (texte or "").lower()) if m]


def marque_de(article: dict) -> str:
    m = ((article.get("attributs") or {}).get("brand") or "").strip()
    m = re.sub(r"\s+(RECOND\w*|RECONDITIONN\w*)$", "", m.upper()).strip()
    if not m:
        mots = [x for x in (article.get("nom") or "").split() if x.isupper() and len(x) > 1]
        m = mots[0] if mots else ""
    return m


def mots_du_nom(nom: str, marque: str) -> list[str]:
    """Mots qui désignent le modèle : « Smartphone MOTOROLA G06 256Go 4G Bleu » -> ['g06', 'bleu']."""
    exclus = MOTS_IGNORES | set(_mots(marque))
    return [m for m in _mots(nom) if m not in exclus and not re.fullmatch(r"\d+(go|to|gb|tb|mo)", m)]


def cle_modele(mots: list[str]) -> str:
    """Le mot « code » du modèle : lettres + chiffres (g06, a17, s25). Un nombre seul (« 17 »)
    est trop vague (les références Apple sont « A3290 ») : pas de recherche automatique."""
    for m in mots:
        if re.search(r"[a-z]", m) and re.search(r"\d", m) and len(m) >= 2:
            return m
    return ""


def compatible(f: Fiche, mots: list[str], cle: str) -> bool:
    base = f.modele.split("(")[0]                       # « g06 power (XT2535-9) » -> « g06 power »
    mb = _mots(base)
    if not any(cle in m for m in mb):
        return False
    noms = set(mots)
    for m in mb:                                        # un mot de la fiche absent du nom = autre modèle
        if m in QUALIFICATIFS and m not in noms:
            return False
        if re.fullmatch(r"[a-z]{4,}", m) and m not in noms and m not in MOTS_IGNORES:
            return False
    for m in noms & QUALIFICATIFS:                      # « G06 Power » ne doit pas trouver « g06 »
        if m not in mb:
            return False
    return True


def candidats(article: dict) -> list[Fiche]:
    """Fiches EPREL possibles pour un article du catalogue (nom, marque, classe énergétique)."""
    marque = marque_de(article)
    nom = article.get("nom") or ""
    mots = mots_du_nom(nom, marque)
    cle = cle_modele(mots)
    if not marque or not cle:
        return []
    classe = ((article.get("attributs") or {}).get("classe_energetique") or "").strip().upper()
    tablette = bool(re.search(r"tablette|ipad|\btab\b", nom.lower()))
    res = []
    for f in chercher(marque, cle):
        if not compatible(f, mots, cle):
            continue
        if classe and f.classe and f.classe.upper() != classe:
            continue
        if f.type and (f.type == "TABLET") != tablette:
            continue
        res.append(f)
    return sorted(res, key=lambda f: f.modele)


# -- mémoire : quel numéro pour quel code ------------------------------------------------------
def _fichier_memoire() -> Path:
    from .energie import dossier
    return dossier() / "eprel.json"


def memoire() -> dict:
    try:
        return json.loads(_fichier_memoire().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _ecrire(m: dict) -> None:
    f = _fichier_memoire()
    tmp = f.with_suffix(".tmp")
    tmp.write_text(json.dumps(m, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(f)


def noter(code: str, **infos) -> None:
    m = memoire()
    d = {k: v for k, v in (m.get(code) or {}).items() if k == "choix"}     # le choix manuel reste
    d.update(infos, date=datetime.now().isoformat(timespec="seconds"))
    m[code] = d
    _ecrire(m)


def choix(code: str) -> str:
    """Choix fait dans « Modifier » : '' automatique, 'site' image Electro Dépôt, sinon n° EPREL."""
    return (memoire().get(code) or {}).get("choix", "")


def choisir(code: str, valeur: str) -> None:
    m = memoire()
    d = m.get(code) or {}
    if (d.get("choix") or "") == valeur:
        return
    if valeur:
        d["choix"] = valeur
    else:
        d.pop("choix", None)
    d.pop("numero", None)                     # la recherche automatique sera refaite
    d.pop("aucun", None)
    m[code] = d
    _ecrire(m)


def a_retenter(info: dict) -> bool:
    try:
        return datetime.now() - datetime.fromisoformat(info.get("date", "")) > timedelta(days=REESSAI_JOURS)
    except ValueError:
        return True
