"""Point d'entrée unique pour obtenir un produit : cache local d'abord, puis le site.

Utilisé par l'interface (un produit ou plusieurs). Toutes les fonctions qui
touchent au réseau sont lentes : l'interface les appelle hors du fil principal.
"""

from __future__ import annotations

import copy

import csv
import io
import re
from dataclasses import dataclass
from pathlib import Path

from . import images, paths
from .base import Base
from .electrodepot import ClientElectroDepot, Resultat, normaliser_code
from .models import Cadrage, ErreurRecherche, Produit
from .noms import detecter_mentions, nom_court


@dataclass
class Reponse:
    produit: Produit
    depuis_cache: bool
    avertissement: str = ""
    origine: str = ""          # "catalogue" : trouvé dans le catalogue hors ligne
    retire: str = ""           # date à laquelle le produit a disparu du site ('' = toujours en ligne)


class Catalogue:
    def __init__(self) -> None:
        self.dossier = paths.data_dir()
        self.base = Base(self.dossier / "produits.sqlite")
        self.client = ClientElectroDepot()

    def chemin_photo(self, code: str, suffixe: str = "") -> Path:
        sur = re.sub(r"[^A-Za-z0-9_-]", "_", code)
        return self.dossier / "photos" / f"{sur}{suffixe}.png"

    # -- recherche -----------------------------------------------------------------
    def obtenir(self, code: str, forcer_site: bool = False, _dans_paire: bool = False) -> Reponse:
        morceaux = (code or "").split()
        if "+" not in (code or "") and len(morceaux) == 2 and all(len(m) >= 5 for m in morceaux):
            code = " + ".join(morceaux)          # « 992826 10020472 » : deux codes, pas un seul
        if "+" in (code or ""):
            return self._obtenir_deux(code, forcer_site)
        r = self._obtenir_un(code, forcer_site)
        if not _dans_paire:                       # historique : affiche d'un produit seul
            try:
                self.base.noter_seul(r.produit.code)
            except Exception:
                pass
        return r

    def _obtenir_un(self, code: str, forcer_site: bool = False) -> Reponse:
        code = normaliser_code(code)
        connu = self.base.produit(code)
        # 1) catalogue hors ligne : aucune connexion nécessaire
        art = None if forcer_site else self.base.article(code)
        if art and art.get("photo") and Path(paths.retrouver_photo(art["photo"])).is_file():
            return Reponse(self._depuis_catalogue(art, connu), True, "", "catalogue", art.get("retire") or "")
        # enregistré par une version précédente (sans prix ou sans coloris) : relu une fois sur le site
        a_completer = (connu is not None and connu.source in ("electrodepot.fr", "catalogue hors ligne")
                       and (not connu.prix or not connu.mentions.variantes))
        if connu and not forcer_site and not a_completer and connu.photo and Path(connu.photo).is_file():
            return Reponse(connu, True, connu.avertissement)
        try:
            res = self.client.rechercher(code)
        except ErreurRecherche:
            # hors ligne / site indisponible : on garde ce qu'on a, s'il y a quelque chose
            if connu and connu.pret and Path(connu.photo).is_file():
                return Reponse(connu, True, "Site injoignable : informations enregistrées utilisées.")
            raise
        return Reponse(self._depuis_resultat(res, connu), False, res.avertissement)

    def _obtenir_deux(self, texte: str, forcer_site: bool) -> Reponse:
        """« 10017363 + 10020472 » : deux versions du même téléphone sur une seule affiche."""
        codes = [c for c in (x.strip() for x in texte.split("+")) if c]
        if len(codes) != 2:
            raise ErreurRecherche("Deux codes maximum par affiche, séparés par « + ».")
        if normaliser_code(codes[0]) == normaliser_code(codes[1]):
            raise ErreurRecherche("Les deux codes sont identiques.")
        r1 = self.obtenir(codes[0], forcer_site, _dans_paire=True)
        try:
            r2 = self.obtenir(codes[1], forcer_site, _dans_paire=True)
        except ErreurRecherche as e:
            raise ErreurRecherche(f"2e code ({codes[1]}) : {e}") from e
        p = copy.copy(r1.produit)
        p.version2 = r2.produit
        try:
            self.base.noter_paire(r1.produit.code, r2.produit.code)     # historique : une affiche, deux produits
        except Exception:
            pass
        avert = " · ".join(a for a in (r1.avertissement, r2.avertissement and f"2e code : {r2.avertissement}") if a)
        return Reponse(p, r1.depuis_cache and r2.depuis_cache, avert, r1.origine if r1.origine == r2.origine else "",
                       r1.retire or r2.retire)

    def couleurs_connues(self, p: Produit) -> list[dict]:
        """Couleurs déjà vues pour ce téléphone (retirées du site, autres capacités ou états)."""
        from .coloris import couleurs_connues
        art = self.base.article(p.code)
        return couleurs_connues(p.code, p.nom_site, art["coloris"] if art else "", self.base.tous_articles())

    def photo_couleur(self, p: Produit, couleur: str) -> str:
        """Photo du téléphone dans cette couleur, trouvée automatiquement : d'abord dans le catalogue
        (produits retirés, autres capacités ou états), puis sur le site. '' si rien n'est trouvé."""
        for c in self.couleurs_connues(p):
            if c["couleur"].lower() == couleur.lower() and c["photo"]:
                chemin = paths.retrouver_photo(c["photo"])
                if Path(chemin).is_file():
                    return str(chemin)
        try:                                             # sur le site (si Internet)
            from .coloris import cle_famille, couleur_produit, requete_modele
            famille = cle_famille(p.nom_site)
            for a in self.client.chercher(requete_modele(p.nom_site)):
                nom = a.get("name", "")
                if (cle_famille(nom, a.get("coloris", "")) == famille
                        and couleur_produit(nom, a.get("coloris", "")).lower() == couleur.lower()):
                    code = str(a.get("refCode") or a.get("sku") or "")
                    dest = self.chemin_photo(code)
                    if not dest.is_file():
                        data = self.client.telecharger_photo(Resultat(code=code, nom=nom, url_fiche="",
                                                                      url_image=a.get("imageUrl", "")))
                        images.preparer(data, dest)
                    return str(dest)
        except Exception:
            pass
        return ""

    def photos_couleurs(self, p: Produit) -> list[tuple]:
        """[(couleur, code, chemin de la photo)] pour choisir la couleur du téléphone sur l'affiche."""
        from .coloris import photos_par_couleur
        art = self.base.article(p.code)
        coloris = art["coloris"] if art else ""
        res = []
        for couleur, code, photo in photos_par_couleur(p.code, p.nom_site, coloris, self.base.articles_avec_photo()):
            if code == p.code:                      # sa propre photo (même si une autre couleur est choisie)
                propre = [paths.retrouver_photo(art["photo"])] if art and art.get("photo") else []
                propre.append(str(self.chemin_photo(p.code)))
                chemin = next((c for c in propre if c and Path(c).is_file()),
                              "" if p.mentions.photo_couleur else p.photo)
            else:
                chemin = paths.retrouver_photo(photo)
            if chemin and Path(chemin).is_file():
                res.append((couleur, code, str(chemin)))
        return res

    def depuis_fiche(self, url: str, code_attendu: str = "") -> Reponse:
        res = self.client.depuis_fiche(url, code_attendu)
        connu = self.base.produit(res.code)
        return Reponse(self._depuis_resultat(res, connu), False, res.avertissement)

    def choisir_candidat(self, code: str, url: str) -> Reponse:
        """Après une ambiguïté : l'utilisateur a désigné la bonne fiche."""
        return self.depuis_fiche(url, code_attendu=code)

    def _variantes(self, res: Resultat) -> list | None:
        """Couleurs et réseaux du même modèle sur le site (None si la vérification a échoué)."""
        from .coloris import requete_modele, variantes
        q = requete_modele(res.nom)
        if not q:
            return []
        try:
            produits = self.client.chercher(q)
        except ErreurRecherche:
            return None
        return variantes(res.code, res.nom, res.coloris, produits)

    def _depuis_catalogue(self, art: dict, connu: Produit | None) -> Produit:
        b = art.get("boite") or {}
        res = Resultat(code=art["code"], nom=art["nom"], url_fiche=art["url_fiche"], url_image=art["url_image"],
                       coloris=art["coloris"], attributs=art["attributs"], prix=art["prix"], verifie_fiche=True,
                       accessoires=b.get("acc", ""), description_boite=b.get("desc", ""), fiche_lue=bool(b))
        from .coloris import variantes
        # coloris recalculés sur tout le catalogue (toujours avec les règles les plus récentes)
        var = variantes(art["code"], art["nom"], art["coloris"], self.base.articles_pour_coloris())
        return self._depuis_resultat(res, connu, photo=paths.retrouver_photo(art["photo"]),
                                     var=var, source="catalogue hors ligne")

    @staticmethod
    def _photo_manuelle(connu: Produit | None, nom: str) -> bool:
        return bool(connu and connu.nom_site == nom and connu.photo and Path(connu.photo).is_file()
                    and ("manuellement" in (connu.avertissement or "") or connu.mentions.photo_couleur))

    def _depuis_resultat(self, res: Resultat, connu: Produit | None, photo: str | None = None,
                         var: list | None = None, source: str = "electrodepot.fr") -> Produit:
        if self._photo_manuelle(connu, res.nom):
            photo = connu.photo                      # photo choisie à la main : jamais écrasée
        elif photo is None:
            data = self.client.telecharger_photo(res)
            photo = str(images.preparer(data, self.chemin_photo(res.code)))
        avert = res.avertissement or (connu.avertissement if self._photo_manuelle(connu, res.nom)
                                      and "manuellement" in (connu.avertissement or "") else "")
        mentions = self._mentions(res, connu, var)
        if connu and connu.nom_site == res.nom and connu.nom_affiche:
            nom_affiche = connu.nom_affiche          # nom corrigé à la main : conservé
        else:
            nom_affiche = nom_court(res.nom)
            if len(mentions.variantes) > 1:          # existe en 4G et 5G : l'étiquette l'indique
                nom_affiche = re.sub(r"\s*\b[45]G\b", "", nom_affiche).strip()
        p = Produit(
            code=res.code,
            nom_site=res.nom,
            # un nom corrigé à la main est conservé si la désignation du site n'a pas changé
            nom_affiche=nom_affiche,
            photo=str(photo),
            source=source,
            url_fiche=res.url_fiche,
            verifie=True,
            avertissement=avert,
            cadrage=connu.cadrage if connu else Cadrage(),
            # mentions corrigées à la main conservées tant que la désignation est la même
            mentions=mentions,
            galerie=res.galerie,
            prix=res.prix,
        )
        self.base.enregistrer(p)
        self.base.noter(p.code, "recherche")
        return p

    def _mentions(self, res: Resultat, connu: Produit | None, var: list | None = None):
        # mentions corrigées à la main conservées tant que la désignation est la même
        m = connu.mentions if connu and connu.nom_site == res.nom else detecter_mentions(res.nom, res.attributs)
        from .boite import detecter
        # recalculé à chaque fois (nom, fiche…), sauf correction à la main, ou si une fiche lue
        # auparavant l'indiquait et que rien de nouveau n'a été lu
        garder = m.boite_manuel or (m.boite_indique and not res.fiche_lue and not m.reconditionne
                                    and connu is not None and connu.nom_site == res.nom)
        if not garder:
            m.boite, m.boite_indique = detecter(res.accessoires, res.nom, res.description_boite, m.reconditionne)
        from .coloris import plusieurs
        if var is None:
            var = self._variantes(res)
        if var is not None:
            m.variantes = var
            propre = var and next((c[0] for r, c in var if c), "")
            m.autres_coloris = [c for _, cs in var for c in cs if c != propre]
            if plusieurs(m.variantes_affichees()):
                m.coloris = True          # au moins un autre coloris (site ou réserve) ou un autre réseau
            elif m.iphone and var:
                m.coloris = False         # iPhone vérifié : une seule couleur → pas de « plusieurs coloris »
        return m

    # -- modifications manuelles ---------------------------------------------------------
    def remplacer_photo_fichier(self, p: Produit, fichier: Path, dest: Path | None = None) -> Produit:
        dest = dest or self.chemin_photo(p.code)
        images.preparer_fichier(fichier, dest)
        p.photo = str(dest)
        p.cadrage = Cadrage()
        if p.source in ("electrodepot.fr", "catalogue hors ligne"):
            p.avertissement = "Photo remplacée manuellement."
        return p

    def remplacer_photo_url(self, p: Produit, url: str) -> Produit:
        data = self.client.telecharger_url(url)
        dest = self.chemin_photo(p.code)
        images.preparer(data, dest)
        p.photo = str(dest)
        p.cadrage = Cadrage()
        return p

    def creer_manuel(self, code: str, nom: str, fichier_photo: Path) -> Produit:
        code = normaliser_code(code)
        dest = self.chemin_photo(code)
        images.preparer_fichier(fichier_photo, dest)
        p = Produit(code=code, nom_site="", nom_affiche=nom.strip().upper(), photo=str(dest),
                    source="saisie manuelle", verifie=False, mentions=detecter_mentions(nom),
                    avertissement="Produit saisi à la main : non vérifié sur le site.")
        self.base.enregistrer(p)
        self.base.noter(code, "saisie manuelle")
        return p

    def enregistrer(self, p: Produit) -> None:
        self.base.enregistrer(p)

    # -- import CSV ---------------------------------------------------------------------
    def importer_csv(self, fichier: Path, telecharger=True) -> tuple[int, list[str]]:
        """Colonnes reconnues : code ; nom (ou designation) ; photo (chemin ou adresse web).

        Renvoie (nombre importé, liste des erreurs).
        """
        brut = Path(fichier).read_bytes()
        for enc in ("utf-8-sig", "cp1252", "latin-1"):
            try:
                texte = brut.decode(enc)
                break
            except UnicodeDecodeError:
                continue
        try:
            dialecte = csv.Sniffer().sniff(texte[:4096], delimiters=";,\t")
        except csv.Error:
            class dialecte(csv.excel):  # noqa: N801
                delimiter = ";"
        lecteur = csv.reader(io.StringIO(texte), dialecte)
        lignes = [l for l in lecteur if any(c.strip() for c in l)]
        if not lignes:
            return 0, ["Fichier vide."]
        entete = [c.strip().lower() for c in lignes[0]]

        def col(*noms):
            for n in noms:
                for i, e in enumerate(entete):
                    if e.startswith(n):
                        return i
            return None

        ic = col("code", "réf", "ref", "sku", "article")
        inn = col("nom", "désignation", "designation", "libellé", "libelle", "titre")
        ip = col("photo", "image", "visuel", "url")
        ipx = col("prix", "price")
        if ic is None or inn is None:
            return 0, ["La première ligne doit contenir au moins les colonnes « code » et « nom »."]

        ok, erreurs = 0, []
        for n, l in enumerate(lignes[1:], start=2):
            try:
                code = normaliser_code(l[ic] if ic < len(l) else "")
                nom = (l[inn] if inn < len(l) else "").strip()
                if not nom:
                    raise ErreurRecherche("nom vide")
                src = (l[ip].strip() if ip is not None and ip < len(l) else "")
                connu = self.base.produit(code)
                photo = connu.photo if connu else ""
                if src:
                    dest = self.chemin_photo(code)
                    if re.match(r"https?://", src, re.I):
                        if telecharger:
                            images.preparer(self.client.telecharger_url(src), dest, verifier_taille=False)
                            photo = str(dest)
                    else:
                        images.preparer_fichier(Path(src), dest)
                        photo = str(dest)
                from .electrodepot import lire_prix
                prix = lire_prix(l[ipx]) if ipx is not None and ipx < len(l) else (connu.prix if connu else 0.0)
                p = Produit(code=code, nom_site=nom, nom_affiche=nom_court(nom), mentions=detecter_mentions(nom), prix=prix,
                            photo=photo, source="catalogue CSV", verifie=True,
                            cadrage=connu.cadrage if connu else Cadrage())
                if not photo:
                    p.avertissement = "Pas de photo dans le catalogue : ajoutez-la avec « Modifier »."
                self.base.enregistrer(p)
                ok += 1
            except (ErreurRecherche, images.ImageInvalide, OSError) as e:
                erreurs.append(f"Ligne {n} : {e}")
        return ok, erreurs
