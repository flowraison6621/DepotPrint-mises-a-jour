r"""Emplacements des fichiers : ressources embarquées et données (mode portable).

Mode portable : tout est rangé à côté du logiciel, dans le même dossier.

    Dépôt Print\
        DepotPrint.exe          ← double-clic pour lancer
        DepotPrint_donnees\     ← créé tout seul : produits, photos, réglages
        Affiches PDF\           ← créé tout seul : les PDF générés

Pour déplacer le logiciel sur un autre poste, il suffit de copier ce dossier.
Si l'emplacement n'est pas modifiable (dossier protégé), les données vont dans
le profil Windows et les PDF dans « Documents\\Dépôt Print ».
"""

from __future__ import annotations

import os
import shutil
import sys
from functools import lru_cache
from pathlib import Path

NOM_DONNEES = "DepotPrint_donnees"
NOM_PDF = "Affiches PDF"


def _base_dir() -> Path:
    """Dossier des ressources (dans l'exe PyInstaller ou dans les sources)."""
    if getattr(sys, "frozen", False):
        return Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent))
    return Path(__file__).resolve().parent.parent


def _exe_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


ASSETS = _base_dir() / "assets"
TEMPLATE_PDF = ASSETS / "modele_fond.pdf"
FONT_NAME_FILE = ASSETS / "fonts" / "Barlow-Bold.ttf"
FONT_PROTECTION_FILE = ASSETS / "fonts" / "BigShouldersDisplay-ExtraBold.ttf"   # style Electrosur
ICON_FILE = ASSETS / "icone.ico"


def _modifiable(d: Path) -> bool:
    try:
        d.mkdir(parents=True, exist_ok=True)
        essai = d / ".essai_ecriture"
        essai.write_text("ok", encoding="utf-8")
        essai.unlink()
        return True
    except OSError:
        return False


def _ancien_dossier() -> Path:
    """Emplacement utilisé par les versions précédentes (profil Windows)."""
    if os.name == "nt" and os.environ.get("LOCALAPPDATA"):
        return Path(os.environ["LOCALAPPDATA"]) / "DepotPrint"
    return Path.home() / ".depotprint"


@lru_cache(maxsize=1)
def data_dir() -> Path:
    """Données : produits enregistrés, photos, réglages (à côté du logiciel si possible)."""
    force = os.environ.get("DEPOTPRINT_DONNEES")          # utilisé par les tests
    if force:
        d = Path(force)
    else:
        portable = _exe_dir() / NOM_DONNEES
        ancien = _ancien_dossier()
        if not portable.is_dir() and (ancien / "produits.sqlite").is_file():
            # premier lancement en mode portable : on reprend les produits déjà enregistrés
            try:
                shutil.copytree(ancien, portable)
            except OSError:
                pass
        d = portable if _modifiable(portable) else ancien
    d.mkdir(parents=True, exist_ok=True)
    (d / "photos").mkdir(exist_ok=True)
    return d


@lru_cache(maxsize=1)
def output_dir() -> Path:
    """Dossier des PDF : « Affiches PDF » à côté du logiciel (sinon Documents\\Dépôt Print)."""
    force = os.environ.get("DEPOTPRINT_PDF")
    if force:
        d = Path(force)
    else:
        d = _exe_dir() / NOM_PDF
        if not _modifiable(d):
            docs = Path.home() / "Documents"
            d = (docs if docs.is_dir() else Path.home()) / "Dépôt Print"
    d.mkdir(parents=True, exist_ok=True)
    return d


def retrouver_photo(chemin: str) -> str:
    """Photo enregistrée sur un autre poste ou à un autre emplacement : on la cherche ici."""
    if not chemin or Path(chemin).is_file():
        return chemin
    nom = Path(chemin.replace("\\", "/")).name
    for ici in (data_dir() / "photos" / nom, data_dir() / "photos" / "catalogue" / nom):
        if ici.is_file():
            return str(ici)
    return chemin
