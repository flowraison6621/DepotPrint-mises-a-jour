"""Réseau d'un téléphone (4G ou 5G), affiché partout : sur l'affiche, la fiche et la liste.

Ordre de priorité :
1. choix fait à la main dans « Modifier » ;
2. ce qui est écrit dans la désignation du site (« … 5G 128Go … ») ;
3. déduit du modèle quand le site ne l'écrit pas (iPhone 12 et plus récents = 5G, Galaxy S21 et plus = 5G…) ;
4. sinon 4G : les vendeurs écrivent toujours « 5G » quand le téléphone l'est.
Les tablettes n'ont pas de réseau affiché, sauf s'il est écrit dans leur nom.
Les consoles et les manettes n'en ont jamais.
"""
from __future__ import annotations

import re

_ECRIT = re.compile(r"\b([45])G\b", re.I)


def _est_tablette(nom: str) -> bool:
    n = nom.lower()
    return n.startswith("tablette") or "ipad" in n or re.search(r"\btab\b", n) is not None


def _est_jeu(nom: str) -> bool:
    """Consoles et manettes : pas de réseau 4G/5G."""
    return re.match(r"\s*(console|manette)", nom, re.I) is not None


def deduire(nom: str) -> str:
    """Réseau d'après la désignation seule (sans le choix fait à la main)."""
    nom = nom or ""
    m = _ECRIT.search(nom)
    if m:
        return m.group(1) + "G"
    if not nom.strip() or _est_tablette(nom) or _est_jeu(nom):
        return ""
    n = nom.lower()
    if "iphone" in n:
        if re.search(r"iphone\s*se", n):
            return "5G" if re.search(r"2022|\b3\b|3e|3ème", n) else "4G"
        m = re.search(r"iphone\s*(\d+)", n)
        if m:
            return "5G" if int(m.group(1)) >= 12 else "4G"
        return "4G"
    if "samsung" in n or "galaxy" in n:
        if re.search(r"\bz\s*(fold|flip)", n):
            return "5G"
        m = re.search(r"\bs\s?(\d{2})", n)
        if m and int(m.group(1)) >= 21:
            return "5G"
    m = re.search(r"pixel\s*(\d+)", n)
    if m and int(m.group(1)) >= 6:
        return "5G"
    return "4G"


def reseau(p) -> str:
    """« 4G », « 5G » ou « » (tablette sans réseau)."""
    choix = getattr(p.mentions, "reseau", "")
    if choix in ("4G", "5G"):
        return choix
    return reseau_auto(p)


def reseau_auto(p) -> str:
    """Réseau trouvé sans le choix fait à la main (écrit sur le site, ou déduit du modèle)."""
    for nom in (p.nom_site, p.nom_affiche):           # écrit quelque part : on le prend
        m = _ECRIT.search(nom or "")
        if m:
            return m.group(1) + "G"
    return deduire(p.nom_site) if (p.nom_site or "").strip() else deduire(p.nom_affiche)


def mentions_de_son_reseau(p):
    """Produit seul : seulement les couleurs de SON réseau (le code tapé est un 4G ou un 5G).
    Les couleurs de l'autre réseau ne servent que pour une affiche à deux produits (4G + 5G)."""
    from dataclasses import replace
    m = p.mentions
    groupes = [g for g, cs in m.variantes if cs]
    r = reseau(p)
    if len(groupes) < 2 or not r or r not in [(g or "").upper() for g in groupes]:
        return m
    garder = lambda cle: (cle.partition("|")[0] or r).upper() == r
    return replace(m, variantes=[[g, cs] for g, cs in m.variantes if (g or "").upper() == r],
                   coloris_exclus=[c for c in m.coloris_exclus if garder(c)],
                   coloris_ajoutes=[c for c in m.coloris_ajoutes if garder(c)])


def nom_produit_seul(p) -> str:
    """Nom imprimé pour un produit seul : avec son réseau."""
    if len(mentions_de_son_reseau(p).variantes_affichees()) > 1:
        return p.nom_affiche
    return nom_avec_reseau(p.nom_affiche, reseau(p))


def nom_avec_reseau(nom: str, res: str) -> str:
    """Nom d'un produit seul : on ajoute le réseau à la fin s'il n'y est pas déjà."""
    if not res or _ECRIT.search(nom or ""):
        return nom
    return f"{nom} {res}".strip()
