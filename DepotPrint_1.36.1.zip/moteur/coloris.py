"""Autres coloris d'un même produit (chaque coloris a son propre code sur le site).

Règle validée : même modèle, même capacité, même réseau (4G / 5G), même état
pour un reconditionné ; seule la couleur change. Les accessoires (coques,
films…) ne sont jamais comptés.

Exemples vérifiés sur le site :
  MOTOROLA G06 256Go 4G Vert      → aussi Bleu, Orange
  SAMSUNG Galaxy A17 4G 128Go Noir → aussi Bleu clair (le site écrit « Bleu Clair »
                                     dans le nom et « Bleu ciel » dans le coloris)
  SAMSUNG Galaxy A17 5G 128Go Noir → aussi Bleu, Gris
"""

from __future__ import annotations

import re
import unicodedata

from .noms import _COULEURS

# nuances qui accompagnent une couleur (« Bleu Clair », « Vert Nuit »…)
_NUANCES = ["clair", "claire", "fonce", "foncee", "ciel", "nuit", "pastel", "mat", "matte", "glacier",
            "glace", "metal", "metallise", "intense", "profond", "sideral", "alpin", "poudre",
            "menthe", "lavande", "corail", "sable", "minuit", "naturel", "desert", "aurore",
            "cosmique", "lunaire", "eclipse", "ocean", "titane", "light", "dark"]
_PREFIXES = re.compile(r"^(smartphone|tablette( tactile)?|telephone( mobile)?|mobile|portable) ")
_CAPACITE = re.compile(r"\b(\d+) ?(go|gb|to|tb)\b")
_ACCESSOIRES = re.compile(r"\b(coque|film|verre|etui|folio|protection|chargeur|cable|housse|support|"
                          r"ecouteurs?|batterie externe|pack)\b")


def _sans_accents(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")


_MOTS_COULEUR = {_sans_accents(m) for c in _COULEURS for m in c.lower().split()} | set(_NUANCES)


def _normaliser(s: str) -> str:
    s = _sans_accents((s or "").lower())
    s = re.sub(r"[^a-z0-9+ ]", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def cle_modele(designation: str, coloris: str = "") -> str:
    """Désignation sans la couleur : deux coloris d'un même produit ont la même clé."""
    s = _normaliser(designation)
    s = _PREFIXES.sub("", s)
    s = re.sub(r"\bgalaxy\b ", "", s)
    s = _CAPACITE.sub(lambda m: f"{m.group(1)}{'to' if m.group(2) in ('to', 'tb') else 'go'}", s)
    c = _normaliser(coloris)
    if c:
        s = re.sub(rf"\b{re.escape(c)}\b", " ", s)
    mots = [m for m in s.split() if m not in _MOTS_COULEUR]
    return " ".join(mots)


def requete_modele(designation: str) -> str:
    """Texte à chercher sur le site : la désignation jusqu'à la capacité (« SAMSUNG Galaxy A17 »)."""
    s = re.split(r"\s\+\s", designation or "")[0]
    s = re.sub(r"^\s*(smartphone|tablette(\s+tactile)?|t[ée]l[ée]phone(\s+mobile)?|mobile)\s+", "", s, flags=re.I)
    m = re.search(r"\b\d+\s?(go|gb|to|tb)\b", s, re.I)
    if m:
        s = s[:m.start()]
    s = re.sub(r"\s+[45]G\s*$", "", s.strip(), flags=re.I)     # 4G et 5G : la clé les distingue
    return " ".join(s.split())


def est_accessoire(designation: str) -> bool:
    return bool(_ACCESSOIRES.search(_normaliser(designation)))


def autres_coloris(code: str, designation: str, coloris: str, produits_site: list[dict]) -> list[str]:
    """Coloris des AUTRES codes du même produit parmi les résultats de recherche du site."""
    cle = cle_modele(designation, coloris)
    if not cle:
        return []
    trouves: list[str] = []
    for p in produits_site:
        ref = str(p.get("refCode") or p.get("sku") or "").strip()
        nom = p.get("name", "")
        if not nom or ref == code or est_accessoire(nom):
            continue
        if cle_modele(nom, p.get("coloris", "")) != cle:
            continue
        couleur = _joli(couleur_produit(nom, p.get("coloris", "")))
        if couleur.lower() != _joli(couleur_produit(designation, coloris)).lower() and couleur not in trouves:
            trouves.append(couleur)
    return trouves


def _couleur_du_nom(nom: str, cle: str) -> str:
    mots = [m for m in _normaliser(nom).split() if m in _MOTS_COULEUR]
    return " ".join(mots)


# --- Variantes : couleurs ET réseaux (4G / 5G) d'un même modèle -------------------------------

_RESEAU = re.compile(r"\b([45])g\b")


def reseau(designation: str) -> str:
    m = _RESEAU.search(_normaliser(designation))
    return f"{m.group(1)}G" if m else ""


def _cle_sans_reseau(designation: str, coloris: str) -> str:
    return " ".join(m for m in cle_modele(designation, coloris).split() if not _RESEAU.fullmatch(m))


def couleur_produit(nom: str, coloris_site: str = "") -> str:
    """Couleur d'un produit. Le nom fait foi : le champ « coloris » du site est parfois
    faux (ex. « Redmi Note17 4G 128Go Bleu » indiqué « Noir »). Le champ du site ne sert
    que si le nom ne contient aucune couleur."""
    s = re.split(r"\s\+\s", nom or "")[0]
    mots = [m for m in re.findall(r"[^\s/,()]+", s) if _normaliser(m) in _MOTS_COULEUR]
    # on garde le dernier groupe de mots de couleur consécutifs (« Bleu Clair », « Titane bleu »)
    tokens = re.findall(r"[^\s/,()]+", s)
    groupes, courant = [], []
    for t in tokens:
        if _normaliser(t) in _MOTS_COULEUR:
            courant.append(t)
        elif courant:
            groupes.append(courant)
            courant = []
    if courant:
        groupes.append(courant)
    if groupes and mots:
        return " ".join(groupes[-1])
    return coloris_site or ""


def _joli(couleur: str) -> str:
    c = " ".join(couleur.split())
    return c[:1].upper() + c[1:].lower() if c else "?"


def variantes(code: str, designation: str, coloris: str, produits_site: list[dict]) -> list[list]:
    """Toutes les couleurs disponibles, groupées par réseau : [["4G", ["Noir", "Bleu ciel"]], ["5G", [...]]].

    Le produit saisi est toujours inclus (sa couleur en premier dans son réseau).
    Même modèle et même capacité ; seuls la couleur et le réseau peuvent changer.
    """
    cle = _cle_sans_reseau(designation, coloris)
    if not cle:
        return []
    groupes: dict[str, list[str]] = {}
    propre = _joli(couleur_produit(designation, coloris))
    groupes.setdefault(reseau(designation), []).append(propre)
    for p in produits_site:
        ref = str(p.get("refCode") or p.get("sku") or "").strip()
        nom = p.get("name", "")
        if not nom or ref == code or est_accessoire(nom):
            continue
        col = p.get("coloris", "")
        if _cle_sans_reseau(nom, col) != cle:
            continue
        couleur = _joli(couleur_produit(nom, col))
        liste = groupes.setdefault(reseau(nom), [])
        if couleur not in liste:
            liste.append(couleur)
    ordre = {"4G": 0, "5G": 1, "": 2}
    return [[r, c] for r, c in sorted(groupes.items(), key=lambda kv: ordre.get(kv[0], 3))]


def photos_par_couleur(code: str, designation: str, coloris: str, articles: list[dict]) -> list[tuple]:
    """Photos du même modèle (même réseau, capacité, état) dans les autres couleurs :
    [(couleur, code, photo)], la couleur du produit en premier."""
    cle = cle_modele(designation, coloris)
    if not cle:
        return []
    res = [(_joli(couleur_produit(designation, coloris)), code, "")]
    vus = {res[0][0]}
    for a in articles:
        nom, col = a.get("nom", ""), a.get("coloris", "")
        if a.get("code") == code or not nom or est_accessoire(nom) or cle_modele(nom, col) != cle:
            continue
        c = _joli(couleur_produit(nom, col))
        if c and c not in vus and a.get("photo"):
            vus.add(c)
            res.append((c, a["code"], a["photo"]))
    return res


_MOTS_VERSION = {"reconditionne", "reconditionnee", "etat", "correct", "excellent", "eco", "grade", "batterie",
                 "neuve", "batnew", "4g", "5g", "rec", "a", "a+", "b", "c", "premium", "tres", "bon"}


def cle_famille(designation: str, coloris: str = "") -> str:
    """Même téléphone, toutes versions confondues : sans couleur, capacité, réseau, état ni batterie.
    Sert à retrouver la photo d'une couleur (un iPhone 13 Vert 256 Go montre le même vert qu'en 128 Go)."""
    cle = cle_modele(designation, coloris)
    mots = [m for m in cle.split() if m not in _MOTS_VERSION and not re.fullmatch(r"\d+(go|to)", m)]
    return " ".join(mots)


def couleurs_connues(code: str, designation: str, coloris: str, articles: list[dict]) -> list[dict]:
    """Couleurs déjà vues pour ce téléphone dans le catalogue (produits retirés du site, autres
    capacités ou états) : [{"couleur", "code", "photo", "motif"}], une entrée par couleur."""
    famille = cle_famille(designation, coloris)
    if not famille:
        return []
    exacte = cle_modele(designation, coloris)
    capa = _CAPACITE.search(_normaliser(designation))
    propre = _joli(couleur_produit(designation, coloris))
    res: dict[str, dict] = {}
    for a in articles:
        nom, col = a.get("nom", ""), a.get("coloris", "")
        if a.get("code") == code or not nom or est_accessoire(nom) or cle_famille(nom, col) != famille:
            continue
        c = _joli(couleur_produit(nom, col))
        if not c or c == propre:
            continue
        if a.get("retire"):
            motif = "plus sur le site"
        elif cle_modele(nom, col) == exacte:
            motif = "sur le site"
        else:
            m = _CAPACITE.search(_normaliser(nom))
            autre_capa = m and capa and m.group(1) != capa.group(1)
            motif = f"vu en {m.group(1)} Go" if autre_capa else "vu dans une autre version"
        prec = res.get(c)
        rang = {"sur le site": 0, "plus sur le site": 1}.get(motif, 2)
        if prec is None or (rang < prec["rang"]) or (not prec["photo"] and a.get("photo")):
            res[c] = {"couleur": c, "code": a["code"], "photo": a.get("photo", ""), "motif": motif, "rang": rang}
    return sorted(res.values(), key=lambda d: (d["rang"], d["couleur"]))


def nb_couleurs(var: list) -> int:
    return sum(len(c) for _, c in var or [])


def cle_couleur(reseau: str, couleur: str) -> str:
    return f"{reseau or ''}|{couleur}"


def filtrer(var: list, exclus: list) -> list:
    """Retire les couleurs décochées ; un réseau sans couleur restante disparaît."""
    if not exclus:
        return var
    ex = set(exclus)
    out = [[r, [c for c in cs if cle_couleur(r, c) not in ex]] for r, cs in (var or [])]
    return [g for g in out if g[1]]


def ajouter(var: list, ajouts: list) -> list:
    """Ajoute les couleurs saisies à la main (en réserve, pas encore sur le site)."""
    if not ajouts:
        return var
    out = [[r, list(cs)] for r, cs in (var or [])]
    for cle in ajouts:
        r, _, c = cle.partition("|")
        g = next((g for g in out if (g[0] or "") == r), None)
        if g is None:
            g = [r, []]
            out.append(g)
        if c and c not in g[1]:
            g[1].append(c)
    ordre = {"4G": 0, "5G": 1, "": 2}
    return sorted(out, key=lambda g: ordre.get(g[0] or "", 3))


def plusieurs(var: list) -> bool:
    """Faut-il afficher l'étiquette ? (au moins 2 couleurs ou 2 réseaux)"""
    return nb_couleurs(var) > 1 or len(var or []) > 1


def resume_variantes(var: list) -> str:
    if not var:
        return ""
    if len(var) == 1:
        return ", ".join(var[0][1])
    return " · ".join(f"{r or 'autre'} : {', '.join(c)}" for r, c in var)


# Teintes des pastilles (nom du site → couleur). Inconnue → gris neutre, le nom reste écrit.
_TEINTES = {
    "noir": "#1A1A1A", "blanc": "#FFFFFF", "gris": "#8A8F98", "graphite": "#4A4D52", "anthracite": "#3A3D42",
    "argent": "#C9CCD1", "silver": "#C9CCD1", "titane": "#9C9A93", "titane naturel": "#B9B3A6", "titane bleu": "#3E4A5E", "titane noir": "#3B3B3D",
    "titane blanc": "#E6E4DF", "titane desert": "#C7A88A",
    "bleu": "#2167C9", "bleu ciel": "#8CCBF0", "navy": "#1C2A52", "space gray": "#4A4D52", "bleu clair": "#8CCBF0", "bleu nuit": "#1C2A52",
    "bleu marine": "#1C2A52", "marine": "#1C2A52", "bleu glacier": "#BFDDF0", "turquoise": "#2BB3B1",
    "vert": "#3BA55C", "vert clair": "#9AD3A5", "vert menthe": "#98E2C6", "menthe": "#98E2C6",
    "vert fonce": "#1E5B37", "olive": "#7A7F3A", "sauge": "#A8B89A", "lime": "#B9DD4B",
    "orange": "#F28C28", "corail": "#F2775C", "rouge": "#D32F2F", "rose": "#F4A7C0", "rose poudre": "#F2C4CE",
    "violet": "#8E5BD0", "lavande": "#B9A7E6", "lilas": "#C8A2C8", "prune": "#6B2E4E",
    "jaune": "#F7D443", "or": "#D4AF37", "dore": "#D4AF37", "creme": "#F3E9D2", "beige": "#D9C3A0",
    "ivoire": "#F4EFE1", "sable": "#D8C3A0", "bronze": "#A97142", "cuivre": "#B87333",
    "transparent": "#E9EEF2",
}


def teinte(nom: str) -> str:
    n = _normaliser(nom)
    if n in _TEINTES:
        return _TEINTES[n]
    for cle in sorted(_TEINTES, key=len, reverse=True):     # « Bleu ciel pastel » → bleu ciel
        if re.search(rf"\b{re.escape(cle)}\b", n):
            return _TEINTES[cle]
    return "#B8BCC4"
