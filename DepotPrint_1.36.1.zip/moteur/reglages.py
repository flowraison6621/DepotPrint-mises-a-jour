"""Réglages modifiables : grille de la protection casse / vol / oxydation (Electrosur).

Le tarif est choisi d'après le prix du produit lu sur le site. Ce prix sert
uniquement au calcul : il n'est JAMAIS imprimé sur l'affiche.
"""

from __future__ import annotations

import json

from . import paths

# Grille Electrosur Casse Mobile (tarif mensuel TTC selon le prix d'achat)
GRILLE_DEFAUT = [
    {"jusqua": 149.99, "tarif": 2},
    {"jusqua": 299.99, "tarif": 4},
    {"jusqua": 499.99, "tarif": 7},
    {"jusqua": None, "tarif": 10},      # 500 € et plus
]


def _fichier():
    return paths.data_dir() / "reglages.json"


def charger_grille() -> list[dict]:
    try:
        d = json.loads(_fichier().read_text(encoding="utf-8"))
        g = d.get("grille_protection")
        if _valide(g):
            return g
    except (OSError, ValueError, AttributeError):
        pass
    return [dict(x) for x in GRILLE_DEFAUT]


def enregistrer_grille(grille: list[dict]) -> None:
    if not _valide(grille):
        raise ValueError("Grille invalide : les seuils doivent être croissants et les tarifs positifs.")
    try:
        d = json.loads(_fichier().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        d = {}
    d["grille_protection"] = grille
    _fichier().write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")


def _valide(g) -> bool:
    if not isinstance(g, list) or not g:
        return False
    precedent = -1.0
    for i, t in enumerate(g):
        if not isinstance(t, dict) or not isinstance(t.get("tarif"), (int, float)) or t["tarif"] <= 0:
            return False
        s = t.get("jusqua")
        if s is None:
            if i != len(g) - 1:
                return False
        else:
            if not isinstance(s, (int, float)) or s <= precedent:
                return False
            precedent = s
    return g[-1].get("jusqua") is None


def tarif_pour_prix(prix: float, grille: list[dict] | None = None) -> int | None:
    """Tarif mensuel de la protection pour ce prix (None si le prix est inconnu)."""
    if not prix or prix <= 0:
        return None
    for t in grille or charger_grille():
        if t["jusqua"] is None or prix <= t["jusqua"]:
            v = t["tarif"]
            return int(v) if float(v).is_integer() else v
    return None


# Electrosûr « Garantie Tranquillité » (panne), formule 1 famille : 6 €/mois (electrodepot.fr/electrosur)
TARIF_TRANQUILLITE = 6


def tarif_affiche(produit) -> int | float | None:
    """Tarif à imprimer : choix manuel s'il y en a un, sinon calcul d'après le prix."""
    from .noms import est_tablette
    m = produit.mentions
    if not m.protection:
        return None
    if m.tarif_protection:
        return m.tarif_protection             # tarif forcé à la main dans « Modifier »
    from .affiche import est_jeu
    if est_jeu(produit):
        return TARIF_TRANQUILLITE             # consoles, manettes : Garantie Tranquillité (panne)
    if est_tablette(produit.nom_site or produit.nom_affiche):
        return None                           # pas de protection Electrosur sur les tablettes
    return tarif_pour_prix(produit.prix)


def texte_tarif(v) -> str:
    return f"{v:g}" if isinstance(v, float) else str(v)


# --- Affiche « deux versions » : disposition choisie dans Réglages -----------------------------
#  Deux réglages séparés : reconditionnés (état, batterie…) et neufs 4G / 5G.
DISPOSITIONS = {"cote": "Photo en haut, versions côte à côte", "empile": "Photo à gauche, versions empilées",
                "simple": "Affiche simple, comme avant\n(1re version seule, couleurs 4G / 5G dans l'étiquette)"}
GENRES = {"recond": ("deux_versions", "cote"),      # clé dans reglages.json, valeur par défaut
          "reseau": ("deux_reseaux", "simple")}


def genre_deux_versions(p1, p2) -> str:
    """« reseau » : deux neufs (4G / 5G) ; « recond » : au moins un reconditionné."""
    return "recond" if (p1.mentions.reconditionne or p2.mentions.reconditionne) else "reseau"


def disposition_deux_versions(genre: str = "recond") -> str:
    """Toujours côte à côte (photo en haut) : le choix a été retiré des Réglages."""
    return "cote"


def _disposition_enregistree(genre: str = "recond") -> str:
    cle, defaut = GENRES.get(genre, GENRES["recond"])
    try:
        d = json.loads(_fichier().read_text(encoding="utf-8")).get(cle, defaut)
        return d if d in DISPOSITIONS else defaut
    except (OSError, ValueError, AttributeError):
        return defaut


def enregistrer_disposition(valeur: str, genre: str = "recond") -> None:
    if valeur not in DISPOSITIONS or genre not in GENRES:
        raise ValueError(valeur)
    try:
        d = json.loads(_fichier().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        d = {}
    d[GENRES[genre][0]] = valeur
    _fichier().write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")


# --- réglages simples (clé → valeur) dans reglages.json ------------------------------------
def lire_reglage(cle: str, defaut=None):
    try:
        return json.loads(_fichier().read_text(encoding="utf-8")).get(cle, defaut)
    except (OSError, ValueError, AttributeError):
        return defaut


def enregistrer_reglage(cle: str, valeur) -> None:
    try:
        d = json.loads(_fichier().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        d = {}
    d[cle] = valeur
    _fichier().write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
