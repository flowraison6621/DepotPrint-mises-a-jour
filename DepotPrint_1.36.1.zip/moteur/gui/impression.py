"""Impression directe sur une imprimante Windows, avec aperçu avant impression."""

from __future__ import annotations

import pymupdf
from PySide6.QtCore import QMarginsF, QRectF
from PySide6.QtGui import QImage, QPageLayout, QPageSize, QPainter
from PySide6.QtPrintSupport import QPrintDialog, QPrinter, QPrintPreviewDialog
from PySide6.QtWidgets import QWidget

DPI_IMPRESSION = 300


def _imprimante(nom_doc: str) -> QPrinter:
    p = QPrinter(QPrinter.PrinterMode.HighResolution)
    p.setPageLayout(QPageLayout(QPageSize(QPageSize.PageSizeId.A4), QPageLayout.Orientation.Landscape,
                                QMarginsF(0, 0, 0, 0)))
    p.setFullPage(True)          # échelle 100 % : les marges sont déjà dans l'affiche
    p.setDocName(nom_doc)
    p.setColorMode(QPrinter.ColorMode.Color)
    return p


def _peindre(doc: pymupdf.Document, imprimante: QPrinter) -> None:
    peintre = QPainter()
    if not peintre.begin(imprimante):
        raise RuntimeError("Impossible de démarrer l'impression (imprimante indisponible ?).")
    try:
        dpi = min(DPI_IMPRESSION, max(150, imprimante.resolution()))
        for i, page in enumerate(doc):
            if i:
                imprimante.newPage()
            pix = page.get_pixmap(dpi=dpi, alpha=False)
            img = QImage(pix.samples, pix.width, pix.height, pix.stride, QImage.Format.Format_RGB888).copy()
            dessiner_page(peintre, img)
    finally:
        peintre.end()


def dessiner_page(peintre: QPainter, img: QImage) -> None:
    """Pose la feuille sans JAMAIS la déformer.

    L'imprimante (ou ses réglages par défaut) peut imposer le portrait : la feuille
    paysage est alors tournée d'un quart de tour, ce qui donne exactement le même
    papier imprimé. Les proportions sont toujours conservées.
    """
    vp = peintre.viewport()
    W, H = float(vp.width()), float(vp.height())
    peintre.save()
    if (H > W) != (img.height() > img.width()):     # orientations différentes
        peintre.translate(W, 0)
        peintre.rotate(90)
        W, H = H, W
    r = min(W / img.width(), H / img.height())
    w, h = img.width() * r, img.height() * r
    peintre.drawImage(QRectF((W - w) / 2, (H - h) / 2, w, h), img)
    peintre.restore()


def imprimer(parent: QWidget, doc: pymupdf.Document, nom_doc: str = "Affiches") -> bool:
    imp = _imprimante(nom_doc)
    dlg = QPrintDialog(imp, parent)
    dlg.setWindowTitle(f"Imprimer : {nom_doc}")
    if dlg.exec() != QPrintDialog.DialogCode.Accepted:
        return False
    imp.setFullPage(True)
    portrait = len(doc) and doc[0].rect.height > doc[0].rect.width      # relevés, étiquettes : portrait
    imp.setPageOrientation(QPageLayout.Orientation.Portrait if portrait else QPageLayout.Orientation.Landscape)
    _peindre(doc, imp)
    return True


def apercu_avant_impression(parent: QWidget, doc: pymupdf.Document, nom_doc: str = "Affiches") -> None:
    imp = _imprimante(nom_doc)
    dlg = QPrintPreviewDialog(imp, parent)
    dlg.setWindowTitle("Aperçu avant impression")
    dlg.resize(1100, 800)
    dlg.paintRequested.connect(lambda p: _peindre(doc, p))
    dlg.exec()
