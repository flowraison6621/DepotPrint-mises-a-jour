"""Petites fenêtres : choix en cas d'ambiguïté, saisie manuelle, fiche produit."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QDialog, QDialogButtonBox, QFileDialog, QFormLayout, QGridLayout, QHBoxLayout, QLabel, QLineEdit,
    QListWidget, QListWidgetItem, QMessageBox, QPushButton, QVBoxLayout, QWidget,
)

from .edition import FILTRE_IMAGES


def _boutons(dlg: QDialog, ok_txt: str) -> QDialogButtonBox:
    b = QDialogButtonBox()
    ok = b.addButton(ok_txt, QDialogButtonBox.ButtonRole.AcceptRole)
    ok.setObjectName("principal")
    b.addButton("Annuler", QDialogButtonBox.ButtonRole.RejectRole)
    b.accepted.connect(dlg.accept)
    b.rejected.connect(dlg.reject)
    return b


class ChoixCandidat(QDialog):
    """Plusieurs fiches pour un même code : l'utilisateur choisit, rien n'est deviné."""

    def __init__(self, parent: QWidget, code: str, message: str, candidats: list[dict]):
        super().__init__(parent)
        self.setWindowTitle(f"Référence {code} ambiguë")
        self.resize(620, 360)
        v = QVBoxLayout(self)
        l = QLabel(message + "\nChaque choix sera revérifié sur sa fiche produit.")
        l.setWordWrap(True)
        v.addWidget(l)
        self.liste = QListWidget()
        for c in candidats:
            it = QListWidgetItem(f"{c['nom']}\n{c['url']}")
            it.setData(Qt.ItemDataRole.UserRole, c["url"])
            self.liste.addItem(it)
        self.liste.setCurrentRow(0)
        self.liste.itemDoubleClicked.connect(lambda *_: self.accept())
        v.addWidget(self.liste, 1)
        v.addWidget(_boutons(self, "Utiliser ce produit"))

    def url(self) -> str:
        it = self.liste.currentItem()
        return it.data(Qt.ItemDataRole.UserRole) if it else ""


class SaisieManuelle(QDialog):
    """Dernier recours : nom et photo fournis par l'utilisateur."""

    def __init__(self, parent: QWidget, code: str = "", nom: str = ""):
        super().__init__(parent)
        self.setWindowTitle("Saisie manuelle d'un produit")
        self.resize(560, 300)
        self.fichier = ""
        v = QVBoxLayout(self)
        aide = QLabel("À utiliser si le produit est introuvable sur le site. "
                      "L'affiche indiquera ce que vous saisissez : vérifiez bien.")
        aide.setWordWrap(True)
        aide.setObjectName("petit")
        v.addWidget(aide)
        f = QFormLayout()
        self.code = QLineEdit(code)
        self.nom = QLineEdit(nom)
        self.nom.setPlaceholderText("ex. SAMSUNG A57 5G")
        f.addRow("Code produit", self.code)
        f.addRow("Nom sur l'affiche", self.nom)
        h = QHBoxLayout()
        self.lbl_photo = QLabel("Aucune photo choisie")
        self.lbl_photo.setObjectName("petit")
        b = QPushButton("Choisir la photo…")
        b.clicked.connect(self._choisir)
        h.addWidget(b)
        h.addWidget(self.lbl_photo, 1)
        f.addRow("Photo", h)
        self.vignette = QLabel()
        self.vignette.setFixedHeight(110)
        f.addRow("", self.vignette)
        v.addLayout(f)
        v.addStretch()
        v.addWidget(_boutons(self, "Créer l'affiche"))

    def _choisir(self):
        f, _ = QFileDialog.getOpenFileName(self, "Photo du produit", str(Path.home()), FILTRE_IMAGES)
        if f:
            self.fichier = f
            self.lbl_photo.setText(Path(f).name)
            pm = QPixmap(f)
            if not pm.isNull():
                self.vignette.setPixmap(pm.scaledToHeight(105, Qt.TransformationMode.SmoothTransformation))

    def accept(self):
        if not self.code.text().strip() or not self.nom.text().strip() or not self.fichier:
            QMessageBox.warning(self, "Incomplet", "Indiquez le code, le nom et la photo.")
            return
        super().accept()


class DepuisFiche(QDialog):
    def __init__(self, parent: QWidget, code: str = ""):
        super().__init__(parent)
        self.setWindowTitle("Depuis une fiche produit Electro Dépôt")
        self.resize(640, 220)
        v = QVBoxLayout(self)
        aide = QLabel("Ouvrez la fiche du produit sur www.electrodepot.fr, copiez l'adresse de la page "
                      "(barre d'adresse du navigateur) et collez-la ci-dessous. Le code article affiché "
                      "sur la fiche sera vérifié.")
        aide.setWordWrap(True)
        v.addWidget(aide)
        f = QFormLayout()
        self.url = QLineEdit()
        self.url.setPlaceholderText("https://www.electrodepot.fr/mobile-….html")
        self.code = QLineEdit(code)
        self.code.setPlaceholderText("facultatif — pour contrôler la correspondance")
        f.addRow("Adresse de la fiche", self.url)
        f.addRow("Code attendu", self.code)
        v.addLayout(f)
        v.addStretch()
        v.addWidget(_boutons(self, "Récupérer"))

    def accept(self):
        if "electrodepot.fr" not in self.url.text():
            QMessageBox.warning(self, "Adresse incorrecte", "Collez l'adresse d'une fiche produit\nde www.electrodepot.fr.")
            return
        super().accept()


class FenetreReglages(QDialog):
    """Grille de la protection casse / vol / oxydation."""

    def __init__(self, parent: QWidget):
        super().__init__(parent)
        from ..reglages import charger_grille
        self.setWindowTitle("Réglages")
        self.resize(560, 760)
        v = QVBoxLayout(self)
        t = QLabel("🛡️ Protection casse · vol · oxydation")
        t.setStyleSheet("font-size: 13pt; font-weight: 700;")
        v.addWidget(t)
        aide = QLabel("Tarif mensuel imprimé sur les affiches de téléphones selon le prix du produit sur le site "
                      "(pas sur les tablettes). Le prix du produit, lui, n'est jamais imprimé.")
        aide.setWordWrap(True)
        aide.setObjectName("petit")
        v.addWidget(aide)
        self.grille = QGridLayout()
        self.grille.setHorizontalSpacing(12)
        self.grille.setVerticalSpacing(8)
        for c, txt in enumerate(("Prix du produit", "", "Tarif (€/mois)")):
            e = QLabel(txt)
            e.setObjectName("etiquette")
            self.grille.addWidget(e, 0, c)
        v.addLayout(self.grille)
        self.lignes = []
        self._remplir(charger_grille())
        h = QHBoxLayout()
        b_defaut = QPushButton("Tarifs Electrosur par défaut")
        b_defaut.clicked.connect(self._defaut)
        h.addWidget(b_defaut)
        h.addStretch()
        v.addLayout(h)
        self.choix_dispo = {}                          # plus de choix : toujours côte à côte
        # émoticônes de l'interface
        from PySide6.QtWidgets import QButtonGroup, QRadioButton
        from .icones import MODES, mode
        v.addSpacing(14)
        t2 = QLabel("😀 Émoticônes dans le logiciel")
        t2.setStyleSheet("font-size: 13pt; font-weight: 700;")
        v.addWidget(t2)
        aide2 = QLabel("Boutons, onglets, fiches et messages.\n(L'affiche imprimée n'en a jamais.)")
        aide2.setObjectName("petit")
        v.addWidget(aide2)
        self.choix_icones = {}
        groupe = QButtonGroup(self)
        exemples = {"les_deux": "Icône + texte      ex. « 🖨️ Imprimer »",
                    "icone": "Icône seule      ex. « 🖨️ »\n(boutons et onglets ; le texte s'affiche au survol)",
                    "texte": "Texte seul      ex. « Imprimer »"}
        for cle in MODES:
            r = QRadioButton(exemples[cle])
            r.setChecked(cle == mode())
            groupe.addButton(r)
            v.addWidget(r)
            self.choix_icones[cle] = r
        v.addStretch()
        v.addWidget(_boutons(self, "Enregistrer"))

    def _remplir(self, grille):
        from PySide6.QtWidgets import QDoubleSpinBox
        for w in self.lignes:
            for x in w:
                if isinstance(x, QWidget):
                    x.deleteLater()
        self.lignes = []
        precedent = None
        for i, t in enumerate(grille, start=1):
            if t["jusqua"] is None:
                lib = QLabel(f"au-delà de {precedent:.2f} €".replace(".", ",") if precedent is not None else "tous les prix")
                seuil = None
            else:
                lib = QLabel("jusqu'à")
                seuil = QDoubleSpinBox()
                seuil.setRange(0, 100000)
                seuil.setDecimals(2)
                seuil.setSuffix(" €")
                seuil.setValue(float(t["jusqua"]))
                precedent = t["jusqua"]
            tarif = QDoubleSpinBox()
            tarif.setRange(0.5, 1000)
            tarif.setDecimals(2)
            tarif.setSuffix(" €")
            tarif.setValue(float(t["tarif"]))
            self.grille.addWidget(lib, i, 0)
            if seuil:
                self.grille.addWidget(seuil, i, 1)
            self.grille.addWidget(tarif, i, 2)
            self.lignes.append((lib, seuil, tarif))

    def _defaut(self):
        from ..reglages import GRILLE_DEFAUT
        self._remplir([dict(x) for x in GRILLE_DEFAUT])

    def accept(self):
        from ..reglages import enregistrer_disposition, enregistrer_grille
        for (genre, cle), r in self.choix_dispo.items():
            if r.isChecked():
                enregistrer_disposition(cle, genre)
        g = []
        for _, seuil, tarif in self.lignes:
            v = tarif.value()
            g.append({"jusqua": round(seuil.value(), 2) if seuil else None,
                      "tarif": int(v) if float(v).is_integer() else round(v, 2)})
        try:
            enregistrer_grille(g)
        except ValueError as e:
            QMessageBox.warning(self, "Grille incorrecte", str(e))
            return
        from ..reglages import enregistrer_reglage
        for cle, r in getattr(self, "choix_icones", {}).items():
            if r.isChecked():
                enregistrer_reglage("affichage_icones", cle)
        from .icones import oublier_mode
        oublier_mode()
        super().accept()
