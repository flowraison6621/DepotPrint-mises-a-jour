"""Onglet « Relevé des quantités » : listes de produits du catalogue → fiche A4 à remplir au stylo."""
from __future__ import annotations

from datetime import datetime

from PySide6.QtCore import QSize, Qt, QTimer, QUrl
from PySide6.QtGui import QDesktopServices, QIcon, QPixmap
from PySide6.QtWidgets import (QAbstractItemView, QButtonGroup, QCheckBox, QDialog, QDialogButtonBox, QHBoxLayout,
                               QHeaderView, QLabel, QLineEdit, QListWidget, QListWidgetItem, QMenu, QMessageBox,
                               QPushButton, QScrollArea, QSpinBox, QTableWidget, QTableWidgetItem, QVBoxLayout,
                               QWidget)

from .. import paths, releve
from ..paths import retrouver_photo

TAILLE_PHOTO = 54


class _NouvelleListe(QDialog):
    """Nom de la liste + rayons du catalogue où prendre les produits."""

    def __init__(self, parent):
        super().__init__(parent)
        from ..hors_ligne import GROUPES
        self.setWindowTitle("➕ Nouvelle liste")
        v = QVBoxLayout(self)
        v.addWidget(QLabel("Nom de la liste :"))
        self.nom = QLineEdit()
        self.nom.setPlaceholderText("ex. Cartes mémoire, Clés USB…")
        v.addWidget(self.nom)
        v.addWidget(QLabel("Produits pris dans :"))
        self.cases = {}
        for cle, lib, rayons in GROUPES:
            c = QCheckBox(lib.replace(",\n", ", "))
            v.addWidget(c)
            self.cases[cle] = (c, rayons)
        b = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        b.button(QDialogButtonBox.StandardButton.Ok).setText("Créer la liste")
        b.button(QDialogButtonBox.StandardButton.Cancel).setText("Annuler")
        b.accepted.connect(self._ok)
        b.rejected.connect(self.reject)
        v.addWidget(b)

    def _ok(self):
        if not self.nom.text().strip() or not self.rayons():
            QMessageBox.warning(self, "Nouvelle liste", "Donne un nom à la liste\net coche au moins un rayon.")
            return
        self.accept()

    def rayons(self) -> list[str]:
        return [r for c, rs in self.cases.values() if c.isChecked() for r in rs]


class OngletReleve(QWidget):
    def __init__(self, fenetre):
        super().__init__()
        self.fenetre = fenetre
        self.cat = fenetre.cat
        self.donnees = releve.charger_listes()
        self.catalogue: list[dict] = []
        self.produits: list[dict] = []          # produits de la liste choisie
        self.filtre = ""                         # sous-catégorie (chip), '' = tout
        self._icones: dict[str, QIcon | None] = {}
        self.doc = None
        self._minuterie = QTimer(self, singleShot=True, interval=350)
        self._minuterie.timeout.connect(self._apercu)

        racine = QHBoxLayout(self)
        racine.setContentsMargins(22, 18, 22, 18)
        racine.setSpacing(16)

        # gauche : listes
        g = QVBoxLayout()
        t = QLabel("📋 Mes listes de relevé")
        t.setObjectName("etiquette")
        g.addWidget(t)
        self.l_listes = QListWidget()
        self.l_listes.setStyleSheet("QListWidget::item { padding: 9px 6px; }")
        self.l_listes.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.l_listes.customContextMenuRequested.connect(self._menu_liste)
        self.l_listes.currentRowChanged.connect(self._liste_choisie)
        g.addWidget(self.l_listes, 1)
        b_new = QPushButton("➕  Nouvelle liste")
        b_new.setObjectName("modifier")
        b_new.clicked.connect(self.nouvelle_liste)
        g.addWidget(b_new)
        gw = QWidget()
        gw.setLayout(g)
        gw.setFixedWidth(250)
        racine.addWidget(gw)

        # milieu : produits
        m = QVBoxLayout()
        self.titre = QLabel("")
        self.titre.setObjectName("etiquette")
        m.addWidget(self.titre)
        self.recherche = QLineEdit()
        self.recherche.setPlaceholderText("🔎 Un mot : 128, Edenwood, Samsung…")
        self.recherche.textChanged.connect(lambda _: self._remplir())
        m.addWidget(self.recherche)
        self.chips = QHBoxLayout()
        self.chips.setSpacing(6)
        self.groupe_chips = QButtonGroup(self)
        self.groupe_chips.setExclusive(True)
        self.chips.setContentsMargins(0, 0, 0, 0)
        self.w_chips = QWidget()
        self.w_chips.setObjectName("chips")
        self.w_chips.setStyleSheet("QWidget#chips { background: transparent; border: none; }")
        self.w_chips.setLayout(self.chips)
        m.addWidget(self.w_chips)
        ht = QHBoxLayout()
        self.b_tout = QPushButton("✖  Tout décocher")         # un seul bouton, qui alterne
        self.b_tout.setMinimumWidth(170)
        self.b_tout.clicked.connect(lambda: self._tout(not self._a_imprimer()))
        ht.addWidget(self.b_tout)
        ht.addStretch()
        m.addLayout(ht)
        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["✔", "Photo", "Réf.", "Produit"])
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(TAILLE_PHOTO + 8)
        self.table.setIconSize(QSize(TAILLE_PHOTO, TAILLE_PHOTO))
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setShowGrid(False)
        h = self.table.horizontalHeader()
        for col, larg in ((0, 40), (1, TAILLE_PHOTO + 16), (2, 100)):
            h.setSectionResizeMode(col, QHeaderView.ResizeMode.Fixed)
            self.table.setColumnWidth(col, larg)
        h.setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        self.table.cellClicked.connect(self._clic)
        self.table.itemChanged.connect(self._coche_changee)
        m.addWidget(self.table, 1)
        racine.addLayout(m, 1)

        # droite : impression
        d = QVBoxLayout()
        t = QLabel("🖨️ Impression")
        t.setObjectName("etiquette")
        d.addWidget(t)
        modes = QHBoxLayout()
        self.groupe_modes = QButtonGroup(self)
        for cle, lib in (("compact", "Compact"), ("standard", "Standard"), ("illustre", "Illustré")):
            b = QPushButton(lib)
            b.setCheckable(True)
            b.setProperty("mode", cle)
            b.setObjectName("mode")
            self.groupe_modes.addButton(b)
            modes.addWidget(b)
        self.groupe_modes.buttonClicked.connect(lambda _: self._options_changees())
        d.addLayout(modes)
        o1 = QHBoxLayout()
        self.c_codes = QCheckBox("Codes-barres")
        self.c_photos = QCheckBox("Photos")
        self.c_nb = QCheckBox("Noir et blanc")
        for c in (self.c_codes, self.c_photos, self.c_nb):
            o1.addWidget(c)
            c.toggled.connect(lambda _: self._options_changees())
        d.addLayout(o1)
        o2 = QHBoxLayout()
        self.c_paysage = QCheckBox("Paysage")
        self.c_paysage.toggled.connect(lambda _: self._options_changees())
        o2.addWidget(self.c_paysage)
        o2.addWidget(QLabel("Hauteur des lignes :"))
        self.s_haut = QSpinBox()
        self.s_haut.setRange(0, 40)
        self.s_haut.setSuffix(" mm")
        self.s_haut.setSpecialValueText("auto")
        self.s_haut.valueChanged.connect(lambda _: self._options_changees())
        o2.addWidget(self.s_haut)
        o2.addStretch()
        d.addLayout(o2)
        o3 = QHBoxLayout()
        o3.addWidget(QLabel("Employé :"))
        self.e_employe = QLineEdit()
        self.e_employe.setPlaceholderText("(facultatif)")
        self.e_employe.textChanged.connect(lambda _: self._options_changees())
        o3.addWidget(self.e_employe)
        d.addLayout(o3)
        from .apercu_feuilles import ZoneApercu
        self.zone_apercu = ZoneApercu(self._apercu)          # toutes les pages, à la largeur du panneau
        self.l_apercu = self.zone_apercu.label
        d.addWidget(self.zone_apercu, 1)
        self.l_pages = QLabel("")
        self.l_pages.setObjectName("petit")
        d.addWidget(self.l_pages)
        b_pdf = QPushButton("📄  EXPORTER EN PDF")
        b_pdf.clicked.connect(self.exporter)
        d.addWidget(b_pdf)
        self.b_imp = QPushButton("🖨️  IMPRIMER LE RELEVÉ")
        self.b_imp.setObjectName("energie")
        self.b_imp.setMinimumHeight(48)
        self.b_imp.clicked.connect(self.imprimer)
        d.addWidget(self.b_imp)
        dw = QWidget()
        dw.setLayout(d)
        dw.setFixedWidth(360)
        racine.addWidget(dw)

        self._poser_options()
        self.charger()

    # -- données ----------------------------------------------------------------------------------
    def charger(self) -> None:
        """(Re)lit le catalogue : après une mise à jour, les listes gardent leurs cases."""
        try:
            self.catalogue = self.cat.base.catalogue_complet()
        except Exception:
            self.catalogue = []
        ligne = max(0, self.l_listes.currentRow())
        self.l_listes.blockSignals(True)
        self.l_listes.clear()
        for li in self.donnees["listes"]:
            self.l_listes.addItem(QListWidgetItem(f"{li.get('emoji') or '📋'}  {li['nom']}"))
        self.l_listes.blockSignals(False)
        if self.donnees["listes"]:
            self.l_listes.setCurrentRow(min(ligne, len(self.donnees["listes"]) - 1))
            self._liste_choisie(self.l_listes.currentRow())

    def _liste(self) -> dict | None:
        r = self.l_listes.currentRow()
        return self.donnees["listes"][r] if 0 <= r < len(self.donnees["listes"]) else None

    def _sauver(self) -> None:
        try:
            releve.enregistrer_listes(self.donnees)
        except OSError:
            pass

    def _liste_choisie(self, _r: int) -> None:
        li = self._liste()
        self.produits = releve.produits_de(li, self.catalogue) if li else []
        self.filtre = ""
        self._chips()
        self._remplir()

    def _chips(self) -> None:
        """Catégories en haut (Stockage : HDD, SSD interne…) ; rien pour une liste sans sous-catégorie."""
        while self.chips.count():
            it = self.chips.takeAt(0)
            if it.widget():
                self.groupe_chips.removeButton(it.widget())
                it.widget().deleteLater()
        presentes = {releve.sous_categorie(a["nom"]) for a in self.produits} - {""}
        self.w_chips.setVisible(bool(presentes))
        if not presentes:
            return
        for sc in [""] + releve.SOUS_CATEGORIES:
            b = QPushButton(sc or "Tout")
            b.setCheckable(True)
            b.setChecked(sc == self.filtre)
            b.setObjectName("chip")
            b.clicked.connect(lambda _=False, v=sc: self._choisir_chip(v))
            self.groupe_chips.addButton(b)
            self.chips.addWidget(b)
        self.chips.addStretch()

    def _choisir_chip(self, sc: str) -> None:
        self.filtre = sc
        for b in self.groupe_chips.buttons():
            b.setChecked(b.text() == (sc or "Tout"))
        self._remplir()

    def visibles(self) -> list[dict]:
        mots = self.recherche.text().lower().split()
        res = []
        for a in self.produits:
            if self.filtre and releve.sous_categorie(a["nom"]) != self.filtre:
                continue
            texte = f"{a['code']} {a['nom']}".lower()
            if all(m in texte for m in mots):
                res.append(a)
        return res

    def _icone(self, a: dict):
        code = a["code"]
        if code not in self._icones:
            ic = None
            f = retrouver_photo(a.get("photo") or "")
            if f:
                from PySide6.QtGui import QImageReader
                lecteur = QImageReader(f)
                taille = lecteur.size()
                if taille.isValid() and max(taille.width(), taille.height()) > 0:
                    lecteur.setScaledSize(taille * (TAILLE_PHOTO * 2 / max(taille.width(), taille.height())))
                img = lecteur.read()
                if not img.isNull():
                    ic = QIcon(QPixmap.fromImage(img))
            self._icones[code] = ic
        return self._icones[code]

    def _remplir(self) -> None:
        li = self._liste()
        decoches = set((li or {}).get("decoches") or [])
        vis = self.visibles()
        self.table.blockSignals(True)
        self.table.setUpdatesEnabled(False)
        self.table.setRowCount(len(vis))
        for r, a in enumerate(vis):
            c = QTableWidgetItem()
            c.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled)
            c.setCheckState(Qt.CheckState.Unchecked if a["code"] in decoches else Qt.CheckState.Checked)
            c.setData(Qt.ItemDataRole.UserRole, a["code"])
            self.table.setItem(r, 0, c)
            p = QTableWidgetItem()
            ic = self._icone(a)
            if ic is not None:
                p.setIcon(ic)
            self.table.setItem(r, 1, p)
            self.table.setItem(r, 2, QTableWidgetItem(a["code"]))
            self.table.setItem(r, 3, QTableWidgetItem(a["nom"]))
        self.table.setUpdatesEnabled(True)
        self.table.blockSignals(False)
        self._maj_titre()
        self._minuterie.start()

    def _maj_titre(self) -> None:
        li = self._liste()
        if not li:
            self.titre.setText("")
            return
        n = len(self.produits)
        k = len(self._a_imprimer())
        if hasattr(self, "b_tout"):
            self.b_tout.setText("✖  Tout décocher" if k else "☑️  Tout cocher")
        if not n:
            self.titre.setText(f"{li.get('emoji') or '📋'} {li['nom']} · aucun produit\n"
                               "(fais la mise à jour du catalogue avec ce rayon coché)")
        else:
            self.titre.setText(f"{li.get('emoji') or '📋'} {li['nom']} · {n} produit{'s' if n > 1 else ''}"
                               f" · ✔ {k} à imprimer")

    def _clic(self, rang: int, col: int) -> None:
        if col == 0:
            return
        it = self.table.item(rang, 0)
        if it is not None:
            it.setCheckState(Qt.CheckState.Unchecked if it.checkState() == Qt.CheckState.Checked
                             else Qt.CheckState.Checked)

    def _coche_changee(self, it) -> None:
        li = self._liste()
        if it.column() != 0 or li is None:
            return
        code = it.data(Qt.ItemDataRole.UserRole)
        dec = set(li.get("decoches") or [])
        if it.checkState() == Qt.CheckState.Checked:
            dec.discard(code)
        else:
            dec.add(code)
        li["decoches"] = sorted(dec)
        self._sauver()
        self._maj_titre()
        self._minuterie.start()

    def _tout(self, coche: bool) -> None:
        li = self._liste()
        if li is None:
            return
        dec = set(li.get("decoches") or [])
        codes = {a["code"] for a in self.visibles()}
        li["decoches"] = sorted(dec - codes if coche else dec | codes)
        self._sauver()
        self._remplir()

    # -- listes -----------------------------------------------------------------------------------
    def nouvelle_liste(self) -> None:
        dlg = _NouvelleListe(self)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        rayons = dlg.rayons()
        emoji = "💾" if rayons == ["stockage"] else ("☎️" if rayons == ["mobiles"] else "📋")
        self.donnees["listes"].append({"nom": dlg.nom.text().strip(), "emoji": emoji, "rayons": rayons,
                                       "decoches": []})
        self._sauver()
        self.charger()
        self.l_listes.setCurrentRow(len(self.donnees["listes"]) - 1)

    def _menu_liste(self, pos) -> None:
        r = self.l_listes.indexAt(pos).row()
        if r < 0:
            return
        menu = QMenu(self)
        a_sup = menu.addAction("🗑️  Supprimer cette liste")
        if menu.exec(self.l_listes.mapToGlobal(pos)) is a_sup:
            nom = self.donnees["listes"][r]["nom"]
            if QMessageBox.question(self, "Supprimer la liste",
                                    f"Supprimer la liste « {nom} » ?\n"
                                    "Les produits restent dans le catalogue.") == QMessageBox.StandardButton.Yes:
                del self.donnees["listes"][r]
                self._sauver()
                self.charger()

    # -- impression -------------------------------------------------------------------------------
    def _poser_options(self) -> None:
        o = self.donnees["options"]
        for b in self.groupe_modes.buttons():
            b.setChecked(b.property("mode") == o["mode"])
        for c, cle in ((self.c_codes, "codes_barres"), (self.c_photos, "photos"), (self.c_nb, "noir_blanc"),
                       (self.c_paysage, "paysage")):
            c.blockSignals(True)
            c.setChecked(bool(o[cle]))
            c.blockSignals(False)
        self.s_haut.blockSignals(True)
        self.s_haut.setValue(int(o["hauteur_mm"] or 0))
        self.s_haut.blockSignals(False)
        self.e_employe.setText(o.get("employe") or "")
        self.c_photos.setEnabled(o["mode"] == "illustre")

    def _options_changees(self) -> None:
        o = self.donnees["options"]
        b = self.groupe_modes.checkedButton()
        o["mode"] = b.property("mode") if b else "illustre"
        o["codes_barres"] = self.c_codes.isChecked()
        o["photos"] = self.c_photos.isChecked()
        o["noir_blanc"] = self.c_nb.isChecked()
        o["paysage"] = self.c_paysage.isChecked()
        o["hauteur_mm"] = self.s_haut.value()
        o["employe"] = self.e_employe.text().strip()
        self.c_photos.setEnabled(o["mode"] == "illustre")
        self._sauver()
        self._minuterie.start()

    def _a_imprimer(self) -> list[dict]:
        """Produits cochés parmi ceux affichés (catégorie et recherche en cours), dans l'ordre du rayon."""
        li = self._liste() or {}
        dec = set(li.get("decoches") or [])
        return [a for a in self.visibles() if a["code"] not in dec]

    def _document(self):
        li = self._liste()
        if not li:
            return None
        o = self.donnees["options"]
        lignes = [releve.Ligne(a["code"], a["nom"], retrouver_photo(a.get("photo") or ""),
                               releve.sous_categorie(a["nom"])) for a in self._a_imprimer()]
        if not lignes:
            return None
        titre = li["nom"] + (f" · {self.filtre}" if self.filtre else "")
        opt = releve.Options(mode=o["mode"], paysage=o["paysage"], photos=o["photos"],
                             codes_barres=o["codes_barres"], noir_blanc=o["noir_blanc"],
                             hauteur_mm=float(o["hauteur_mm"] or 0), titre=titre, employe=o.get("employe") or "")
        return releve.creer_pdf(lignes, opt)

    def _apercu(self) -> None:
        try:
            self.doc = self._document()
        except Exception as e:                       # jamais de plantage pour un aperçu
            self.doc = None
            self.zone_apercu.texte(f"Aperçu impossible :\n{e}")
            return
        if self.doc is None:
            self.zone_apercu.texte("\nCoche au moins un produit.")
            self.l_pages.setText("")
            self.b_imp.setEnabled(False)
            return
        try:
            self.zone_apercu.montrer(self.doc)
        except Exception as e:
            self.zone_apercu.texte(f"Aperçu impossible :\n{e}")
            return
        n = self.doc.page_count
        self.l_pages.setText(f"{n} page{'s' if n > 1 else ''} A4")
        self.b_imp.setEnabled(True)

    def exporter(self) -> None:
        self._apercu()
        if self.doc is None:
            return
        li = self._liste()
        nom = "Releve_" + "".join(ch if ch.isalnum() else "_" for ch in li["nom"]) + \
              datetime.now().strftime("_%Y-%m-%d_%Hh%M")
        dest = paths.output_dir() / f"{nom}.pdf"
        try:
            dest.parent.mkdir(parents=True, exist_ok=True)
            self.doc.save(dest)
        except (PermissionError, OSError) as e:
            QMessageBox.warning(self, "PDF", f"Impossible d'enregistrer le PDF :\n{e}")
            return
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(dest)))

    def imprimer(self) -> None:
        self._apercu()
        if self.doc is None:
            return
        from . import impression
        try:
            impression.imprimer(self, self.doc, "Relevé des quantités")
        except Exception as e:
            QMessageBox.critical(self, "Impression impossible", str(e))
