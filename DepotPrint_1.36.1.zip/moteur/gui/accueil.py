"""Écran d'accueil : « Que veux-tu faire ? » — trois grandes cartes."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget

# ordre demandé : Étiquettes énergie · Relevé de quantité · Étiquettes produits
CARTES = (
    ("energie", "🍃", "Étiquettes énergie", "L'étiquette officielle,\nen taille réelle.", "#2E7D32"),
    ("releve", "✍️", "Relevé de quantité", "La fiche A4 à remplir\nau stylo en rayon.", "#2F8CCB"),
    ("produits", "🏷️", "Étiquettes produits", "Les affiches du rayon,\ndeux par feuille A4.", "#D97E00"),
)


class _Carte(QPushButton):
    def __init__(self, emoji: str, titre: str, texte: str, couleur: str):
        super().__init__()
        self.setObjectName("carteAccueil")
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFixedSize(330, 330)
        self.setStyleSheet(f"""
            QPushButton#carteAccueil {{ background: white; border: 3px solid {couleur}; border-radius: 22px; }}
            QPushButton#carteAccueil:hover {{ background: #FAFBFC; border-width: 5px; }}
        """)
        v = QVBoxLayout(self)
        v.setContentsMargins(18, 18, 18, 18)
        v.addStretch()
        for txt, style in ((emoji, "font-size: 64pt; background: transparent;"),
                           (titre, f"font-size: 19pt; font-weight: 800; color: {couleur}; background: transparent;"),
                           (texte, "font-size: 12pt; color: #555; background: transparent;")):
            l = QLabel(txt)
            l.setAlignment(Qt.AlignmentFlag.AlignHCenter)
            l.setStyleSheet(style)
            l.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
            v.addWidget(l)
            v.addSpacing(8)
        v.addStretch()


class EcranAccueil(QWidget):
    def __init__(self, fenetre):
        super().__init__()
        self.fenetre = fenetre
        v = QVBoxLayout(self)
        v.setContentsMargins(30, 30, 30, 30)
        v.addStretch(2)
        t = QLabel("Que veux-tu faire ?")
        t.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        t.setStyleSheet("font-size: 22pt; font-weight: 800;")
        v.addWidget(t)
        s = QLabel("Clique sur une carte.")
        s.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        s.setStyleSheet("font-size: 12pt; color: #666;")
        v.addWidget(s)
        v.addSpacing(36)
        h = QHBoxLayout()
        h.setSpacing(34)
        h.addStretch()
        self.cartes = {}
        for mode, emoji, titre, texte, couleur in CARTES:
            c = _Carte(emoji, titre, texte, couleur)
            c.clicked.connect(lambda _=False, m=mode: fenetre.ouvrir_mode(m))
            h.addWidget(c)
            self.cartes[mode] = c
        h.addStretch()
        v.addLayout(h)
        v.addSpacing(30)
        self.l_cat = QLabel("")
        self.l_cat.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        self.l_cat.setStyleSheet("color: #888; font-size: 10.5pt;")
        v.addWidget(self.l_cat)
        v.addStretch(3)
        self.maj()

    def maj(self) -> None:
        base = self.fenetre.cat.base
        n = base.nb_articles()
        self.l_cat.setText(f"📦 Catalogue hors ligne : {n} produits · mis à jour le {base.valeur('catalogue_date', '?')}"
                           if n else "📦 Pas encore de catalogue : clique sur « Catalogue hors ligne » en haut.")
