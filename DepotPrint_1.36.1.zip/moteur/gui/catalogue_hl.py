"""Fenêtre « Catalogue hors ligne » : mise à jour des rayons, avancement et bilan."""

from __future__ import annotations

import time

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtWidgets import (
    QCheckBox, QDialog, QFrame, QGridLayout, QHBoxLayout, QLabel, QMessageBox, QProgressBar,
    QPushButton, QVBoxLayout, QWidget,
)

from .. import hors_ligne
from ..catalogue import Catalogue
from ..models import ErreurRecherche


class _Travail(QThread):
    progres = Signal(int, int, str)
    fini = Signal(object)
    echec = Signal(str)

    def __init__(self, cat: Catalogue, rayons: list[str]):
        super().__init__()
        self.cat, self.rayons, self.stop = cat, rayons, False

    def run(self):
        try:
            b = hors_ligne.mettre_a_jour(self.cat.base, self.cat.client, self.cat.dossier, self.rayons,
                                        lambda i, n, t: self.progres.emit(i, n, t), lambda: self.stop)
        except ErreurRecherche as e:
            self.echec.emit(str(e))
        except Exception as e:  # jamais de plantage du logiciel
            self.echec.emit(f"Erreur inattendue : {e}")
        else:
            self.fini.emit(b)


def _court(nom: str) -> str:
    from ..noms import nom_court
    return nom_court(nom) or nom


def _liste(items, n=3, fmt=lambda x: _court(x[1])) -> str:
    """« 12 — SAMSUNG A17 128 GO, MOTOROLA G06 256 GO 4G… » (détail complet en info-bulle)."""
    if not items:
        return "0"
    detail = ", ".join(fmt(x) for x in items[:n])
    return f"{len(items)} — {detail}" + (f" et {len(items) - n} autre(s)" if len(items) > n else "")


class FenetreCatalogue(QDialog):
    def __init__(self, parent: QWidget, cat: Catalogue):
        super().__init__(parent)
        self.setWindowTitle("Catalogue hors ligne")
        self.resize(700, 640)
        self.cat = cat
        self.travail: _Travail | None = None
        self.debut = 0.0

        v = QVBoxLayout(self)
        t = QLabel("Mettre à jour le catalogue")
        t.setStyleSheet("font-size: 14pt; font-weight: 800;")
        v.addWidget(t)
        a = QLabel("Télécharge depuis electrodepot.fr la liste des produits et leurs photos. "
                   "Ensuite, les affiches se font sans Internet. Faites-le avant chaque série d'affiches.")
        a.setWordWrap(True)
        a.setObjectName("petit")
        v.addWidget(a)

        f = QFrame()
        f.setObjectName("carte")
        fl = QVBoxLayout(f)
        fl.setContentsMargins(16, 12, 16, 12)
        he = QHBoxLayout()
        e = QLabel("Rayons à télécharger")
        e.setObjectName("etiquette")
        he.addWidget(e)
        he.addStretch()
        self.b_tout = QPushButton("☑️ Tout cocher")
        self.b_tout.clicked.connect(self._tout_cocher)
        he.addWidget(self.b_tout)
        fl.addLayout(he)
        self.cases = {}
        grille = QHBoxLayout()                       # mêmes groupes que les catégories de « Parcourir »
        grille.setSpacing(28)
        colonnes = (QVBoxLayout(), QVBoxLayout())
        self._rayons_de = {}
        for i, (cle, libelle, rayons) in enumerate(hors_ligne.GROUPES):
            c = QCheckBox(libelle.replace(",\n", ", "))   # ici la place ne manque pas : 2 lignes au plus
            colonnes[0 if i < 6 else 1].addWidget(c)
            c.setChecked(False)                       # rien de coché d'avance : on choisit ses rayons
            c.toggled.connect(lambda _: self._maj_lancer())
            self.cases[cle] = c
            self._rayons_de[cle] = rayons
        for col in colonnes:
            col.setSpacing(6)
            col.addStretch()
            grille.addLayout(col)
        grille.addStretch()
        fl.addLayout(grille)
        self.consigne = QLabel("⚠️ Cochez le ou les rayons à mettre à jour.\n"
                               "(la mise à jour ne peut pas démarrer sans rayon coché)")
        self.consigne.setStyleSheet("color: #B45F00; font-weight: 700;")
        fl.addWidget(self.consigne)
        v.addWidget(f)

        self.barre = QProgressBar()
        self.barre.setRange(0, 1)
        self.barre.setValue(0)
        self.barre.setFormat("")
        v.addWidget(self.barre)
        self.detail = QLabel("")
        self.detail.setObjectName("petit")
        self.detail.setWordWrap(True)
        v.addWidget(self.detail)

        r = QFrame()
        r.setObjectName("carte")
        self.grille = QGridLayout(r)
        self.grille.setContentsMargins(16, 12, 16, 12)
        self.grille.setColumnStretch(1, 1)
        self.valeurs = {}
        for i, (cle, lib) in enumerate((("nouveaux", "🆕 Nouveaux produits"), ("prix", "💶 Prix modifiés"),
                                        ("tranche", "Tranche de protection"), ("retires", "🚫 Plus sur le site\n(gardés au catalogue)"),
                                        ("photos", "Photos manquantes"), ("etiquettes", "🍃 Étiquettes énergie"),
                                        ("date", "Dernière mise à jour"))):
            l = QLabel(lib)
            l.setObjectName("etiquette")
            self.grille.addWidget(l, i, 0)
            val = QLabel("—")
            val.setWordWrap(True)
            val.setStyleSheet("font-weight: 700;")
            self.grille.addWidget(val, i, 1)
            self.valeurs[cle] = val
        n = cat.base.nb_articles()
        self.valeurs["date"].setText(f"{cat.base.valeur('catalogue_date', 'jamais')}  ({n} produits)")
        v.addWidget(r)
        v.addStretch()

        hb = QHBoxLayout()
        self.b_lancer = QPushButton("⬇️ Lancer la mise à jour")
        self.b_lancer.setObjectName("principal")
        self.b_lancer.clicked.connect(self.lancer)
        self.b_stop = QPushButton("Arrêter")
        self.b_stop.setEnabled(False)
        self.b_stop.clicked.connect(self.arreter)
        self.b_fermer = QPushButton("Fermer")
        self.b_fermer.clicked.connect(self.close)
        hb.addWidget(self.b_lancer)
        hb.addWidget(self.b_stop)
        hb.addStretch()
        hb.addWidget(self.b_fermer)
        v.addLayout(hb)
        self._maj_lancer()

    def _maj_lancer(self) -> None:
        """« Lancer la mise à jour » seulement quand au moins un rayon est coché."""
        coche = any(c.isChecked() for c in self.cases.values())
        en_cours = getattr(self, "_en_cours", False)
        self.b_lancer.setEnabled(coche and not en_cours)
        self.consigne.setVisible(not coche)
        if hasattr(self, "b_tout"):
            tout = all(c.isChecked() for c in self.cases.values())
            self.b_tout.setText("✖ Tout décocher" if tout else "☑️ Tout cocher")
            self.b_tout.setEnabled(not en_cours)

    def _tout_cocher(self) -> None:
        """Un seul bouton : tout cocher, ou tout décocher quand tout est déjà coché."""
        tout = all(c.isChecked() for c in self.cases.values())
        for c in self.cases.values():
            c.setChecked(not tout)

    def lancer(self):
        rayons = [r for k, c in self.cases.items() if c.isChecked() for r in self._rayons_de[k]]
        if not rayons:
            QMessageBox.information(self, "Aucun rayon", "Cochez au moins un rayon.")
            return
        self._en_cours = True
        self.travail = _Travail(self.cat, rayons)
        self.travail.progres.connect(self._progres)
        self.travail.fini.connect(self._fini)
        self.travail.echec.connect(self._echec)
        self.debut = time.monotonic()
        for c in self.cases.values():
            c.setEnabled(False)
        self.b_lancer.setEnabled(False)
        self.b_stop.setEnabled(True)
        self.b_fermer.setEnabled(False)
        self.barre.setRange(0, 0)               # lecture des rayons : durée inconnue
        self.detail.setText("Lecture des rayons du site…")
        self.travail.start()

    def arreter(self):
        if self.travail:
            self.travail.stop = True
            self.b_stop.setEnabled(False)
            self.detail.setText("Arrêt demandé… Le catalogue précédent est conservé.")

    def _progres(self, i: int, n: int, texte: str):
        if texte.startswith(("Photos", "Contenu des boîtes", "Étiquettes énergie")):
            if self.barre.maximum() != n:
                self.barre.setRange(0, max(1, n))
                self.barre.setFormat("%v / %m produits")
                self._t_photos = time.monotonic()
            self.barre.setValue(i)
            reste = ""
            if i > 5:
                ecoule = time.monotonic() - self._t_photos
                s = ecoule / i * (n - i)
                reste = f"  ·  environ {max(1, round(s / 60))} min restantes" if s > 60 else "  ·  moins d'une minute"
            self.detail.setText(texte[:90] + reste)
        else:
            self.detail.setText(texte)

    def _remettre(self):
        for c in self.cases.values():
            c.setEnabled(True)
        self.b_stop.setEnabled(False)
        self.b_fermer.setEnabled(True)
        self._en_cours = False
        self._maj_lancer()

    def _fini(self, b):
        self._remettre()
        if b.arrete:
            self.barre.setRange(0, 1)
            self.barre.setValue(0)
            self.barre.setFormat("")
            self.detail.setText("Mise à jour arrêtée : le catalogue précédent est conservé.")
            return
        self.barre.setRange(0, 1)
        self.barre.setValue(1)
        self.barre.setFormat("Terminé")
        self.detail.setText(f"✔ Catalogue à jour : {b.total} produits disponibles hors ligne.")
        for cle, items in (("nouveaux", b.nouveaux), ("prix", b.prix_modifies), ("retires", b.retires),
                           ("photos", b.photos_manquantes)):
            self.valeurs[cle].setToolTip("\n".join(f"{x[0]}  {x[1]}" for x in items[:60]))
        self.valeurs["nouveaux"].setText(_liste(b.nouveaux))
        self.valeurs["prix"].setText(_liste(b.prix_modifies))
        self.valeurs["tranche"].setText(
            _liste(b.tranche_modifiee, fmt=lambda x: f"{_court(x[1])} ({x[2] or '—'} → {x[3] or '—'} €/mois)")
            + ("  → réimprimez ces affiches" if b.tranche_modifiee else ""))
        self.valeurs["retires"].setText(_liste(b.retires))
        self.valeurs["photos"].setText(_liste(b.photos_manquantes))
        self.valeurs["etiquettes"].setText(f"{b.etiquettes} produit(s)\n(disponibles sans Internet)")
        self.valeurs["date"].setText(f"{b.date}  ({b.total} produits)")
        for cle, coul in (("nouveaux", "#1E6B36"), ("prix", "#8A5A00"), ("tranche", "#A3241B")):
            self.valeurs[cle].setStyleSheet(f"font-weight: 700; color: {coul};")

    def _echec(self, msg: str):
        self._remettre()
        self.barre.setRange(0, 1)
        self.barre.setValue(0)
        self.barre.setFormat("")
        self.detail.setText(f"✖ {msg}  Le catalogue précédent est conservé.")

    def closeEvent(self, e):
        if self.travail and self.travail.isRunning():
            e.ignore()
            return
        super().closeEvent(e)
