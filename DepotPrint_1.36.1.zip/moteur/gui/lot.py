"""Onglet « Plusieurs produits » : une case numérotée par code → une feuille A4 par code."""

from __future__ import annotations

import re
from datetime import datetime

from PySide6.QtCore import Qt, QThread, QTimer, Signal
from PySide6.QtGui import QKeySequence
from PySide6.QtWidgets import (
    QApplication, QButtonGroup, QDialog, QDialogButtonBox, QFrame, QHBoxLayout, QLabel, QLineEdit,
    QMessageBox, QPlainTextEdit, QProgressBar, QPushButton, QRadioButton, QScrollArea, QVBoxLayout,
    QWidget,
)

from .. import affiche, paths
from ..catalogue import Catalogue
from ..models import Ambiguite, ErreurRecherche, Produit
from ..reglages import tarif_affiche, texte_tarif
from . import impression
from .dialogues import SaisieManuelle
from .edition import FenetreEdition

CASES_AU_DEPART = 8
COULEURS = {"ok": "#1E6B36", "avert": "#8A5A00", "erreur": "#A3241B", "attente": "#1F4E8C"}
SYMBOLES = {"ok": "✅ ", "avert": "⚠️ ", "erreur": "❌ ", "attente": "⏳ ", "vide": ""}

STYLE = """
QFrame#ligne { background: white; border: 1px solid #E2E4E8; border-radius: 8px; }
QFrame#ligne[etat="erreur"] { border-color: #F5C2BE; }
QFrame#ligne[etat="avert"] { border-color: #F2D58C; }
QLabel#num { color: #5B6270; font-weight: 700; font-size: 12pt; }
QLineEdit#case { font-family: Consolas, "Courier New", monospace; font-size: 15pt; font-weight: 700;
                 padding: 4px 8px; border: 2px solid #C9CDD4; border-radius: 6px; }
QLineEdit#case:focus { border-color: #FF9900; }
QLineEdit#case[deux="true"] { font-size: 12pt; }
QPushButton#plus { background: white; color: #E68A00; border: 2px solid #FF9900; border-radius: 6px;
                   font-size: 15pt; font-weight: 800; padding: 0; }
QPushButton#plus:hover { background: #FFF3E0; }
QLabel#legendeVersion { color: #5B6270; font-size: 8pt; font-weight: 700; }
QPushButton#plus:disabled { border-color: transparent; background: transparent; color: #E68A00; }
QPushButton#suppr { border: none; background: transparent; color: #9AA0AA; font-size: 13pt; padding: 2px 6px; }
QPushButton#suppr:hover { color: #A3241B; background: transparent; }
QLabel#compteur { background: white; border: 1px solid #E2E4E8; border-radius: 8px; padding: 8px; }
QScrollArea#zoneCases, QWidget#interieurCases { background: transparent; }
"""


def lire_codes(texte: str) -> list[str]:
    """Découpe un texte collé (lignes, espaces, virgules, points-virgules) en codes."""
    texte = re.sub(r"\s*\+\s*", "+", texte or "")          # « 10017363 + 10020472 » reste ensemble
    return [c for c in (x.strip() for x in re.split(r"[\s,;]+", texte)) if c]


def _taille_deux_codes(champ, texte: str) -> None:
    """« code1 + code2 » : texte plus petit pour que les deux codes restent lisibles en entier."""
    deux = "+" in texte
    if champ.property("deux") != deux:
        champ.setProperty("deux", deux)
        champ.style().unpolish(champ)
        champ.style().polish(champ)


def bouton_plus(hauteur: int) -> QPushButton:
    """Petit « + » orange : ouvre une 2e case pour le code de la 2e version (une seule affiche)."""
    b = QPushButton("+")
    b.setObjectName("plus")
    b.setFixedSize(hauteur, hauteur)
    b.setCursor(Qt.CursorShape.PointingHandCursor)
    b.setToolTip("Ajouter un 2e code\n(deux versions dans la même cloche : une seule affiche)")
    taille = b.sizePolicy()
    taille.setRetainSizeWhenHidden(True)          # rien ne bouge quand il apparaît
    b.setSizePolicy(taille)
    b.hide()
    return b


def bouton_moins(hauteur: int) -> QPushButton:
    b = QPushButton("✕")
    b.setObjectName("suppr")
    b.setFixedSize(hauteur, hauteur)
    b.setCursor(Qt.CursorShape.PointingHandCursor)
    b.setToolTip("Retirer le 2e code")
    return b


class CaseCode(QLineEdit):
    """Case d'un code. Coller une liste la répartit dans les cases suivantes."""

    collage_multiple = Signal(object, list)    # case, codes
    suivante = Signal(object)

    def __init__(self):
        super().__init__()
        self.setObjectName("case")
        self.setFixedWidth(190)
        self.setPlaceholderText("code…")
        self.setMaxLength(45)
        self.textChanged.connect(lambda t: _taille_deux_codes(self, t if self.width() > 160 else "+"))
        self.returnPressed.connect(lambda: self.suivante.emit(self))

    def _coller(self, texte: str) -> bool:
        codes = lire_codes(texte)
        if len(codes) > 1:
            self.collage_multiple.emit(self, codes)
            return True
        return False

    def keyPressEvent(self, e):
        if e.matches(QKeySequence.StandardKey.Paste) and self._coller(QApplication.clipboard().text()):
            e.accept()
            return
        super().keyPressEvent(e)

    def contextMenuEvent(self, e):
        menu = self.createStandardContextMenu()
        for a in menu.actions():
            if a.text().replace("&", "").lower().startswith(("coller", "paste")):
                a.triggered.disconnect()
                a.triggered.connect(lambda: self._coller(QApplication.clipboard().text())
                                    or self.insert(QApplication.clipboard().text().strip()))
        menu.exec(e.globalPos())


def _resume_court(v: Produit, sans_recond: bool = False) -> str:
    """« Reconditionné · Excellent état + batterie neuve · 7 €/mois » (sans la liste des couleurs)."""
    mm = v.mentions
    if mm.reconditionne:
        etat = mm.etat.capitalize() if mm.etat else ""
        t = (etat or "Reconditionné") if sans_recond else "Reconditionné" + (f" · {etat}" if etat else "")
    else:
        from ..affiche import _reseau
        t = "Neuf" + (f" · {_reseau(v)}" if _reseau(v) else "")
    if mm.batterie_neuve:
        t += " + batterie neuve"
    tarif = tarif_affiche(v)
    if tarif:
        t += f"&nbsp;·&nbsp;{texte_tarif(tarif)}&nbsp;€/mois"
    return t


class LigneCode(QFrame):
    double_clic = Signal(object)
    vider = Signal(object)

    def __init__(self, numero: int):
        super().__init__()
        self.setObjectName("ligne")
        self.produit: Produit | None = None
        self.etat = "vide"
        h = QHBoxLayout(self)
        h.setContentsMargins(14, 6, 10, 6)
        self.num = QLabel(str(numero))
        self.num.setObjectName("num")
        self.num.setFixedWidth(34)
        h.addWidget(self.num)
        # 1re case, et 2e case (2e version) qui s'ouvre à côté avec le « + »
        self.case = CaseCode()
        self.case2 = CaseCode()
        self.case2.setPlaceholderText("code…")
        # sous les cases : « Entrer la référence » (ou « les références ») tant qu'on n'a pas cherché,
        # puis « Version 1 / 2 » (même téléphone) ou « Produit 1 / 2 » (deux téléphones différents)
        from PySide6.QtWidgets import QGridLayout
        gc = QGridLayout()
        gc.setHorizontalSpacing(6)
        gc.setVerticalSpacing(1)
        self.b_plus = bouton_plus(30)
        gc.addWidget(self.case, 0, 0)
        gc.addWidget(self.b_plus, 0, 1)
        gc.addWidget(self.case2, 0, 2)
        self.legendes = []
        for col in (0, 2):
            lg = QLabel("")
            lg.setObjectName("legendeVersion")
            lg.setAlignment(Qt.AlignmentFlag.AlignCenter)
            gc.addWidget(lg, 1, col)
            self.legendes.append(lg)
        self.leg_commun = QLabel("Entrer les références")
        self.leg_commun.setObjectName("legendeVersion")
        self.leg_commun.setAlignment(Qt.AlignmentFlag.AlignCenter)
        gc.addWidget(self.leg_commun, 1, 0, 1, 3)
        h.addLayout(gc)
        self.b_moins = bouton_moins(26)
        self.b_moins.clicked.connect(self.fermer_2e)
        h.addWidget(self.b_moins)
        self.case2.hide()
        self.b_moins.hide()
        self.b_plus.clicked.connect(self.ouvrir_2e)
        self.case.textChanged.connect(lambda _: self._maj_plus())
        self.case2.textEdited.connect(lambda _: self.definir("vide", None, ""))
        self.case2.returnPressed.connect(lambda: self.case.suivante.emit(self.case))
        self.nom = QLabel("")
        self.nom.setStyleSheet("font-weight: 700;")
        self.nom.setMinimumWidth(120)
        self.nom.setWordWrap(True)          # mentions longues : à la ligne, jamais coupées
        h.addWidget(self.nom, 1)
        self.b_modifier = QPushButton("✏️ Modifier")
        self.b_modifier.setObjectName("modifierPetit")
        self.b_modifier.setToolTip("Modifier l'affiche de ce produit\n(nom, mentions, contenu de la boîte, photo…)")
        self.b_modifier.setCursor(Qt.CursorShape.PointingHandCursor)
        self.b_modifier.setFixedWidth(96)
        self.b_modifier.clicked.connect(lambda: self.double_clic.emit(self))
        garde = self.b_modifier.sizePolicy()
        garde.setRetainSizeWhenHidden(True)        # la ligne ne bouge pas quand le bouton apparaît
        self.b_modifier.setSizePolicy(garde)
        self.b_modifier.hide()
        h.addWidget(self.b_modifier)
        h.addSpacing(10)
        self.statut = QLabel("")
        self.statut.setFixedWidth(120)
        self.statut.setWordWrap(True)
        h.addWidget(self.statut)
        x = QPushButton("✕")
        x.setObjectName("suppr")
        x.setFixedWidth(30)
        x.setToolTip("Vider cette case")
        x.setCursor(Qt.CursorShape.PointingHandCursor)
        x.clicked.connect(lambda: self.vider.emit(self))
        h.addWidget(x)
        self.case.textEdited.connect(lambda _: self.definir("vide", None, ""))
        self._maj_legendes()

    def code(self) -> str:
        c1 = self.case.text().strip()
        c2 = self.case2.text().strip() if not self.case2.isHidden() else ""
        return f"{c1} + {c2}" if c1 and c2 else c1

    def _maj_plus(self) -> None:
        deux = not self.case2.isHidden()
        # deux cases : le « + » reste entre elles, comme un signe
        self.b_plus.setVisible(deux or (bool(self.case.text().strip()) and "+" not in self.case.text()))
        self.b_plus.setEnabled(not deux)

    def _deux_cases(self, oui: bool) -> None:
        for c in (self.case, self.case2):
            c.setFixedWidth(98 if oui else 190)          # deux cases côte à côte
            _taille_deux_codes(c, "+" if oui else c.text())
        self.case2.setVisible(oui)
        self.b_moins.setVisible(oui)
        if not oui:
            self.case2.clear()
        self._maj_plus()
        self._maj_legendes()

    def _maj_legendes(self) -> None:
        deux = not self.case2.isHidden()
        p = self.produit
        trouve = deux and p is not None and p.version2 is not None
        if trouve:
            from ..affiche import libelle_version
            for k, lg in enumerate(self.legendes):
                lg.setText(libelle_version(p, p.version2, k))
                lg.show()
            self.leg_commun.hide()
        elif deux:
            for lg in self.legendes:
                lg.hide()
            self.leg_commun.setText("Entrer les références")
            self.leg_commun.show()
        else:
            self.legendes[1].hide()
            self.leg_commun.hide()
            self.legendes[0].setText("Entrer la référence")
            self.legendes[0].setVisible(p is None and self.etat == "vide")   # pas sous un code introuvable

    def ouvrir_2e(self) -> None:
        self._deux_cases(True)
        self.case2.setFocus()

    def fermer_2e(self) -> None:
        self._deux_cases(False)
        self.definir("vide", None, "")
        self.case.setFocus()

    def mettre_code(self, code: str) -> None:
        """« 10017363+10020472 » (liste collée) : chaque code dans sa case."""
        morceaux = [m.strip() for m in code.split("+") if m.strip()]
        self._deux_cases(len(morceaux) > 1)
        self.case.setText(morceaux[0] if morceaux else "")
        if len(morceaux) > 1:
            self.case2.setText(morceaux[1])
        self._maj_plus()

    def definir(self, etat: str, produit: Produit | None, message: str):
        self.etat = etat
        self.produit = produit
        nom = produit.nom_affiche if produit else ""
        if produit is not None and produit.version2 is None and nom:
            from ..reseau import nom_produit_seul
            nom = nom_produit_seul(produit)               # tel qu'imprimé, avec le réseau
        self._maj_legendes()
        if produit is not None and produit.version2 is not None:
            from ..affiche import nom_deux_versions
            nom = nom_deux_versions(produit, produit.version2).replace("\n", "<br>")   # le nom tel qu'imprimé
        lignes = []                                   # une ligne courte par version, jamais coupée
        if produit:
            versions = [produit] + ([produit.version2] if produit.version2 is not None else [])
            commun_recond = len(versions) == 2 and all(v.mentions.reconditionne for v in versions)
            from ..affiche import _capacite, differences_versions
            capa = len(versions) == 2 and differences_versions(*versions)[0]
            for k, v in enumerate(versions):
                t = _resume_court(v, sans_recond=commun_recond)
                if len(versions) == 2:                       # même structure que la carte et l'affiche
                    from ..affiche import resume_version
                    t = resume_version(v).replace(" Go", "&nbsp;Go")
                    tarif = tarif_affiche(v)
                    if tarif:
                        t += f"&nbsp;·&nbsp;{texte_tarif(tarif)}&nbsp;€/mois"
                if len(versions) == 2:
                    from ..affiche import libelle_version
                    lib = libelle_version(*versions, k).replace(" ", "&nbsp;")
                    t = (f"<span style='background:#1C1F24; color:white; font-weight:700'>"
                         f"&nbsp;{lib}&nbsp;</span>&nbsp; {t}")
                lignes.append(t)
        details = "<br>".join(lignes)
        taille = "8pt" if len(lignes) > 1 else "8.5pt"
        self.nom.setText(f"{nom}<br><span style='color:#3D6B4A; font-size:{taille}; font-weight:600'>{details}</span>"
                         if details else nom)
        self.nom.setToolTip(produit.mentions.resume(tarif_affiche(produit)) if produit else "")
        self.b_modifier.setVisible(produit is not None)
        court = message
        if etat == "erreur":                                # message complet en info-bulle
            court = "Introuvable" if "introuvable" in message.lower() else "Erreur"
        if etat == "ok" and message.startswith("Prêt"):     # « Prêt (catalogue hors ligne) » : détail en info-bulle
            court = "Prêt" + ("\n(plus sur le site)" if "plus sur le site" in message else "")
        from .icones import txt
        self.statut.setText(txt(SYMBOLES.get(etat, "") + court))
        self.statut.setToolTip(message)
        coul = COULEURS.get(etat)
        self.statut.setStyleSheet(f"color: {coul}; font-weight: 600;" if coul else "")
        self.setProperty("etat", etat)
        self.style().unpolish(self)
        self.style().polish(self)

    def mouseDoubleClickEvent(self, e):
        self.double_clic.emit(self)
        super().mouseDoubleClickEvent(e)


class _Travail(QThread):
    resultat = Signal(int, object, str, str)     # index de ligne, produit|None, état, message

    def __init__(self, cat: Catalogue, taches: list[tuple[int, str]]):
        super().__init__()
        self.cat, self.taches = cat, taches
        self.stop = False

    def run(self):
        for i, code in self.taches:
            if self.stop:
                break
            try:
                rep = self.cat.obtenir(code)
                p = rep.produit
                avert = rep.avertissement or p.avertissement or ("" if p.verifie else "non vérifié")
                self.resultat.emit(i, p, "avert" if avert else "ok", avert or
                                   ("Prêt (catalogue, plus sur le site)" if rep.retire
                                    else "Prêt (catalogue hors ligne)" if rep.origine == "catalogue"
                                    else "Prêt (enregistré)" if rep.depuis_cache else "Prêt (vérifié sur le site)"))
            except Ambiguite as e:
                self.resultat.emit(i, None, "erreur", f"{e} Ouvrez-le dans l'onglet « Un produit ».")
            except ErreurRecherche as e:
                self.resultat.emit(i, None, "erreur", str(e))
            except Exception as e:  # une référence en échec n'arrête jamais le lot
                self.resultat.emit(i, None, "erreur", f"Erreur inattendue : {e}")


class CollerListe(QDialog):
    def __init__(self, parent):
        super().__init__(parent)
        self.setWindowTitle("Coller une liste de codes")
        self.resize(420, 420)
        v = QVBoxLayout(self)
        a = QLabel("Collez vos codes ci-dessous (un par ligne). Ils seront placés dans les cases vides.")
        a.setWordWrap(True)
        v.addWidget(a)
        self.texte = QPlainTextEdit()
        self.texte.setStyleSheet("font-family: Consolas, monospace; font-size: 13pt;")
        v.addWidget(self.texte, 1)
        b = QDialogButtonBox()
        ok = b.addButton("Placer dans les cases", QDialogButtonBox.ButtonRole.AcceptRole)
        ok.setObjectName("principal")
        b.addButton("Annuler", QDialogButtonBox.ButtonRole.RejectRole)
        b.accepted.connect(self.accept)
        b.rejected.connect(self.reject)
        v.addWidget(b)


class OngletLot(QWidget):
    def __init__(self, cat: Catalogue, fenetre):
        super().__init__()
        self.cat, self.fenetre = cat, fenetre
        self.lignes: list[LigneCode] = []
        self.travail: _Travail | None = None
        self._unitaire: _Travail | None = None       # recherche d'une seule ligne (touche Entrée)
        self._file: list[tuple[int, str]] = []
        self._attendu: tuple[int, str] | None = None
        self.setStyleSheet(STYLE)

        racine = QHBoxLayout(self)
        racine.setContentsMargins(22, 18, 22, 18)
        racine.setSpacing(22)

        # --- cases ------------------------------------------------------------------
        g = QVBoxLayout()
        g.setSpacing(8)
        t = QLabel("Codes produits")
        t.setStyleSheet("font-size: 13pt; font-weight: 700;")
        g.addWidget(t)
        aide = QLabel("Un code par case. Coller une liste dans une case remplit automatiquement "
                      "les cases suivantes.\nEntrée = le produit s'affiche, et on passe à la case suivante.")
        aide.setObjectName("petit")
        aide.setWordWrap(True)
        g.addWidget(aide)
        ent = QHBoxLayout()
        ent.setContentsMargins(15, 0, 15, 0)
        for txt, larg in (("N°", 34), ("Code produit", 190), ("", 30), ("Nom sur l'affiche", 0), ("", 96),
                          ("État", 120), ("", 30)):
            l = QLabel(txt)
            l.setObjectName("etiquette")
            if larg:
                l.setFixedWidth(larg)
            ent.addWidget(l, 0 if larg else 1)
        g.addLayout(ent)
        self.interieur = QWidget()
        self.interieur.setObjectName("interieurCases")
        self.liste = QVBoxLayout(self.interieur)
        self.liste.setContentsMargins(0, 0, 4, 0)
        self.liste.setSpacing(6)
        self.liste.addStretch()
        self.defil = QScrollArea()
        self.defil.setObjectName("zoneCases")
        self.defil.setWidget(self.interieur)
        self.defil.setWidgetResizable(True)
        self.defil.setFrameShape(QFrame.Shape.NoFrame)
        g.addWidget(self.defil, 1)
        hb = QHBoxLayout()
        b_plus = QPushButton("➕ Ajouter 5 cases")
        b_plus.clicked.connect(lambda: self._ajouter_cases(5))
        b_coller = QPushButton("📋 Coller une liste…")
        b_coller.clicked.connect(self._coller_liste)
        self.b_vider = QPushButton("🗑️ Vider toutes les cases")
        self.b_vider.clicked.connect(self.vider)
        hb.addWidget(b_plus)
        hb.addWidget(b_coller)
        hb.addStretch()
        hb.addWidget(self.b_vider)
        g.addLayout(hb)
        racine.addLayout(g, 3)

        # --- résumé et actions -------------------------------------------------------------
        d = QVBoxLayout()
        d.setSpacing(10)
        e = QLabel("Résumé")
        e.setObjectName("etiquette")
        d.addWidget(e)
        cp = QHBoxLayout()
        self.compteurs = {}
        for cle, lib in (("ok", "✅ prêts"), ("avert", "⚠️ à vérifier"), ("erreur", "❌ en erreur")):
            q = QLabel()
            q.setObjectName("compteur")
            q.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.compteurs[cle] = (q, lib)
            cp.addWidget(q)
        d.addLayout(cp)
        self.progres = QProgressBar()
        self._raz_progres()
        d.addWidget(self.progres)
        self.b_lancer = QPushButton("🔍 Rechercher tous les produits")
        self.b_lancer.setObjectName("principal")
        self.b_lancer.clicked.connect(self.lancer)
        d.addWidget(self.b_lancer)
        self.b_stop = QPushButton("⏹️ Arrêter")
        self.b_stop.setEnabled(False)
        self.b_stop.clicked.connect(self.arreter)
        d.addWidget(self.b_stop)
        d.addSpacing(12)
        e2 = QLabel("Enregistrer")
        e2.setObjectName("etiquette")
        d.addWidget(e2)
        self.r_unique = QRadioButton("un seul PDF (toutes les pages)")
        self.r_separes = QRadioButton("un PDF par produit")
        self.r_unique.setChecked(True)
        grp = QButtonGroup(self)
        grp.addButton(self.r_unique)
        grp.addButton(self.r_separes)
        d.addWidget(self.r_unique)
        d.addWidget(self.r_separes)
        self.b_pdf = QPushButton("📄  Générer PDF")
        self.b_pdf.setObjectName("principal")
        self.b_pdf.clicked.connect(self.generer)
        self.b_imprimer = QPushButton("🖨️  Imprimer tout")
        self.b_imprimer.setObjectName("principal")
        self.b_imprimer.clicked.connect(self.imprimer)
        self.b_apercu = QPushButton("👁️  Aperçu avant impression")
        self.b_apercu.clicked.connect(self.apercu)
        self.b_energie = QPushButton("🍃  Étiquettes énergie")
        self.b_energie.setObjectName("energie")
        self.b_energie.setToolTip("Les étiquettes énergie de toute la liste, 6 par feuille A4")
        self.b_energie.clicked.connect(self.etiquettes_energie)
        for b in (self.b_pdf, self.b_imprimer, self.b_apercu, self.b_energie):
            d.addWidget(b)
        d.addStretch()
        aide2 = QLabel("« Modifier » ou double-clic sur une ligne :\n"
                       "– corriger le nom, la photo, les mentions\n"
                       "– corriger le contenu de la boîte\n"
                       "– saisir à la main un produit introuvable")
        aide2.setObjectName("petit")
        d.addWidget(aide2)
        dw = QWidget()
        dw.setLayout(d)
        dw.setFixedWidth(330)
        racine.addWidget(dw)

        self._ajouter_cases(CASES_AU_DEPART)
        self._compter()
        self._maj_boutons()

    # -- cases ---------------------------------------------------------------------------------
    def _ajouter_cases(self, n: int) -> None:
        for _ in range(n):
            l = LigneCode(len(self.lignes) + 1)
            l.case.collage_multiple.connect(self._repartir)
            l.case.suivante.connect(self._case_suivante)
            l.vider.connect(self._vider_ligne)
            l.double_clic.connect(self._corriger)
            self.liste.insertWidget(self.liste.count() - 1, l)
            self.lignes.append(l)
            from .icones import appliquer
            appliquer(l)

    def _case_suivante(self, case: CaseCode) -> None:
        i = next(k for k, l in enumerate(self.lignes) if l.case is case)
        if i + 1 >= len(self.lignes):
            self._ajouter_cases(5)
        suivante = self.lignes[i + 1]
        suivante.case.setFocus()
        self.defil.ensureWidgetVisible(suivante)
        self._chercher_ligne(i)

    # -- Entrée : recherche immédiate de la ligne, pendant qu'on tape la suivante --------------------
    def _chercher_ligne(self, i: int) -> None:
        l = self.lignes[i]
        code = l.code()
        if not code or self._occupe() or (l.produit is not None and l.produit.code == code):
            return
        autre = next((k for k, x in enumerate(self.lignes) if k != i and x.code() == code
                      and (x.produit is not None or x.etat == "attente")), None)
        if autre is not None:
            l.definir("avert", None, f"Doublon de la case n°{autre + 1}\n(une seule feuille)")
            self._compter()
            return
        l.definir("attente", None, "Recherche…")
        self._file.append((i, code))
        self._suite_file()

    def _suite_file(self) -> None:
        if (self._unitaire and self._unitaire.isRunning()) or not self._file:
            return
        i, code = self._file.pop(0)
        if self.lignes[i].code() != code:            # modifiée entre-temps : on passe
            return self._suite_file()
        self._attendu = (i, code)
        self._unitaire = _Travail(self.cat, [(i, code)])
        self._unitaire.resultat.connect(self._resultat_unitaire)
        self._unitaire.finished.connect(self._suite_file)
        self._unitaire.finished.connect(self.fenetre.rafraichir_historique)
        self._unitaire.start()

    def _resultat_unitaire(self, i: int, p, etat: str, msg: str) -> None:
        l = self.lignes[i]
        if not self._attendu or l.code() != self._attendu[1]:
            return                                    # la case a changé pendant la recherche
        l.definir(etat, p, msg)
        self._compter()
        self._maj_boutons()

    def _repartir(self, case: CaseCode, codes: list[str]) -> None:
        """Place les codes à partir de cette case, dans les cases vides suivantes."""
        if self._occupe():
            return
        i = next(k for k, l in enumerate(self.lignes) if l.case is case)
        derniere = self.lignes[i]
        for n, code in enumerate(codes):
            if n:                # la 1re va dans la case d'origine, les suivantes dans les cases vides
                while i < len(self.lignes) and self.lignes[i].code():
                    i += 1
            if i >= len(self.lignes):
                self._ajouter_cases(max(5, len(codes) - n))
            derniere = self.lignes[i]
            derniere.mettre_code(code)
            derniere.definir("vide", None, "")
            i += 1
        self.defil.ensureWidgetVisible(derniere)

    def ajouter_codes(self, codes: list[str]) -> None:
        """Depuis l'historique : ajoute des codes dans les premières cases vides."""
        if not codes or self._occupe():
            return
        vides = [l for l in self.lignes if not l.code()]
        if not vides:
            self._ajouter_cases(max(5, len(codes)))
            vides = [l for l in self.lignes if not l.code()]
        self._repartir(vides[0].case, codes)

    def _coller_liste(self) -> None:
        dlg = CollerListe(self)
        if dlg.exec():
            codes = lire_codes(dlg.texte.toPlainText())
            if codes:
                self.ajouter_codes(codes)

    def _vider_ligne(self, l: LigneCode) -> None:
        if self._occupe():
            return
        l.case.clear()
        l.fermer_2e()
        self._compter()
        self._maj_boutons()

    def vider(self) -> None:
        if self._occupe():
            return
        for l in self.lignes[CASES_AU_DEPART:]:
            self.liste.removeWidget(l)
            l.deleteLater()
        self.lignes = self.lignes[:CASES_AU_DEPART]
        for l in self.lignes:
            l.case.clear()
            l.fermer_2e()
        self._raz_progres()
        self._compter()
        self._maj_boutons()
        self.lignes[0].case.setFocus()

    def _raz_progres(self) -> None:
        self.progres.setRange(0, 1)
        self.progres.setValue(0)
        self.progres.setFormat("")

    # -- recherche --------------------------------------------------------------------------------
    def _occupe(self) -> bool:
        return bool(self.travail and self.travail.isRunning())

    def _unitaire_en_cours(self) -> bool:
        return bool(self._file) or bool(self._unitaire and self._unitaire.isRunning())

    def lancer(self) -> None:
        if self._occupe():
            return
        if self._unitaire_en_cours():                  # on laisse finir la recherche « Entrée » en cours
            QTimer.singleShot(150, self.lancer)
            return
        vus: dict[str, int] = {}
        taches = []
        for i, l in enumerate(self.lignes):
            code = l.code()
            if not code:
                l.definir("vide", None, "")
                continue
            if code in vus:
                l.definir("avert", None, f"Doublon de la case n°{vus[code] + 1}\n(une seule feuille)")
                continue
            vus[code] = i
            l.definir("attente", None, "En attente…")
            taches.append((i, code))
        if not taches:
            QMessageBox.information(self, "Aucun code", "Tapez ou collez au moins un code produit.")
            return
        self.progres.setRange(0, len(taches))
        self.progres.setValue(0)
        self.progres.setFormat("%v / %m")
        self.travail = _Travail(self.cat, taches)
        self.travail.resultat.connect(self._resultat)
        self.travail.finished.connect(self._fini)
        self.b_lancer.setEnabled(False)
        self.b_stop.setEnabled(True)
        self.b_vider.setEnabled(False)
        self._maj_boutons()
        self.travail.start()

    def arreter(self) -> None:
        if self.travail:
            self.travail.stop = True
            self.b_stop.setEnabled(False)

    def _resultat(self, i: int, p, etat: str, msg: str) -> None:
        self.lignes[i].definir(etat, p, msg)
        self.progres.setValue(self.progres.value() + 1)
        self._compter()

    def _fini(self) -> None:
        for l in self.lignes:
            if l.etat == "attente":
                l.definir("vide", None, "Non traité (arrêté)")
        self.b_lancer.setEnabled(True)
        self.b_stop.setEnabled(False)
        self.b_vider.setEnabled(True)
        self._compter()
        self._maj_boutons()
        self.fenetre.rafraichir_historique()

    def _compter(self) -> None:
        n = {"ok": 0, "avert": 0, "erreur": 0}
        for l in self.lignes:
            if l.etat in n and (l.produit or l.etat == "erreur"):
                n[l.etat] += 1
        from .icones import txt
        for cle, (q, lib) in self.compteurs.items():
            q.setText(f"<span style='font-size:17pt;font-weight:800;color:{COULEURS[cle]}'>{n[cle]}</span>"
                      f"<br><span style='font-size:9pt;color:#5B6270;font-weight:600'>{txt(lib)}</span>")

    def _corriger(self, l: LigneCode) -> None:
        if self._occupe() or not l.code():
            return
        if l.produit is None:
            dlg = SaisieManuelle(self, code=l.code())
            if not dlg.exec():
                return
            try:
                p = self.cat.creer_manuel(dlg.code.text(), dlg.nom.text(), dlg.fichier)
            except Exception as e:
                QMessageBox.warning(self, "Erreur", str(e))
                return
            l.case.setText(p.code)
            l.definir("avert", p, p.avertissement)
        else:
            dlg = FenetreEdition(self, self.cat, l.produit)
            if not dlg.exec():
                return
            p = dlg.produit()
            if p.version2 is not None:                       # ordre éventuellement inversé
                l.case.blockSignals(True)
                l.case2.blockSignals(True)
                l.mettre_code(f"{p.code}+{p.version2.code}")
                l.case.blockSignals(False)
                l.case2.blockSignals(False)
            l.definir("avert" if p.avertissement else "ok", p, p.avertissement or "Prêt (modifié)")
        self._compter()
        self._maj_boutons()

    # -- sorties ----------------------------------------------------------------------------------
    def etiquettes_energie(self) -> None:
        prets = self._prets()
        if not prets or self._occupe():
            return
        from .etiquettes import FenetreEtiquettes
        FenetreEtiquettes(self, self.cat.client, prets, self.cat.base).exec()

    def _prets(self) -> list[Produit]:
        return [l.produit for l in self.lignes if l.produit is not None and l.produit.pret]

    def _maj_boutons(self) -> None:
        actif = bool(self._prets()) and not self._occupe()
        for b in (self.b_pdf, self.b_imprimer, self.b_apercu, self.b_energie):
            b.setEnabled(actif)

    def _confirmer(self) -> list[Produit] | None:
        prets = self._prets()
        erreurs = [l for l in self.lignes if l.etat == "erreur"]
        douteux = [p for p in prets if p.avertissement or not p.verifie]
        lignes = []
        if erreurs:
            lignes.append(f"{len(erreurs)} case(s) en erreur ne seront pas imprimées : "
                          + ", ".join(l.num.text() for l in erreurs[:10]) + ("…" if len(erreurs) > 10 else ""))
        if douteux:
            lignes.append(f"{len(douteux)} affiche(s) sont marquées « à vérifier » : "
                          + ", ".join(p.code for p in douteux[:8]) + ("…" if len(douteux) > 8 else ""))
        if lignes:
            r = QMessageBox.question(self, "Avant de continuer", "\n".join(lignes) + "\n\nContinuer quand même ?")
            if r != QMessageBox.StandardButton.Yes:
                return None
        return prets

    def generer(self) -> None:
        prets = self._confirmer()
        if not prets:
            return
        dossier = paths.output_dir()
        horo = datetime.now().strftime("%Y-%m-%d_%Hh%M")
        try:
            if self.r_unique.isChecked():
                f = affiche.creer_pdf(prets, dossier / f"Affiches_{horo}_{len(prets)}_produits.pdf",
                                      f"Affiches rayon ({len(prets)})")
                for p in prets:
                    self.cat.base.noter_affiche(p, "PDF", str(f))
                self.fenetre.annoncer_pdf(f)
            else:
                sous = dossier / f"Affiches_{horo}"
                for p in prets:
                    f = affiche.creer_pdf([p], sous / self.fenetre.nom_fichier(p), p.nom_affiche)
                    self.cat.base.noter_affiche(p, "PDF", str(f))
                self.fenetre.annoncer_pdf(sous, dossier=True, n=len(prets))
        except PermissionError:
            QMessageBox.warning(self, "Fichier ouvert", "Un PDF du même nom est ouvert dans un autre programme.\n"
                                "Fermez-le puis réessayez.")
        except Exception as e:
            QMessageBox.critical(self, "Erreur", f"Le PDF n'a pas pu être créé :\n{e}")
        self.fenetre.rafraichir_historique()

    def imprimer(self) -> None:
        prets = self._confirmer()
        if not prets:
            return
        doc = affiche.pdf_en_memoire(prets)
        try:
            if impression.imprimer(self, doc, f"Affiches rayon ({len(prets)})"):
                for p in prets:
                    self.cat.base.noter_affiche(p, "impression")
        except Exception as e:
            QMessageBox.critical(self, "Impression impossible", str(e))
        finally:
            doc.close()
        self.fenetre.rafraichir_historique()

    def apercu(self) -> None:
        prets = self._prets()
        if not prets:
            return
        doc = affiche.pdf_en_memoire(prets)
        try:
            impression.apercu_avant_impression(self, doc, f"Affiches rayon ({len(prets)})")
        finally:
            doc.close()
