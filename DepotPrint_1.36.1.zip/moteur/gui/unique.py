"""Une seule fenêtre Dépôt Print à la fois (par session Windows).

Au 2e lancement : message « déjà ouvert », et la fenêtre déjà ouverte passe au premier plan.
"""
from __future__ import annotations

import getpass
import re

from PySide6.QtNetwork import QLocalServer, QLocalSocket

_serveur: QLocalServer | None = None


def _nom() -> str:
    try:
        u = getpass.getuser()
    except Exception:
        u = "poste"
    return "DepotPrint-" + re.sub(r"[^A-Za-z0-9_-]", "_", u)


def deja_ouvert() -> bool:
    """True si un Dépôt Print tourne déjà (on lui demande de se montrer)."""
    s = QLocalSocket()
    s.connectToServer(_nom())
    if s.waitForConnected(300):
        s.write(b"montrer")
        s.flush()
        s.waitForBytesWritten(300)
        s.disconnectFromServer()
        return True
    return False


def ecouter(fenetre) -> None:
    """Le Dépôt Print ouvert répond aux lancements suivants en se mettant au premier plan."""
    global _serveur
    QLocalServer.removeServer(_nom())               # reste d'un logiciel fermé brutalement
    _serveur = QLocalServer()
    _serveur.listen(_nom())

    def montrer():
        c = _serveur.nextPendingConnection()
        if c is not None:
            c.readyRead.connect(lambda c=c: c.readAll())
            c.disconnected.connect(c.deleteLater)
        if fenetre.isMinimized():
            fenetre.showNormal()
        fenetre.raise_()
        fenetre.activateWindow()

    _serveur.newConnection.connect(montrer)
