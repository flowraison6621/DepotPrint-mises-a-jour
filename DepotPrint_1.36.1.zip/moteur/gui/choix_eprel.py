"""« 🍃 Choisir l'étiquette » (mode Étiquettes énergie) : automatique, image du site,
ou une fiche EPREL précise quand plusieurs modèles se ressemblent."""
from __future__ import annotations

from types import SimpleNamespace

from PySide6.QtWidgets import QDialog, QDialogButtonBox, QGridLayout, QLabel, QVBoxLayout

from .edition import FenetreEdition


class ChoixEprel(QDialog):
    # mêmes outils que l'ancienne ligne de « Modifier »
    _ligne_eprel = FenetreEdition._ligne_eprel
    _eprel_ajouter = FenetreEdition._eprel_ajouter
    _eprel_active = FenetreEdition._eprel_active
    _eprel_chercher = FenetreEdition._eprel_chercher

    def __init__(self, parent, cat, code: str, nom: str):
        super().__init__(parent)
        self.setWindowTitle("🍃 Étiquette énergie")
        self.setMinimumWidth(560)
        self.cat = cat
        self.code = code
        self._eprel: dict[str, str] = {}
        v = QVBoxLayout(self)
        t = QLabel(f"<b>{nom}</b><br>{code}")
        v.addWidget(t)
        g = QGridLayout()
        self._ligne_eprel(SimpleNamespace(code=code), g, 0)
        if self.c_eprel is None:
            v.addWidget(QLabel("Pas de choix possible pour ce produit :\n"
                               "l'étiquette du site Electro Dépôt est utilisée."))
        else:
            v.addLayout(g)
            aide = QLabel("Plusieurs modèles se ressemblent ?\n"
                          "🔎 cherche les fiches EPREL : prends celle\n"
                          "dont la référence est écrite sur la boîte.")
            aide.setObjectName("petit")
            v.addWidget(aide)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.button(QDialogButtonBox.StandardButton.Ok).setText("💾 Enregistrer")
        bb.button(QDialogButtonBox.StandardButton.Cancel).setText("Annuler")
        bb.accepted.connect(self._ok)
        bb.rejected.connect(self.reject)
        v.addWidget(bb)

    def _minuteur_start(self):
        pass

    def _ok(self) -> None:
        from .. import eprel
        if self.c_eprel is not None:
            d = self.c_eprel.currentData()
            if d != "?":
                self._eprel[self.code] = d
        for code, valeur in self._eprel.items():
            try:
                eprel.choisir(code, valeur)
            except OSError:
                pass
        self.accept()
