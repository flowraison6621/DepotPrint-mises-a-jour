"""Exécution des recherches Internet hors du fil de l'interface (l'écran ne gèle jamais)."""

from __future__ import annotations

import traceback
from typing import Callable

from PySide6.QtCore import QObject, QRunnable, QThreadPool, Signal


class _Signaux(QObject):
    fini = Signal(object)
    erreur = Signal(object)


class _Tache(QRunnable):
    def __init__(self, fn: Callable, *args):
        super().__init__()
        self.fn, self.args = fn, args
        self.signaux = _Signaux()

    def run(self):
        try:
            r = self.fn(*self.args)
        except Exception as e:  # remonté tel quel à l'interface
            if not getattr(e, "args", None):
                traceback.print_exc()
            self.signaux.erreur.emit(e)
        else:
            self.signaux.fini.emit(r)


# Un seul accès réseau à la fois : le site n'est jamais sollicité en parallèle.
_pool = QThreadPool()
_pool.setMaxThreadCount(1)
_actives: set = set()


def lancer(fn: Callable, *args, fini: Callable | None = None, erreur: Callable | None = None) -> None:
    t = _Tache(fn, *args)
    _actives.add(t.signaux)
    if fini:
        t.signaux.fini.connect(fini)
    if erreur:
        t.signaux.erreur.connect(erreur)
    t.signaux.fini.connect(lambda *_: _actives.discard(t.signaux))
    t.signaux.erreur.connect(lambda *_: _actives.discard(t.signaux))
    t.setAutoDelete(True)
    _pool.start(t)


def attendre_fin(ms: int = 3000) -> None:
    _pool.waitForDone(ms)
