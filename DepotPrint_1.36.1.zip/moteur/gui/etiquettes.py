"""Fenêtre « Étiquettes énergie » : cherche les étiquettes officielles des produits,
montre la feuille A4 (6 par feuille, taille réelle) et permet de l'imprimer ou d'en faire un PDF."""
from __future__ import annotations

from datetime import datetime

from PySide6.QtCore import Qt, QThread, QUrl, Signal
from PySide6.QtGui import QDesktopServices, QPixmap
from PySide6.QtWidgets import (QDialog, QHBoxLayout, QLabel, QMessageBox, QProgressBar, QPushButton,
                               QScrollArea, QVBoxLayout, QWidget)

from .. import energie, paths
from ..electrodepot import ErreurRecherche
from . import impression


class _Recherche(QThread):
    progres = Signal(int, int, str)
    fini = Signal(object, object)          # trouvées [Etiquette], absentes [(code, nom, raison)]

    def __init__(self, client, produits, base=None):
        super().__init__()
        self.client, self.produits, self.base = client, produits, base

    def run(self):
        trouvees, absentes = [], []
        for i, (code, nom) in enumerate(self.produits):
            self.progres.emit(i, len(self.produits), nom)
            try:
                article = None
                if self.base is not None:
                    try:
                        article = self.base.article(code)
                    except Exception:
                        article = None
                f = energie.obtenir(self.client, code, article=article)
                trouvees.append(energie.Etiquette(code, nom, f, energie.format_de(article)))
            except energie.SansEtiquette as e:
                absentes.append((code, nom, str(e)))
            except ErreurRecherche as e:
                absentes.append((code, nom, str(e).split(".")[0]))
            except Exception as e:       # jamais de plantage
                absentes.append((code, nom, f"erreur : {e}"))
        self.fini.emit(trouvees, absentes)


def produits_pour_etiquettes(produits) -> list[tuple[str, str]]:
    """Codes à étiqueter : chaque produit, et la 2e version d'une affiche à deux codes ; sans doublon."""
    vus, liste = set(), []
    for p in produits:
        for v in (p, getattr(p, "version2", None)):
            if v is not None and v.code and v.code not in vus:
                vus.add(v.code)
                from ..reseau import nom_produit_seul
                liste.append((v.code, nom_produit_seul(v) if v.nom_affiche else v.nom_site))
    return liste


class FenetreEtiquettes(QDialog):
    def __init__(self, parent, client, produits, base=None):
        super().__init__(parent)
        self.setWindowTitle("🍃 Étiquettes énergie")
        self.resize(980, 860)
        self.doc = None
        self.trouvees: list = []
        liste = produits_pour_etiquettes(produits)

        v = QVBoxLayout(self)
        t = QLabel("🍃 Étiquettes énergie")
        t.setStyleSheet("font-size: 14pt; font-weight: 800;")
        v.addWidget(t)
        a = QLabel("L'étiquette officielle de chaque produit, en taille réelle,\n"
                   "à découper le long des pointillés.")
        a.setObjectName("petit")
        v.addWidget(a)

        self.barre = QProgressBar()
        self.barre.setRange(0, max(1, len(liste)))
        self.barre.setFormat("%v / %m produits")
        v.addWidget(self.barre)
        self.detail = QLabel("Recherche des étiquettes…")
        v.addWidget(self.detail)

        corps = QHBoxLayout()
        zone = QScrollArea()
        zone.setWidgetResizable(True)
        zone.setMinimumWidth(520)
        self.apercu = QLabel()
        self.apercu.setAlignment(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop)
        zone.setWidget(self.apercu)
        corps.addWidget(zone, 3)
        droite = QVBoxLayout()
        self.resume = QLabel("")
        self.resume.setStyleSheet("font-weight: 700;")
        droite.addWidget(self.resume)
        self.absentes = QLabel("")
        self.absentes.setObjectName("petit")
        self.absentes.setWordWrap(True)
        self.absentes.setTextFormat(Qt.TextFormat.RichText)
        self.absentes.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        za = QScrollArea()
        za.setWidgetResizable(True)
        za.setFrameShape(QScrollArea.Shape.NoFrame)
        za.setWidget(self.absentes)
        droite.addWidget(za, 1)
        self.b_pdf = QPushButton("📄  Générer PDF")
        self.b_pdf.setObjectName("principal")
        self.b_pdf.clicked.connect(self.generer_pdf)
        self.b_imp = QPushButton("🖨️  Imprimer")
        self.b_imp.setObjectName("principal")
        self.b_imp.clicked.connect(self.imprimer)
        b_fermer = QPushButton("Fermer")
        b_fermer.clicked.connect(self.reject)
        for b in (self.b_pdf, self.b_imp, b_fermer):
            droite.addWidget(b)
        dw = QWidget()
        dw.setLayout(droite)
        dw.setFixedWidth(330)
        corps.addWidget(dw)
        v.addLayout(corps, 1)
        for b in (self.b_pdf, self.b_imp):
            b.setEnabled(False)

        from .icones import appliquer
        appliquer(self)
        self.travail = _Recherche(client, liste, base)
        self.travail.progres.connect(self._progres)
        self.travail.fini.connect(self._fini)
        self.travail.start()

    def _progres(self, i, n, nom):
        self.barre.setValue(i)
        self.detail.setText(f"Recherche : {nom}")

    def _fini(self, trouvees, absentes):
        self.trouvees = trouvees
        self.barre.setValue(self.barre.maximum())
        n = len(trouvees)
        self.doc = energie.creer_pdf(trouvees) if n else None
        feuilles = self.doc.page_count if self.doc is not None else 0
        self.detail.setText("Recherche terminée.")
        s, sf = ("s" if n > 1 else ""), ("s" if feuilles > 1 else "")
        nets = sum(1 for e in trouvees if e.officielle)
        detail = ""
        if n:
            detail = ("\n📄 officielle{} EPREL (nette{}) : {}".format("s" if nets > 1 else "", "s" if nets > 1 else "", nets)
                      if nets else "") + ("\n🖼️ image du site : {}".format(n - nets) if n - nets else "")
        self.resume.setText(f"✅ {n} étiquette{s} trouvée{s}\n({feuilles} feuille{sf} A4){detail}" if n
                            else "❌ Aucune étiquette trouvée")
        if absentes:
            lignes = "".join(f"<p style='margin:0 0 6px 0'><b>{c}</b> · {nom}<br>"
                             f"<span style='color:#8A5A00'>{raison}</span></p>" for c, nom, raison in absentes)
            self.absentes.setText("<p style='margin:8px 0 6px 0'><b>⚠️ Sans étiquette énergie :</b><br>"
                                  "(reconditionnés et modèles sortis avant juin 2025 n'en ont pas)</p>" + lignes)
        if not n:
            self.apercu.setText("\nAucune étiquette énergie à imprimer.")
            return
        pix = self.doc[0].get_pixmap(dpi=70)
        pm = QPixmap()
        pm.loadFromData(pix.tobytes("png"))
        self.apercu.setPixmap(pm)
        for b in (self.b_pdf, self.b_imp):
            b.setEnabled(True)

    def generer_pdf(self):
        if not self.trouvees:
            return
        nom = ("Etiquettes_energie_" + self.trouvees[0].code if len(self.trouvees) == 1
               else "Etiquettes_energie_" + datetime.now().strftime("%Y-%m-%d_%Hh%M"))
        dest = paths.output_dir() / f"{nom}.pdf"
        try:
            energie.creer_pdf(self.trouvees, dest)
        except PermissionError:
            QMessageBox.warning(self, "Fichier ouvert", "Ce PDF est ouvert dans un autre programme.\n"
                                                        "Fermez-le puis réessayez.")
            return
        box = QMessageBox(self)
        box.setWindowTitle("PDF enregistré")
        box.setText(f"PDF enregistré :\n{dest}")
        b_ouvrir = box.addButton("Ouvrir le PDF", QMessageBox.ButtonRole.AcceptRole)
        box.addButton("Fermer", QMessageBox.ButtonRole.RejectRole)
        box.exec()
        if box.clickedButton() is b_ouvrir:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(dest)))

    def imprimer(self):
        if self.doc is None:
            return
        try:
            impression.imprimer(self, self.doc, "Étiquettes énergie")
        except Exception as e:
            QMessageBox.critical(self, "Impression impossible", str(e))

    def done(self, r):
        if self.travail.isRunning():
            self.travail.wait(3000)
        super().done(r)
