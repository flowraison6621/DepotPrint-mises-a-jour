"""Fenêtre principale de Dépôt Print."""

from __future__ import annotations

import re
from pathlib import Path

from PySide6.QtCore import Qt, QTimer, QUrl
from PySide6.QtGui import QColor, QDesktopServices, QIcon, QKeySequence, QPixmap, QShortcut
from PySide6.QtWidgets import (
    QAbstractItemView, QFileDialog, QFrame, QGridLayout, QHBoxLayout, QHeaderView, QLabel, QLineEdit,
    QMainWindow, QMessageBox, QPushButton, QScrollArea, QSizePolicy, QTableWidget, QTableWidgetItem,
    QTabWidget, QVBoxLayout, QWidget,
)

from .. import APP_NAME, APP_VERSION, affiche, paths
from ..catalogue import Catalogue, Reponse
from ..models import Ambiguite, ErreurRecherche, Produit
from . import impression, taches
from .dialogues import ChoixCandidat, DepuisFiche, FenetreReglages, SaisieManuelle
from ..reglages import tarif_affiche, texte_tarif
from .edition import FenetreEdition
from .lot import OngletLot


LARG_COLONNE = 470                      # colonne de gauche de l'onglet « Un produit »
LARG_CARTE = LARG_COLONNE - 32          # intérieur de la carte produit
LARG_ETIQ = 124                   # place pour l'émoticône + « Dans la boîte »
LARG_VALEUR = LARG_CARTE - LARG_ETIQ - 12


def _etiquette(t: str) -> QLabel:
    l = QLabel(t)
    l.setObjectName("etiquette")
    return l


def _lien(t: str, fn) -> QPushButton:
    b = QPushButton(t)
    b.setObjectName("lien")
    b.setCursor(Qt.CursorShape.PointingHandCursor)
    b.clicked.connect(fn)
    return b


class Apercu(QLabel):
    """Aperçu A4 qui suit la taille de la fenêtre."""

    def __init__(self):
        super().__init__()
        self.setObjectName("apercu")
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setMinimumSize(480, 340)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self._pm: QPixmap | None = None

    def definir(self, png: bytes):
        pm = QPixmap()
        pm.loadFromData(png)
        self._pm = pm
        self._ajuster()

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._ajuster()

    def _ajuster(self):
        if self._pm:
            self.setPixmap(self._pm.scaled(self.width() - 24, self.height() - 24,
                                           Qt.AspectRatioMode.KeepAspectRatio,
                                           Qt.TransformationMode.SmoothTransformation))


RAPPEL_CATALOGUE_MS = 7 * 60 * 60 * 1000        # rappel « mise à jour du catalogue » : toutes les 7 heures

EMOJI_RANG = {"Code article": "🏷️ ", "Désignation": "🌐 ", "Source": "📍 ", "Dans la boîte": "📦 ",
              "Sur l'affiche": "📝 ", "2e version": "➕ "}


def _coloris_html(mot: str = "Coloris") -> str:
    """« Coloris » avec une couleur par lettre (comme sur l'affiche)."""
    from ..affiche import COULEURS_LETTRES
    return "<b>" + "".join(f"<span style='color:{COULEURS_LETTRES[i % len(COULEURS_LETTRES)]}'>{c}</span>"
                           for i, c in enumerate(mot)) + "</b>"


def _modele_court(nom_site: str) -> str:
    """« Smartphone SAMSUNG Galaxy A17 4G 128Go Noir » → « Samsung Galaxy A17 »."""
    s = re.split(r"\s\+\s", nom_site or "")[0]
    s = re.sub(r"^\s*(smartphone|mobile( s[ée]nior)?|t[ée]l[ée]phone( mobile)?|tablette( tactile)?)\s+", "", s,
               flags=re.I)
    m = re.search(r"\s(\d+\s?(go|gb|to|tb)\b|[45]G\b|reconditionn)", s, re.I)
    if m:
        s = s[:m.start()]
    mots = s.split()
    if mots and mots[0].isupper() and len(mots[0]) > 2:   # marque en capitales : « SAMSUNG » → « Samsung »
        mots[0] = mots[0].capitalize()
    return " ".join(mots)


class FenetrePrincipale(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_NAME)
        if paths.ICON_FILE.is_file():
            self.setWindowIcon(QIcon(str(paths.ICON_FILE)))
        self.resize(1360, 820)
        self.cat = Catalogue()
        self.produit: Produit | None = None
        self._occupe = False

        central = QWidget()
        v = QVBoxLayout(central)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)
        v.addWidget(self._entete())
        from .maj import BandeauMaj
        self.bandeau_maj = BandeauMaj(self)               # « Nouvelle version disponible »
        v.addWidget(self.bandeau_maj)
        self.onglets = QTabWidget()
        self.onglets.addTab(self._onglet_un(), "📱 Un produit")
        self.lot = OngletLot(self.cat, self)
        self.onglets.addTab(self.lot, "📋 Plusieurs produits")
        self.onglets.addTab(self._onglet_historique(), "🕘 Historique")
        from .parcourir import OngletParcourir
        self.parcourir = OngletParcourir(self)
        self.onglets.insertTab(2, self.parcourir, "🔎 Parcourir le catalogue")   # entre Plusieurs produits et Historique
        from .releve import OngletReleve
        self.releve = OngletReleve(self)
        self.onglets.insertTab(3, self.releve, "✍️ Relevé des quantités")      # avant Historique
        self.onglets.currentChanged.connect(self._changement_onglet)
        # écran d'accueil au démarrage : Étiquettes énergie · Relevé de quantité · Étiquettes produits
        from PySide6.QtWidgets import QStackedWidget
        from .accueil import EcranAccueil
        self.pile = QStackedWidget()
        self.accueil = EcranAccueil(self)
        self.pile.addWidget(self.accueil)
        self.pile.addWidget(self.onglets)
        v.addWidget(self.pile, 1)
        self.setCentralWidget(central)
        self.mode = ""

        self.apercu.definir(affiche.apercu_vide_png(dpi=80))
        self._etat("info", "Saisissez un code produit puis appuyez sur Entrée.")
        self.maj_etat_catalogue()
        self._maj_boutons()
        QShortcut(QKeySequence("Ctrl+P"), self, activated=self.imprimer)
        from .icones import appliquer
        appliquer(self)                                  # émoticônes : icône + texte / icône / texte
        # rappel : penser à mettre à jour le catalogue, toutes les 7 heures (logiciel ouvert)
        self._rappel = QTimer(self)
        self._rappel.setInterval(RAPPEL_CATALOGUE_MS)
        self._rappel.timeout.connect(self._rappel_catalogue)
        self._rappel.start()
        QTimer.singleShot(3000, self.bandeau_maj.demarrer)   # fenêtre ouverte : mise à jour validée / cherchée

    # ------------------------------------------------------------------------------ UI
    def _entete(self) -> QWidget:
        w = QWidget()
        w.setObjectName("entete")
        h = QHBoxLayout(w)
        h.setContentsMargins(22, 12, 22, 12)
        # logo rond (bonhomme + imprimante) et titre « DépôtPrint » en blanc
        for fichier, hauteur in (("logo_rond.png", 46), ("logo_titre.png", 26)):
            l = QLabel()
            img = QPixmap(str(paths.ASSETS / fichier))
            if img.isNull():                    # image absente : on garde le titre texte
                l.setText(APP_NAME if fichier == "logo_titre.png" else "")
                l.setObjectName("titreApp")
            else:
                ratio = self.devicePixelRatioF()
                img = img.scaledToHeight(round(hauteur * ratio), Qt.TransformationMode.SmoothTransformation)
                img.setDevicePixelRatio(ratio)
                l.setPixmap(img)
            h.addWidget(l)
            h.addSpacing(6)
        h.addSpacing(8)
        s = QLabel("Electro Dépôt")
        s.setObjectName("sousTitreApp")
        h.addWidget(s)
        h.addSpacing(14)
        self.b_accueil = QPushButton("🏠 Accueil")
        self.b_accueil.clicked.connect(self.aller_accueil)
        self.b_accueil.setVisible(False)
        h.addWidget(self.b_accueil)
        self.l_mode = QLabel("")
        self.l_mode.setVisible(False)
        h.addWidget(self.l_mode)
        h.addStretch()
        bc = QPushButton("📦 Catalogue hors ligne")
        bc.setStyleSheet("background: #FF9900; border: 1px solid #E68A00; font-weight: 700;")
        bc.clicked.connect(self.catalogue_hors_ligne)
        h.addWidget(bc)
        br = QPushButton("⚙️ Réglages")
        br.clicked.connect(self.reglages)
        h.addWidget(br)
        b = QPushButton("📂 Ouvrir le dossier des PDF")
        b.clicked.connect(lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(str(paths.output_dir()))))
        h.addWidget(b)
        return w

    # ------------------------------------------------------------------------------ accueil / modes
    MODES = {
        # mode : (libellé, couleur, onglets visibles)
        "energie": ("🍃 Étiquettes énergie", "#2E7D32", ("parcourir",)),
        "releve": ("✍️ Relevé de quantité", "#2F8CCB", ("releve",)),
        "produits": ("🏷️ Étiquettes produits", "#F29400", ("un", "lot", "parcourir", "historique")),
    }

    def _cle_onglet(self, i: int) -> str:
        w = self.onglets.widget(i)
        if w is self.lot:
            return "lot"
        if w is self.parcourir:
            return "parcourir"
        if w is self.releve:
            return "releve"
        return "un" if i == 0 else "historique"

    def ouvrir_mode(self, mode: str) -> None:
        """Après un clic sur une carte de l'accueil : seulement les onglets utiles."""
        lib, couleur, visibles = self.MODES[mode]
        self.mode = mode
        premier = None
        for i in range(self.onglets.count()):
            vis = self._cle_onglet(i) in visibles
            self.onglets.setTabVisible(i, vis)
            if vis and premier is None:
                premier = i
        self.onglets.tabBar().setVisible(len(visibles) > 1)
        if premier is not None:
            self.onglets.setCurrentIndex(premier)
        self.parcourir.mode_energie(mode == "energie")
        # « Étiquettes produits » : seulement les affiches (l'énergie a sa propre carte)
        self.b_energie.setVisible(mode != "produits")
        self.lot.b_energie.setVisible(mode != "produits")
        self.l_mode.setText(lib)
        self.l_mode.setStyleSheet(f"background: {couleur}; color: white; border-radius: 13px; "
                                  "padding: 5px 14px; font-weight: 700;")
        self.l_mode.setVisible(True)
        self.b_accueil.setVisible(True)
        self.pile.setCurrentIndex(1)
        if mode == "produits":
            QTimer.singleShot(0, self.champ.setFocus)

    def aller_accueil(self) -> None:
        self.mode = ""
        self.accueil.maj()
        self.l_mode.setVisible(False)
        self.b_accueil.setVisible(False)
        self.pile.setCurrentIndex(0)

    def _onglet_un(self) -> QWidget:
        w = QWidget()
        racine = QHBoxLayout(w)
        racine.setContentsMargins(22, 18, 22, 18)
        racine.setSpacing(22)

        g = QVBoxLayout()
        g.setSpacing(10)
        g.addWidget(_etiquette("Code produit"))
        hc = QHBoxLayout()
        self.champ = QLineEdit()
        self.champ.setObjectName("champCode")
        self.champ.setPlaceholderText("ex. 995621")
        self.champ.setMaxLength(45)        # deux codes possibles : « 10017363 + 10020472 »
        from .lot import _taille_deux_codes
        self.champ.textChanged.connect(lambda t: _taille_deux_codes(self.champ, "+" if getattr(self, "_deux", False) else t))
        self.champ.returnPressed.connect(self.rechercher)
        hc.addWidget(self.champ, 1)
        from .lot import bouton_moins, bouton_plus
        self.b_plus = bouton_plus(44)
        self.b_plus.setStyleSheet("QPushButton { background: white; color: #E68A00; border: 2px solid #FF9900;"
                                  "border-radius: 8px; font-size: 20pt; font-weight: 800; padding: 0; }"
                                  "QPushButton:disabled { border-color: transparent; background: transparent; }")
        hc.addWidget(self.b_plus)
        # 2e case (code de la 2e version), à côté de la 1re
        self.champ2 = QLineEdit()
        self.champ2.setObjectName("champCode")
        self.champ2.setProperty("deux", True)
        self.champ2.setPlaceholderText("2e code")
        self.champ2.setMaxLength(20)
        self.champ2.returnPressed.connect(self.rechercher)
        self.b_moins = bouton_moins(32)
        self.b_moins.setStyleSheet("font-size: 13pt; padding: 0;")
        self.b_moins.clicked.connect(self._fermer_2e)
        hc.addWidget(self.champ2, 1)
        hc.addWidget(self.b_moins)
        for wdg in (self.champ2, self.b_moins):
            wdg.hide()
        self._deux = False
        self.b_rech = QPushButton("🔍 Rechercher")
        self.b_rech.setObjectName("rechercher")
        self.b_rech.setMinimumHeight(62)
        self.b_rech.clicked.connect(self.rechercher)
        hc.addWidget(self.b_rech)
        hc.setSpacing(8)
        g.addLayout(hc)
        # « Version 1 » / « Version 2 » sous les deux cases
        self.rang_leg = QWidget()
        hl = QHBoxLayout(self.rang_leg)
        hl.setContentsMargins(0, 0, 0, 0)
        hl.setSpacing(8)
        self.leg1, self.leg2 = QLabel("Version 1"), QLabel("Version 2")
        for lg in (self.leg1, self.leg2):
            lg.setStyleSheet("color: #5B6270; font-size: 8.5pt; font-weight: 700;")
            lg.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.rang_leg.hide()
        g.addWidget(self.rang_leg)
        self.b_plus.clicked.connect(self._ouvrir_2e)
        self.champ.textChanged.connect(lambda _: self._maj_plus())
        for ch in (self.champ, self.champ2):            # code modifié : on redemande les références
            ch.textEdited.connect(lambda _: self._legendes_a_refaire())

        self.bandeau = QLabel()
        self.bandeau.setObjectName("bandeau")
        self.bandeau.setWordWrap(True)
        self.bandeau.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        g.addWidget(self.bandeau)
        self.l_catalogue = QLabel()
        self.l_catalogue.setWordWrap(True)
        self.l_catalogue.setStyleSheet("background: #EAF1FB; color: #1F4E8C; border: 1px solid #C3D6F2; "
                                       "border-radius: 7px; padding: 7px 12px;")
        g.addWidget(self.l_catalogue)

        # --- carte produit : photo + nom, puis fiche d'informations rangée en lignes ---
        carte = QFrame()
        carte.setObjectName("carte")
        cv = QVBoxLayout(carte)
        cv.setContentsMargins(16, 14, 16, 14)
        cv.setSpacing(10)
        haut = QHBoxLayout()
        haut.setSpacing(14)
        self.vignette = QLabel()
        self.vignette.setFixedSize(104, 118)
        self.vignette.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.vignette.setStyleSheet("background: #FAFAFB; border-radius: 8px; color: #9AA0AA;")
        self.vignette.setText("Photo")
        haut.addWidget(self.vignette)
        tete = QVBoxLayout()
        tete.setSpacing(2)
        tete.addWidget(_etiquette("Nom sur l'affiche"))
        self.l_nom = QLabel("—")
        self.l_nom.setObjectName("nomAffiche")
        self.l_nom.setWordWrap(True)
        self.l_nom.setFixedWidth(LARG_CARTE - 104 - 14)
        tete.addWidget(self.l_nom)
        tete.addStretch()
        haut.addLayout(tete, 1)
        cv.addLayout(haut)

        trait = QFrame()
        trait.setFrameShape(QFrame.Shape.HLine)
        trait.setStyleSheet("color: #E2E4E8;")
        cv.addWidget(trait)

        grille = QGridLayout()
        grille.setHorizontalSpacing(12)
        grille.setVerticalSpacing(7)
        grille.setColumnStretch(1, 1)
        self.l_code, self.l_site, self.l_source = QLabel("—"), QLabel("—"), QLabel("—")
        self.l_coloris = QLabel("—")
        self.l_boite = QLabel("—")
        self.l_v2 = QLabel("—")
        self.l_source.setOpenExternalLinks(True)
        self.zone_badges = QWidget()
        self.badges = QVBoxLayout(self.zone_badges)      # 2 pastilles par ligne : jamais coupé
        self.badges.setContentsMargins(0, 0, 0, 0)
        self.badges.setSpacing(5)
        self._rangs = {}                                  # titre → (étiquette, valeur) : masqués pour 2 versions
        for i, (titre, valeur) in enumerate((("Code article", self.l_code), ("Désignation", self.l_site),
                                             ("Source", self.l_source), ("Coloris", self.l_coloris),
                                             ("Dans la boîte", self.l_boite), ("Sur l'affiche", self.zone_badges),
                                             ("2e version", self.l_v2))):
            e = _etiquette(EMOJI_RANG.get(titre, "") + titre)
            e.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
            e.setFixedWidth(LARG_ETIQ)
            grille.addWidget(e, i, 0, Qt.AlignmentFlag.AlignTop)
            valeur.setFixedWidth(LARG_VALEUR)          # largeur connue : hauteur du texte exacte
            if isinstance(valeur, QLabel):
                valeur.setWordWrap(True)
                valeur.setTextInteractionFlags(Qt.TextInteractionFlag.TextBrowserInteraction)
            grille.addWidget(valeur, i, 1)
            self._rangs[titre] = (e, valeur)
            if titre == "Coloris":                       # le mot en multicolore, comme sur l'affiche
                e.setTextFormat(Qt.TextFormat.RichText)
                e.setText("🎨 " + _coloris_html("Coloris"))
        self.l_code.setStyleSheet("font-family: Consolas, monospace; font-weight: 700;")
        cv.addLayout(grille)
        # affiche pour deux versions : une colonne par version (code, désignation, mentions, protection)
        self.l_duo = QLabel()
        self.l_duo.setWordWrap(True)
        self.l_duo.setFixedWidth(LARG_ETIQ + LARG_VALEUR + 12)      # même largeur que les lignes de la carte
        self.l_duo.setTextFormat(Qt.TextFormat.RichText)
        self.l_duo.hide()
        cv.addWidget(self.l_duo)
        g.addWidget(carte)

        self.b_modifier = QPushButton("✏️  Modifier")
        self.b_modifier.setObjectName("modifier")
        self.b_modifier.setToolTip("Nom, mentions, couleurs, boîte, photo, cadrage")
        self.b_modifier.setMinimumWidth(240)
        self.b_modifier.clicked.connect(self.modifier)
        g.addWidget(self.b_modifier, 0, Qt.AlignmentFlag.AlignHCenter)
        hb = QHBoxLayout()
        self.b_pdf = QPushButton("📄  Générer PDF")
        self.b_pdf.setObjectName("principal")
        self.b_pdf.clicked.connect(self.generer_pdf)
        self.b_imp = QPushButton("🖨️  Imprimer")
        self.b_imp.setObjectName("principal")
        self.b_imp.clicked.connect(self.imprimer)
        hb.addWidget(self.b_pdf)
        hb.addWidget(self.b_imp)
        g.addLayout(hb)
        self.b_apercu_imp = QPushButton("👁️  Aperçu avant impression")
        self.b_apercu_imp.clicked.connect(self.apercu_impression)
        g.addWidget(self.b_apercu_imp)
        self.b_energie = QPushButton("🍃  Étiquette énergie")
        self.b_energie.setObjectName("energie")
        self.b_energie.setToolTip("L'étiquette énergie officielle du produit, en taille réelle")
        self.b_energie.clicked.connect(self.etiquettes_energie)
        g.addWidget(self.b_energie)

        g.addSpacing(8)
        g.addWidget(_etiquette("Autres façons d'ajouter un produit"))
        g.addWidget(_lien("🔗 Depuis l'adresse d'une fiche produit electrodepot.fr…", self.depuis_fiche))
        g.addWidget(_lien("✍️ Saisie manuelle (nom + photo)…", self.saisie_manuelle))
        g.addWidget(_lien("➜ Importer un catalogue (fichier CSV / Excel enregistré en CSV)…", self.importer_csv))
        g.addStretch()
        ver = QLabel(f"Version {APP_VERSION}")
        ver.setObjectName("petit")
        g.addWidget(ver)

        gw = QWidget()
        gw.setObjectName("colonneGauche")
        gw.setLayout(g)
        gw.setFixedWidth(LARG_COLONNE)
        # colonne défilante : sur un petit écran rien n'est tassé ni coupé
        defil = QScrollArea()
        defil.setObjectName("colonneGaucheDefil")
        defil.setWidget(gw)
        defil.setWidgetResizable(True)
        defil.setFrameShape(QFrame.Shape.NoFrame)
        defil.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        defil.setFixedWidth(LARG_COLONNE + 14)
        defil.setStyleSheet("QScrollArea#colonneGaucheDefil, QWidget#colonneGauche { background: transparent; }")
        racine.addWidget(defil)

        d = QVBoxLayout()
        d.addWidget(_etiquette("Aperçu de la feuille A4 (paysage)"))
        self.apercu = Apercu()
        d.addWidget(self.apercu, 1)
        racine.addLayout(d, 1)
        return w

    def _onglet_historique(self) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(22, 18, 22, 18)
        h = QHBoxLayout()
        t = QLabel("Affiches enregistrées")
        t.setStyleSheet("font-size: 13pt; font-weight: 700;")
        h.addWidget(t)
        h.addStretch()
        self.filtre = QLineEdit()
        self.filtre.setPlaceholderText("🔎 Rechercher un code ou un nom…")
        self.filtre.setFixedWidth(320)
        self.filtre.textChanged.connect(lambda _: self.rafraichir_historique())
        h.addWidget(self.filtre)
        v.addLayout(h)
        aide = QLabel("Les affiches déjà sorties en PDF ou imprimées. Double-cliquez pour rouvrir et réimprimer.\n"
                      "Pour retirer une ligne : cliquez dessus puis appuyez sur la touche « Suppr ».")
        aide.setObjectName("petit")
        v.addWidget(aide)
        self.t_hist = QTableWidget(0, 6)
        self.t_hist.setHorizontalHeaderLabels(["Affiche", "Code", "Nom sur l'affiche", "Source", "Contrôle", "Sortie le"])
        self.t_hist.verticalHeader().setVisible(False)
        self.t_hist.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.t_hist.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.t_hist.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        hh = self.t_hist.horizontalHeader()
        for i in (0, 1, 3, 4, 5):
            hh.setSectionResizeMode(i, QHeaderView.ResizeMode.ResizeToContents)
        hh.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.t_hist.itemDoubleClicked.connect(lambda it: self._ouvrir_depuis_historique(it.row()))
        # touche « Suppr » : retirer les lignes sélectionnées
        from PySide6.QtGui import QKeySequence, QShortcut
        sc = QShortcut(QKeySequence(QKeySequence.StandardKey.Delete), self.t_hist)
        sc.setContext(Qt.ShortcutContext.WidgetWithChildrenShortcut)
        sc.activated.connect(self._supprimer_selection)
        v.addWidget(self.t_hist, 1)
        hb = QHBoxLayout()
        b1 = QPushButton("↩️ Ouvrir")
        b1.clicked.connect(lambda: self._ouvrir_depuis_historique(self.t_hist.currentRow()))
        b2 = QPushButton("📋 Ajouter la sélection à « Plusieurs produits »")
        b2.clicked.connect(self._vers_lot)
        b3 = QPushButton("🔄 Actualiser depuis le site")
        b3.setToolTip("Recharge le nom et la photo depuis electrodepot.fr")
        b3.clicked.connect(self._actualiser_selection)
        b4 = QPushButton("🗑️ Retirer de la liste (Suppr)")
        b4.clicked.connect(self._supprimer_selection)
        for b in (b1, b2, b3):
            hb.addWidget(b)
        hb.addStretch()
        hb.addWidget(b4)
        v.addLayout(hb)
        self.rafraichir_historique()
        return w

    # --------------------------------------------------------------------- états
    def _etat(self, etat: str, msg: str):
        from .icones import txt
        self.bandeau.setProperty("etat", etat)
        self.bandeau.setText(txt(msg))
        self.bandeau.style().unpolish(self.bandeau)
        self.bandeau.style().polish(self.bandeau)

    def _maj_boutons(self):
        pret = bool(self.produit and self.produit.pret) and not self._occupe
        for b in (self.b_pdf, self.b_imp, self.b_apercu_imp):
            b.setEnabled(pret)
        self.b_modifier.setEnabled(bool(self.produit) and not self._occupe)
        self.b_energie.setEnabled(bool(self.produit and self.produit.code) and not self._occupe)
        self.b_rech.setEnabled(not self._occupe)
        self.champ.setEnabled(not self._occupe)
        self.champ2.setEnabled(not self._occupe)

    def _afficher(self, p: Produit | None):
        self.produit = p
        self._badges([])
        if not p:
            for l in (self.l_nom, self.l_code, self.l_site, self.l_source, self.l_coloris, self.l_boite, self.l_v2):
                l.setText("—")
            self.vignette.clear()
            self.vignette.setText("Photo")
            self.apercu.definir(affiche.apercu_vide_png(dpi=80))
            self._carte_deux_versions(Produit(code=""))   # plus de carte « deux produits » d'avant
            self._maj_boutons()
            return
        if p.version2 is not None:
            from ..affiche import nom_deux_versions, _sans_differences
            from ..reglages import disposition_deux_versions, genre_deux_versions
            if disposition_deux_versions(genre_deux_versions(p, p.version2)) == "simple":
                nom = _sans_differences(p.nom_affiche, False, True)   # comme sur l'affiche simple
            else:
                nom = nom_deux_versions(p, p.version2)
            self.l_nom.setText(nom or "—")
        else:
            from ..reseau import nom_produit_seul
            self.l_nom.setText(nom_produit_seul(p) if p.nom_affiche else "—")   # tel qu'imprimé, avec le réseau
        self.l_code.setText(p.code)
        self.l_site.setText(p.nom_site or "(saisi à la main)")
        lien = f' · <a href="{p.url_fiche}">voir la fiche</a>' if p.url_fiche else ""
        self.l_source.setText(f"{p.source or 'inconnue'}{lien}")
        m = p.mentions
        if p.version2 is None:                         # produit seul : couleurs de son réseau, comme l'affiche
            from ..reseau import mentions_de_son_reseau
            m = mentions_de_son_reseau(p)
        from ..coloris import resume_variantes
        if m.variantes and (m.coloris_exclus or m.coloris_ajoutes):
            t = resume_variantes(m.variantes_affichees()) or "aucune"
            if m.coloris_ajoutes:
                t += "\n(en réserve : " + ", ".join(c.split("|", 1)[1] for c in m.coloris_ajoutes) + ")"
            if m.coloris_exclus:
                t += "\n(retirées à la main : " + ", ".join(c.split("|", 1)[1] for c in m.coloris_exclus) + ")"
            self.l_coloris.setText(t)
        else:
            self.l_coloris.setText(resume_variantes(m.variantes) + "\n(trouvés sur le site)" if m.variantes
                                   else "non vérifié sur le site")
        from ..boite import texte as texte_boite
        if m.boite_manuel:
            precision = "\n(corrigé à la main)"
        elif m.reconditionne:
            precision = "\n(reconditionné : câble seul par sécurité)"
        elif m.boite_indique:
            precision = ""
        else:
            precision = "\n(non indiqué sur le site : à vérifier)"
        self.l_boite.setText(texte_boite(m.boite) + precision)
        v2 = p.version2
        if v2 is not None:
            r2 = v2.mentions.resume(tarif_affiche(v2)) or "aucune mention"
            from ..affiche import _capacite, _couleurs_version, _reseau, differences_versions
            cap = _capacite(v2.nom_affiche) if differences_versions(p, v2)[0] else ""
            self.l_v2.setText(f"{v2.code}{' · ' + cap.replace('GO', ' Go') if cap else ''} · {r2}"
                              "\n(une seule affiche pour les deux versions)")
        else:
            self.l_v2.setText("aucune\n(bouton « + » à côté du code)")
        b = []
        if m.reconditionne:
            b.append(("♻️ Reconditionné", "#1E7D3A", "white"))
            if m.etat:
                b.append((m.etat.capitalize(), "#E7F6EC", "#1E6B36"))
        if m.batterie_neuve:
            b.append(("🔋 Batterie neuve", "#E7F6EC", "#1E6B36"))
        if m.coloris:
            from ..affiche import avec_etiquette
            b.append(("🎨 Étiquette coloris" if avec_etiquette(m) else "🎨 Plusieurs coloris", "#EEF0F3", "#1C1F24"))
        if m.protection:
            t = tarif_affiche(p)
            b.append((f"🛡️ Protection {texte_tarif(t)} €/mois", "#232323", "#FFB52F") if t
                     else ("🛡️ Protection : prix inconnu", "#EEF0F3", "#5B6270"))
        self._badges(b)
        self._carte_deux_versions(p)
        if p.photo and Path(p.photo).is_file():
            pm = self._vignette_deux(p) if p.version2 is not None else QPixmap(p.photo)
            self.vignette.setPixmap(pm.scaled(self.vignette.size() * 0.95, Qt.AspectRatioMode.KeepAspectRatio,
                                              Qt.TransformationMode.SmoothTransformation))
            try:
                self.apercu.definir(affiche.apercu_png(p, dpi=110))
            except Exception as e:
                self._etat("erreur", f"Aperçu impossible : {e}")
        else:
            self.vignette.clear()
            self.vignette.setText("Pas de photo")
            self.apercu.definir(affiche.apercu_vide_png(dpi=80))
        self._maj_boutons()

    def _carte_deux_versions(self, p: Produit) -> None:
        """Deux versions : la carte montre les deux produits côte à côte, pas seulement le premier."""
        duo = p.version2 is not None
        for titre, (e, valeur) in self._rangs.items():
            visible = (not duo) or titre == "Dans la boîte"
            e.setVisible(visible)
            valeur.setVisible(visible)
        self.l_duo.setVisible(duo)
        if not duo:
            return
        from ..affiche import libelle_version as _lib       # légendes sous les cases de code
        self.leg1.setText(_lib(p, p.version2, 0))
        self.leg2.setText(_lib(p, p.version2, 1))
        self._leg_trouve = True
        if getattr(self, "_deux", False):
            self._placer_legendes(True)
        from ..affiche import _capacite, _couleurs_version, _reseau, differences_versions, libelle_version
        capa, res = differences_versions(p, p.version2)
        cols = []
        for k, v in enumerate((p, p.version2)):
            mm = v.mentions
            lib = libelle_version(p, p.version2, k).replace(" ", "&nbsp;")
            lignes = [f"<span style='background:#1C1F24; color:white; font-weight:700'>&nbsp;{lib}&nbsp;</span>"
                      f"&nbsp; <b style='font-family:Consolas,monospace'>{v.code}</b>",
                      f"<b>{_modele_court(v.nom_site) or v.nom_affiche}</b>"]
            # en vert, même structure pour chaque version : état (ou neuf) · réseau · capacité · batterie
            from ..affiche import resume_version
            lignes.append("<b style='color:#1E6B36'>" + resume_version(v) + "</b>")
            couleurs = _couleurs_version(v)              # seulement celles de SON réseau, comme sur l'affiche
            if couleurs:
                lignes.append(_coloris_html() + " : " + ", ".join(couleurs))
            t = tarif_affiche(v)
            if t:
                lignes.append(f"<span style='background:#232323; color:#FFB52F; font-weight:700'>"
                              f"&nbsp;Protection {texte_tarif(t)}&nbsp;€/mois&nbsp;</span>")
            cols.append("<br>".join(lignes))
        larg = LARG_ETIQ + LARG_VALEUR + 12             # largeur fixe : rien ne dépasse de la carte
        demi = (larg - 8) // 2
        self.l_duo.setText(f"<table width='{larg - 8}' cellspacing='0' cellpadding='4'><tr>"
                           + "".join(f"<td width='{demi}' valign='top'>{c}</td>" for c in cols) + "</tr></table>")

    def _vignette_deux(self, p: Produit) -> QPixmap:
        """Les deux photos côte à côte dans la vignette de la carte."""
        from PySide6.QtGui import QPainter
        taille = self.vignette.size()
        pm = QPixmap(taille)
        pm.fill(Qt.GlobalColor.transparent)
        pt = QPainter(pm)
        demi = taille.width() // 2
        for k, v in enumerate((p, p.version2)):
            if v.photo and Path(v.photo).is_file():
                img = QPixmap(v.photo).scaled(demi - 2, taille.height(), Qt.AspectRatioMode.KeepAspectRatio,
                                              Qt.TransformationMode.SmoothTransformation)
                pt.drawPixmap(k * demi + (demi - img.width()) // 2, (taille.height() - img.height()) // 2, img)
        pt.end()
        return pm

    def _badges(self, liste):
        """Pastilles des mentions (ou « aucune »), sur la ligne « Sur l'affiche »."""
        while self.badges.count():
            it = self.badges.takeAt(0)
            w = it.widget()
            if w is None and it.layout() is not None:
                w = QWidget()
                w.setLayout(it.layout())
            if w is not None:
                w.hide()                      # disparaît tout de suite (supprimée un peu après)
                w.deleteLater()
        if not liste:
            l = QLabel("aucune mention")
            l.setObjectName("petit")
            self.badges.addWidget(l)
            return
        for i in range(0, len(liste), 2):
            ligne = QWidget()
            h = QHBoxLayout(ligne)
            h.setContentsMargins(0, 0, 0, 0)
            h.setSpacing(5)
            for texte, fond, encre in liste[i:i + 2]:
                from .icones import txt
                l = QLabel(txt(texte))
                l.setStyleSheet(f"background: {fond}; color: {encre}; border-radius: 10px; padding: 3px 10px; "
                                "font-size: 9pt; font-weight: 700;")
                l.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
                h.addWidget(l)
            h.addStretch()
            self.badges.addWidget(ligne)

    def _etat_produit(self, p: Produit, avert: str = "", cache: bool = False, origine: str = "", retire: str = ""):
        if p.version2 is not None and not (avert or p.avertissement):
            from ..affiche import modeles_differents
            quoi = "deux produits trouvés" if modeles_differents(p, p.version2) else "deux versions trouvées"
            self._etat("ok", f"✅ {p.code} + {p.version2.code} — {quoi}\n"
                             "(une seule affiche pour la cloche)")
        elif origine == "catalogue" and retire and not (avert or p.avertissement):
            self._etat("ok", f"✅ {p.code} — trouvé dans le catalogue hors ligne\n"
                             f"(plus sur le site depuis le {retire} : gardé tel qu'il était)")
        elif origine == "catalogue" and not (avert or p.avertissement):
            self._etat("ok", f"✅ {p.code} — trouvé dans le catalogue hors ligne\n"
                             f"(mis à jour le {self.cat.base.valeur('catalogue_date', '?')})")
        elif avert or p.avertissement or not p.verifie:
            self._etat("avert", "⚠️ À vérifier : " + (avert or p.avertissement or "produit non vérifié sur le site."))
        elif cache:
            self._etat("ok", f"✅ {p.code} — produit déjà enregistré\n(vérifié le {p.maj[:10]})")
        else:
            self._etat("ok", f"✅ {p.code} — trouvé et vérifié sur electrodepot.fr\n(code article identique)")
        mf = affiche.mettre_en_forme_nom(p.nom_affiche) if p.nom_affiche else None
        if mf and mf.trop_long:
            self._etat("avert", "⚠️ Le nom est trop long pour l'affiche : raccourcissez-le avec « Modifier ».")

    # ---------------------------------------------------------------------- 2e case (2e version)
    def _maj_plus(self) -> None:
        t = self.champ.text()
        # deux cases ouvertes : le « + » reste affiché entre elles, comme un signe
        self.b_plus.setVisible(self._deux or (bool(t.strip()) and "+" not in t))
        self.b_plus.setEnabled(not self._deux)

    def _deux_cases(self, oui: bool) -> None:
        self._deux = oui
        self._leg_trouve = False
        for wdg in (self.champ2, self.b_moins):
            wdg.setVisible(oui)
        self._placer_legendes(oui)
        if not oui:
            self.champ2.clear()
        from .lot import _taille_deux_codes
        _taille_deux_codes(self.champ, "+" if oui else self.champ.text())   # texte plus petit : tout tient
        self._maj_plus()

    def _placer_legendes(self, oui: bool) -> None:
        """Légendes alignées sous chaque case (placées d'après la position réelle des cases)."""
        self.rang_leg.setVisible(oui)
        if not oui:
            return
        def placer():
            def x_de(ch):
                return ch.mapTo(self.rang_leg.parentWidget(), ch.rect().topLeft()).x() - self.rang_leg.x()
            for lg in (self.leg1, self.leg2):
                lg.setParent(self.rang_leg)
            if getattr(self, "_leg_trouve", False):        # après la recherche : Version / Produit 1 et 2
                for lg, ch in ((self.leg1, self.champ), (self.leg2, self.champ2)):
                    lg.setGeometry(x_de(ch), 0, ch.width(), 16)
                    lg.show()
            else:                                          # avant : une seule consigne sous les deux cases
                x0 = x_de(self.champ)
                self.leg1.setText("Entrer les références")
                self.leg1.setGeometry(x0, 0, x_de(self.champ2) + self.champ2.width() - x0, 16)
                self.leg1.show()
                self.leg2.hide()
            self.rang_leg.setFixedHeight(16)
        QTimer.singleShot(0, placer)

    def resizeEvent(self, e):
        super().resizeEvent(e)
        if getattr(self, "_deux", False):
            self._placer_legendes(True)

    def _legendes_a_refaire(self) -> None:
        if getattr(self, "_leg_trouve", False):
            self._leg_trouve = False
            if getattr(self, "_deux", False):
                self._placer_legendes(True)

    def _ouvrir_2e(self) -> None:
        self._deux_cases(True)
        self.champ2.setFocus()

    def _mettre_code(self, code: str) -> None:
        self._deux_cases(False)
        self.champ.setText(code)

    def _fermer_2e(self) -> None:
        self._deux_cases(False)
        self.champ.setFocus()

    # ---------------------------------------------------------------------- recherche
    def rechercher(self, forcer_site: bool = False):
        if self._occupe:
            return
        code = self.champ.text().strip()
        c2 = self.champ2.text().strip() if self._deux else ""
        if code and c2:
            code = f"{code} + {c2}"
        if not code:
            self._etat("info", "Saisissez un code produit.")
            return
        self._occupe = True
        self._maj_boutons()
        self._etat("info", f"Recherche de {code}…")
        taches.lancer(self.cat.obtenir, code, forcer_site, fini=self._trouve, erreur=self._echec(code))

    def _trouve(self, rep: Reponse):
        self._occupe = False
        self._afficher(rep.produit)
        self._etat_produit(rep.produit, rep.avertissement, rep.depuis_cache, rep.origine, rep.retire)
        self.rafraichir_historique()
        self.champ.selectAll()
        self.champ.setFocus()

    def _echec(self, code: str):
        def f(e: Exception):
            self._occupe = False
            self._maj_boutons()
            if isinstance(e, Ambiguite):
                dlg = ChoixCandidat(self, code, str(e), e.candidats)
                if dlg.exec() and dlg.url():
                    self._occupe = True
                    self._maj_boutons()
                    self._etat("info", "Vérification du produit choisi…")
                    taches.lancer(self.cat.choisir_candidat, code, dlg.url(), fini=self._trouve, erreur=self._echec(code))
                    return
                self._etat("avert", "Recherche annulée : aucun produit choisi.")
            elif isinstance(e, ErreurRecherche):
                self._etat("erreur", f"❌ {e}")
            else:
                self._etat("erreur", f"❌ Erreur inattendue : {e}")
            self._afficher(None)
            self.champ.selectAll()
            self.champ.setFocus()
        return f

    def depuis_fiche(self):
        dlg = DepuisFiche(self, self.champ.text().strip())
        if not dlg.exec():
            return
        self._occupe = True
        self._maj_boutons()
        self._etat("info", "Lecture de la fiche produit…")
        code = dlg.code.text().strip()
        taches.lancer(self.cat.depuis_fiche, dlg.url.text().strip(), code,
                      fini=lambda r: (self._mettre_code(r.produit.code), self._trouve(r)),
                      erreur=self._echec(code))

    def saisie_manuelle(self):
        dlg = SaisieManuelle(self, code=self.champ.text().strip())
        if not dlg.exec():
            return
        try:
            p = self.cat.creer_manuel(dlg.code.text(), dlg.nom.text(), Path(dlg.fichier))
        except Exception as e:
            QMessageBox.warning(self, "Erreur", str(e))
            return
        self._mettre_code(p.code)
        self._afficher(p)
        self._etat_produit(p)
        self.rafraichir_historique()

    def importer_csv(self):
        f, _ = QFileDialog.getOpenFileName(self, "Catalogue à importer", str(Path.home()),
                                           "Fichiers CSV (*.csv *.txt)")
        if not f:
            return
        self._occupe = True
        self._maj_boutons()
        self._etat("info", "Import du catalogue…")

        def fini(r):
            self._occupe = False
            self._maj_boutons()
            ok, err = r
            msg = f"{ok} produit(s) importé(s)."
            if err:
                msg += f"\n{len(err)} ligne(s) ignorée(s) :\n" + "\n".join(err[:15]) + ("\n…" if len(err) > 15 else "")
            QMessageBox.information(self, "Import terminé", msg)
            self._etat("ok" if ok else "avert", f"Catalogue : {ok} produit(s) importé(s).")
            self.rafraichir_historique()

        def echec(e):
            self._occupe = False
            self._maj_boutons()
            self._etat("erreur", f"❌ Import impossible : {e}")

        taches.lancer(self.cat.importer_csv, Path(f), fini=fini, erreur=echec)

    # ----------------------------------------------------------------------- actions
    def modifier(self):
        if not self.produit:
            return
        dlg = FenetreEdition(self, self.cat, self.produit)
        if dlg.exec():
            p = dlg.produit()
            if p.version2 is not None and self._deux:          # ordre inversé dans « Modifier »
                self.champ.blockSignals(True)
                self.champ.setText(p.code)
                self.champ.blockSignals(False)
                self.champ2.setText(p.version2.code)
            elif p.version2 is not None:
                self._mettre_code(f"{p.code} + {p.version2.code}")
            self._afficher(p)
            self._etat_produit(p)
            self.rafraichir_historique()

    def maj_etat_catalogue(self):
        if hasattr(self, "accueil"):
            self.accueil.maj()
        n = self.cat.base.nb_articles()
        if n:
            r = self.cat.base.nb_retires()
            self.l_catalogue.setText(f"📦  Catalogue hors ligne : <b>{n} produits</b><br>mis à jour le "
                                     f"{self.cat.base.valeur('catalogue_date', '?')}"
                                     + (f"<br>dont {r} plus sur le site, gardés" if r else ""))
        else:
            self.l_catalogue.setText("📦  Pas encore de catalogue hors ligne : cliquez sur « Catalogue hors ligne » "
                                     "en haut pour travailler sans Internet.")

    def etiquettes_energie(self):
        if not self.produit or self._occupe:
            return
        from .etiquettes import FenetreEtiquettes
        FenetreEtiquettes(self, self.cat.client, [self.produit], self.cat.base).exec()

    def _rappel_catalogue(self):
        """Toutes les 7 heures : « Pensez à faire une mise à jour du catalogue »."""
        if self.isMinimized():
            self.showNormal()
        b = QMessageBox(self)
        b.setIcon(QMessageBox.Icon.Information)
        b.setWindowTitle("Dépôt Print — catalogue")
        date = self.cat.base.valeur("catalogue_date", "jamais")
        b.setText("⏰ Pensez à faire une mise à jour du catalogue.")
        b.setInformativeText(f"Dernière mise à jour : {date}\n"
                             "(prix, nouveaux produits et produits retirés du site)")
        b.setStyleSheet("QLabel#qt_msgbox_label, QLabel#qt_msgbox_informativelabel { min-width: 430px; }")  # une phrase = une ligne
        maj = b.addButton("📦 Mettre à jour maintenant", QMessageBox.ButtonRole.AcceptRole)
        b.addButton("Plus tard", QMessageBox.ButtonRole.RejectRole)
        b.exec()
        if b.clickedButton() is maj:
            self.catalogue_hors_ligne()

    def catalogue_hors_ligne(self):
        from .catalogue_hl import FenetreCatalogue
        from .icones import appliquer
        d = FenetreCatalogue(self, self.cat)
        appliquer(d)
        d.exec()
        self._rappel.start()                          # prochain rappel dans 7 heures
        if hasattr(self, "parcourir"):
            self.parcourir.charger()
        if hasattr(self, "releve"):
            self.releve.charger()
        self.maj_etat_catalogue()

    def reglages(self):
        from .icones import appliquer
        d = FenetreReglages(self)
        appliquer(d)
        if d.exec():
            appliquer(self)
            self.rafraichir_historique()
            if self.produit:
                self._afficher(self.produit)
            self._etat("ok", "✅ Réglages enregistrés.")

    def _confirmer_si_douteux(self) -> bool:
        p = self.produit
        if p and (p.avertissement or not p.verifie):
            r = QMessageBox.question(
                self, "Affiche à vérifier",
                f"Ce produit est marqué « à vérifier » :\n{p.avertissement or 'non vérifié sur le site'}\n\n"
                f"Nom : {p.nom_affiche}\nCode : {p.code}\n\nAvez-vous contrôlé la photo et le nom ?",
            )
            return r == QMessageBox.StandardButton.Yes
        return True

    @staticmethod
    def nom_fichier(p: Produit) -> str:
        nom = re.sub(r"[^A-Za-z0-9]+", "_", p.nom_affiche.encode("ascii", "ignore").decode()).strip("_")
        codes = p.code + (f"+{p.version2.code}" if p.version2 is not None else "")
        return f"Affiche_{codes}_{nom[:50]}.pdf"

    def generer_pdf(self):
        p = self.produit
        if not p or not p.pret or not self._confirmer_si_douteux():
            return
        dest = paths.output_dir() / self.nom_fichier(p)
        try:
            affiche.creer_pdf([p], dest, p.nom_affiche)
        except PermissionError:
            QMessageBox.warning(self, "Fichier ouvert",
                                f"Le fichier est déjà ouvert dans un autre programme :\n{dest}\nFermez-le puis réessayez.")
            return
        except Exception as e:
            QMessageBox.critical(self, "Erreur", f"Le PDF n'a pas pu être créé :\n{e}")
            return
        self.cat.base.noter_affiche(p, "PDF", str(dest))
        self.annoncer_pdf(dest)
        self.rafraichir_historique()

    def annoncer_pdf(self, chemin: Path, dossier: bool = False, n: int = 1):
        box = QMessageBox(self)
        box.setWindowTitle("PDF enregistré")
        box.setIcon(QMessageBox.Icon.Information)
        box.setText(f"{n} PDF enregistrés dans :\n{chemin}" if dossier else f"PDF enregistré :\n{chemin}")
        b_ouvrir = None if dossier else box.addButton("Ouvrir le PDF", QMessageBox.ButtonRole.AcceptRole)
        b_dossier = box.addButton("Ouvrir le dossier", QMessageBox.ButtonRole.ActionRole)
        box.addButton("Fermer", QMessageBox.ButtonRole.RejectRole)
        box.exec()
        c = box.clickedButton()
        if b_ouvrir is not None and c is b_ouvrir:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(chemin)))
        elif c is b_dossier:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(chemin if dossier else chemin.parent)))

    def imprimer(self):
        p = self.produit
        if not p or not p.pret or self._occupe or not self._confirmer_si_douteux():
            return
        doc = affiche.pdf_en_memoire([p])
        try:
            if impression.imprimer(self, doc, f"Affiche {p.code}"):
                self.cat.base.noter_affiche(p, "impression")
                self._etat("ok", f"✅ Affiche {p.code} envoyée à l'imprimante.")
        except Exception as e:
            QMessageBox.critical(self, "Impression impossible", str(e))
        finally:
            doc.close()

    def apercu_impression(self):
        p = self.produit
        if not p or not p.pret:
            return
        doc = affiche.pdf_en_memoire([p])
        try:
            impression.apercu_avant_impression(self, doc, f"Affiche {p.code}")
        finally:
            doc.close()

    # ---------------------------------------------------------------------- historique
    def _lignes_historique(self) -> list[dict]:
        """Seulement les affiches sorties en PDF ou imprimées : « Un produit » ou « Deux produits »."""
        from ..reseau import nom_avec_reseau, reseau
        filtre = self.filtre.text().strip().lower()
        base = self.cat.base
        prods = {p.code: p for p in base.tous()}
        lignes = []
        for cle, date in base.impressions().items():
            codes = [c.strip() for c in cle.split("+")]
            ps = [prods.get(c) for c in codes]
            if any(p is None for p in ps):
                continue                                  # produit retiré de la mémoire
            avert = " · ".join(p.avertissement for p in ps if p.avertissement)
            sources = {p.source for p in ps}
            if len(ps) == 2:
                nom = "  +  ".join(nom_avec_reseau(p.nom_affiche, reseau(p)) for p in ps)   # nom 1 + nom 2
                type_ = "Deux produits"
            else:
                nom, type_ = ps[0].nom_affiche, "Un produit"
            lignes.append({"type": type_, "cle": " + ".join(codes), "code": " + ".join(codes), "nom": nom,
                           "source": " / ".join(sorted(sources)), "ok": not avert and all(p.verifie for p in ps),
                           "avert": avert, "maj": date,
                           "cherche": " ".join([cle] + [p.nom_affiche + " " + p.nom_site for p in ps]).lower()})
        if filtre:
            lignes = [l for l in lignes if filtre in l["cherche"]]
        lignes.sort(key=lambda l: l["maj"], reverse=True)
        return lignes

    def rafraichir_historique(self):
        if not hasattr(self, "t_hist"):
            return
        lignes = self._lignes_historique()
        self.t_hist.setRowCount(len(lignes))
        for i, l in enumerate(lignes):
            ctrl = "✅ vérifié" if l["ok"] else "⚠️ à vérifier"
            from .icones import txt
            ctrl = txt(ctrl)
            vals = [txt(("📱📱 " if l["type"] == "Deux produits" else "📱 ") + l["type"]), l["code"], l["nom"], l["source"], ctrl, l["maj"][:16]]
            for c, val in enumerate(vals):
                it = QTableWidgetItem(val)
                if c == 0:
                    it.setData(Qt.ItemDataRole.UserRole, l["cle"])
                    if l["type"] == "Deux produits":
                        it.setForeground(QColor("#E68A00"))
                        f = it.font()
                        f.setBold(True)
                        it.setFont(f)
                if c == 4 and l["avert"]:
                    it.setToolTip(l["avert"])
                self.t_hist.setItem(i, c, it)
        self.t_hist.resizeRowsToContents()           # deux produits : deux lignes (code + nom en face)

    def _codes_selection(self) -> list[str]:
        lignes = sorted({i.row() for i in self.t_hist.selectedIndexes()})
        return [self.t_hist.item(r, 0).data(Qt.ItemDataRole.UserRole) for r in lignes if self.t_hist.item(r, 0)]

    def _ouvrir_depuis_historique(self, ligne: int):
        if ligne < 0 or not self.t_hist.item(ligne, 0):
            return
        code = self.t_hist.item(ligne, 0).data(Qt.ItemDataRole.UserRole)
        if "+" in code:                                   # affiche à deux produits : les deux cases, puis recherche
            c1, c2 = [c.strip() for c in code.split("+")]
            self.onglets.setCurrentIndex(0)
            self._deux_cases(True)
            self.champ.setText(c1)
            self.champ2.setText(c2)
            self.rechercher()
            return
        p = self.cat.base.produit(code)
        if not p:
            return
        self.onglets.setCurrentIndex(0)
        self._mettre_code(code)
        self._afficher(p)
        self._etat_produit(p, cache=True)
        if not p.pret:
            self._etat("avert", "⚠️ Ce produit n'a pas de photo : ajoutez-la avec « Modifier ».")

    def _vers_lot(self):
        codes = self._codes_selection()
        if not codes:
            QMessageBox.information(self, "Aucune sélection", "Sélectionnez une ou plusieurs lignes.")
            return
        self.lot.ajouter_codes(codes)
        self.onglets.setCurrentWidget(self.lot)

    def _actualiser_selection(self):
        codes = self._codes_selection()
        if len(codes) != 1:
            QMessageBox.information(self, "Un produit à la fois", "Sélectionnez une seule ligne à actualiser.")
            return
        self.onglets.setCurrentIndex(0)
        if "+" in codes[0]:
            c1, c2 = [c.strip() for c in codes[0].split("+")]
            self._deux_cases(True)
            self.champ.setText(c1)
            self.champ2.setText(c2)
        else:
            self._mettre_code(codes[0])
        self.rechercher(forcer_site=True)

    def _supprimer_selection(self):
        codes = self._codes_selection()
        if not codes:
            return
        r = QMessageBox.question(self, "Retirer de la liste",
                                 f"Retirer {len(codes)} affiche(s) de la liste ?\n"
                                 "(Les PDF déjà créés ne sont pas supprimés.)")
        if r != QMessageBox.StandardButton.Yes:
            return
        for c in codes:
            self.cat.base.oublier_affiche(c)          # les produits restent connus (sans Internet)
        if self.produit and self.produit.code in {x.strip() for c in codes for x in c.split("+")}:
            self._afficher(None)
        self.rafraichir_historique()

    def _changement_onglet(self, i: int):
        if i == 0:
            self.champ.setFocus()
        elif i == 2:
            self.rafraichir_historique()

    def closeEvent(self, e):
        if self.lot.travail and self.lot.travail.isRunning():
            self.lot.travail.stop = True
            self.lot.travail.wait(5000)
        taches.attendre_fin(3000)
        super().closeEvent(e)
