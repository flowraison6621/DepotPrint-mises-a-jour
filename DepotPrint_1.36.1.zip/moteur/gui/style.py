"""Apparence de l'application (couleurs reprises du modèle d'affiche)."""

ORANGE = "#FF9900"        # cadre extérieur du modèle
JAUNE = "#FFD966"         # cadre intérieur du modèle
ENCRE = "#1C1F24"
GRIS = "#5B6270"
FOND = "#F3F4F6"

QSS = f"""
* {{ font-family: "Segoe UI", "Arial"; font-size: 10.5pt; color: {ENCRE}; }}
QMainWindow, QDialog {{ background: {FOND}; }}
QWidget#entete {{ background: {ENCRE}; }}
QLabel#titreApp {{ color: white; font-size: 17pt; font-weight: 700; }}
QLabel#sousTitreApp {{ color: #C9CDD4; font-size: 10pt; }}
QLabel#pastille {{ background: {ORANGE}; border: 3px solid {JAUNE}; border-radius: 8px; }}

QTabWidget::pane {{ border: none; background: {FOND}; }}
QTabBar::tab {{ background: transparent; color: {GRIS}; padding: 10px 22px; font-size: 11pt;
               font-weight: 600; border-bottom: 3px solid transparent; }}
QTabBar::tab:selected {{ color: {ENCRE}; border-bottom: 3px solid {ORANGE}; }}
QTabBar::tab:hover {{ color: {ENCRE}; }}

QFrame#carte {{ background: white; border: 1px solid #E2E4E8; border-radius: 10px; }}
QLabel#etiquette {{ color: {GRIS}; font-size: 9.5pt; font-weight: 600; }}
QLabel#nomAffiche {{ font-size: 15pt; font-weight: 800; }}
QLabel#petit {{ color: {GRIS}; font-size: 9.5pt; }}

QLineEdit#champCode {{ font-size: 24pt; font-weight: 700; padding: 8px 12px; border: 2px solid #C9CDD4;
                       border-radius: 8px; background: white; }}
QLineEdit#champCode[deux="true"] {{ font-size: 13pt; padding: 8px 8px; }}
QLineEdit#champCode:focus {{ border-color: {ORANGE}; }}
QLineEdit, QPlainTextEdit, QTableWidget {{ background: white; border: 1px solid #C9CDD4; border-radius: 6px; padding: 5px; }}
QLineEdit:focus, QPlainTextEdit:focus {{ border-color: {ORANGE}; }}

QPushButton {{ background: white; border: 1px solid #C9CDD4; border-radius: 7px; padding: 8px 16px; font-weight: 600; }}
QPushButton:hover {{ border-color: {ORANGE}; background: #FFF8EC; }}
QPushButton:pressed {{ background: #FFEFD2; }}
QPushButton:disabled {{ color: #A0A6B1; background: #F0F1F3; border-color: #E2E4E8; }}
QPushButton#principal {{ background: {ORANGE}; border: 1px solid #E68A00; color: {ENCRE}; font-size: 12pt; padding: 11px 18px; }}
QPushButton#principal:hover {{ background: #FFA826; }}
QPushButton#principal:disabled {{ background: #F3D9B0; color: #8D7550; border-color: #EBCB98; }}
QPushButton#modifier {{ background: {ORANGE}; border: 1px solid #E68A00; color: {ENCRE}; font-size: 12pt; padding: 11px 18px; }}
QPushButton#modifier:hover {{ background: #FFA826; }}
QPushButton#modifier:disabled {{ background: #F3D9B0; color: #8D7550; border-color: #EBCB98; }}
QPushButton#modifierPetit {{ background: {ORANGE}; border: 1px solid #E68A00; color: {ENCRE}; font-size: 10pt; padding: 6px 6px; }}
QPushButton#modifierPetit:hover {{ background: #FFA826; }}
QMessageBox QLabel#qt_msgbox_label, QMessageBox QLabel#qt_msgbox_informativelabel {{ min-width: 460px; }}
QPushButton#energie {{ background: #1E8A43; border: 1px solid #17733A; color: white; font-size: 11pt; padding: 9px 14px; }}
QPushButton#energie:hover {{ background: #22A04E; }}
QPushButton#energie:disabled {{ background: #BFDCC8; color: #EEF6F0; border-color: #BFDCC8; }}
QPushButton#bleu {{ background: #2D8FE0; border: 1px solid #1F7AC6; color: white; font-weight: 700; padding: 8px 16px; }}
QPushButton#bleu:hover {{ background: #3A9CEB; }}
QPushButton#chip {{ border-radius: 13px; padding: 4px 12px; }}
QPushButton#chip:checked {{ background: #2F8CCB; color: white; border-color: #2F8CCB; }}
QPushButton#mode:checked {{ background: #2F8CCB; color: white; border-color: #2F8CCB; }}
QPushButton#rechercher {{ background: {ENCRE}; color: white; border: none; font-size: 13pt; padding: 0 22px; }}
QPushButton#rechercher:hover {{ background: #343A44; }}
QPushButton#lien {{ background: transparent; border: none; color: #1F5FBF; text-align: left; padding: 3px 2px; font-weight: 500; }}
QPushButton#lien:hover {{ text-decoration: underline; background: transparent; }}

QLabel#bandeau {{ border-radius: 7px; padding: 9px 12px; font-weight: 600; }}
QLabel#bandeau[etat="ok"] {{ background: #E7F6EC; color: #1E6B36; border: 1px solid #B8E2C6; }}
QLabel#bandeau[etat="avert"] {{ background: #FFF4DB; color: #7A4F00; border: 1px solid #F2D58C; }}
QLabel#bandeau[etat="erreur"] {{ background: #FDECEC; color: #A3241B; border: 1px solid #F5C2BE; }}
QLabel#bandeau[etat="info"] {{ background: #EAF1FB; color: #1F4E8C; border: 1px solid #C3D6F2; }}

QLabel#apercu {{ background: #DADDE2; border-radius: 10px; }}
QProgressBar {{ border: 1px solid #C9CDD4; border-radius: 6px; background: white; height: 18px; text-align: center; }}
QProgressBar::chunk {{ background: {ORANGE}; border-radius: 5px; }}
QHeaderView::section {{ background: #EEF0F3; border: none; border-bottom: 1px solid #DADDE2; padding: 6px; font-weight: 700; }}
QTableWidget {{ gridline-color: #EEF0F3; selection-background-color: #FFE8C2; selection-color: {ENCRE}; }}
QSlider::groove:horizontal {{ height: 6px; background: #DADDE2; border-radius: 3px; }}
QSlider::handle:horizontal {{ background: {ORANGE}; width: 18px; margin: -6px 0; border-radius: 9px; }}
QRadioButton, QCheckBox {{ spacing: 8px; }}
"""
