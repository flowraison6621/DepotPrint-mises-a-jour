"""Émoticônes de l'interface : « icône + texte » (par défaut), « icône seule » ou « texte seul ».

Réglage choisi dans Réglages. L'affiche imprimée n'a jamais d'émoticône.
- texte seul : les émoticônes en début de texte sont retirées partout ;
- icône seule : boutons et onglets ne gardent que l'émoticône (le texte passe en info-bulle) ;
  les étiquettes et cases à cocher gardent leur texte, sinon on ne comprendrait plus rien.
"""
from __future__ import annotations

import re

from PySide6.QtWidgets import QCheckBox, QLabel, QPushButton, QTabWidget, QWidget

MODES = {"les_deux": "Icône + texte", "icone": "Icône seule", "texte": "Texte seul"}
# émoticônes ajoutées par le logiciel (les symboles utiles comme ⇄ ou ✕ ne sont jamais touchés)
EMOTICONES = "🖼☑🗂☎💻🍃📱📋🕘📦⚙📂🔍🏷🌐📍🎨📝➕🔗✍✅⚠❌⏳♻🔋🛡✏📄🖨👁🔎↩🔄🗑⏹💾📷✂📶🆕💶🚫⬇😀"
_UNE = "(?:[" + EMOTICONES + "]\ufe0f?)"
_EMO = re.compile("^(" + _UNE + "+)\\s*")
_PARTOUT = re.compile(_UNE + "+ *")


_MODE: str | None = None


def mode() -> str:
    global _MODE
    if _MODE is None:
        from ..reglages import lire_reglage
        m = lire_reglage("affichage_icones", "les_deux")
        _MODE = m if m in MODES else "les_deux"
    return _MODE


def oublier_mode() -> None:
    """Après un changement dans Réglages."""
    global _MODE
    _MODE = None


def separer(texte: str) -> tuple[str, str]:
    """(émoticône, texte) ; émoticône vide s'il n'y en a pas."""
    m = _EMO.match(texte or "")
    return (m.group(1), texte[m.end():]) if m else ("", texte or "")


def txt(texte: str, bouton: bool = False) -> str:
    """Texte à afficher selon le réglage (bouton : l'icône seule est permise)."""
    if mode() == "texte" and texte and _PARTOUT.search(texte):
        return _PARTOUT.sub("", texte) or texte          # aussi au milieu (« <b>2</b> ✅ prêts »)
    emo, reste = separer(texte)
    if not emo:
        return texte
    m = mode()
    if m == "texte":
        return reste or texte                    # « ⇄ » seul : on le garde
    if m == "icone" and bouton and reste:
        return emo
    return texte


def appliquer(racine: QWidget) -> None:
    """Applique le réglage à une fenêtre (peut être relancé : le texte d'origine est retenu)."""
    widgets = [racine] + racine.findChildren(QWidget)
    for w in widgets:
        if isinstance(w, (QPushButton, QCheckBox, QLabel)):
            actuel = w.text()
            if w.property("txtApplique") != actuel or w.property("txtOrigine") is None:
                w.setProperty("txtOrigine", actuel)        # texte changé depuis : nouvel original
            orig = w.property("txtOrigine")
            nouveau = txt(orig, bouton=isinstance(w, QPushButton))
            if isinstance(w, QPushButton):
                emo, reste = separer(orig)
                if nouveau != orig and nouveau == emo:
                    if not w.property("bulleAuto") and not w.toolTip():
                        w.setProperty("bulleAuto", True)
                    if w.property("bulleAuto"):
                        w.setToolTip(reste)
                elif w.property("bulleAuto"):
                    w.setToolTip("")
            if nouveau != actuel:
                w.setText(nouveau)
            w.setProperty("txtApplique", nouveau)
        if isinstance(w, QTabWidget):
            for i in range(w.count()):
                orig = w.tabBar().tabData(i) or w.tabText(i)
                w.tabBar().setTabData(i, orig)
                nouveau = txt(orig, bouton=True)
                w.setTabText(i, nouveau)
                w.setTabToolTip(i, separer(orig)[1] if nouveau != orig else "")
