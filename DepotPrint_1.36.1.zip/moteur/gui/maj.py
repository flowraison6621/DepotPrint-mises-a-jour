"""Bandeau « Nouvelle version disponible » / « Mis à jour » sous l'en-tête."""
from __future__ import annotations

import threading

from PySide6.QtCore import QObject, Qt, QTimer, Signal
from PySide6.QtWidgets import (QApplication, QHBoxLayout, QLabel, QMessageBox, QProgressDialog, QPushButton,
                               QVBoxLayout, QWidget)

from .. import mise_a_jour


class _Signaux(QObject):
    trouvee = Signal(object)
    avance = Signal(int, int)
    fini = Signal(str)            # '' = réussi, sinon le message d'erreur


class BandeauMaj(QWidget):
    def __init__(self, fenetre):
        super().__init__(fenetre)
        self.fenetre = fenetre
        self.setObjectName("bandeauMaj")
        self.v: mise_a_jour.Version | None = None
        h = QHBoxLayout(self)
        h.setContentsMargins(22, 12, 22, 12)
        h.setSpacing(12)
        self.icone = QLabel("🔄")
        self.icone.setAlignment(Qt.AlignmentFlag.AlignTop)
        h.addWidget(self.icone)
        col = QVBoxLayout()
        col.setSpacing(4)
        self.titre = QLabel("")
        self.titre.setObjectName("bandeauTitre")
        self.texte = QLabel("")
        self.texte.setWordWrap(True)
        col.addWidget(self.titre)
        col.addWidget(self.texte)
        hb = QHBoxLayout()
        self.b_installer = QPushButton("⬇️  Installer maintenant")
        self.b_installer.setObjectName("bleu")
        self.b_installer.clicked.connect(self.installer)
        self.b_plus_tard = QPushButton("Plus tard")
        self.b_plus_tard.clicked.connect(self.hide)
        hb.addWidget(self.b_installer)
        hb.addWidget(self.b_plus_tard)
        hb.addStretch(1)
        col.addLayout(hb)
        h.addLayout(col, 1)
        self.sig = _Signaux()
        self.sig.trouvee.connect(self._trouvee)
        self.hide()

    def _style(self, vert: bool) -> None:
        c, fond = ("#2e7d32", "#eaf7ee") if vert else ("#1565c0", "#e8f4ff")
        self.setStyleSheet(f"QWidget#bandeauMaj {{ background: {fond}; border-bottom: 2px solid {c}; }}"
                           f"QLabel#bandeauTitre {{ color: {c}; font-weight: 700; font-size: 15px; }}")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)

    # -- au démarrage ----------------------------------------------------------------------------
    def demarrer(self) -> None:
        v = mise_a_jour.confirmer()
        if v:
            self._style(True)
            self.icone.setText("✅")
            self.titre.setText(f"Mis à jour en version {v}")
            self.texte.setText("Tes catalogues, photos et réglages sont gardés.")
            self.b_installer.hide()
            self.b_plus_tard.hide()
            self.show()
            QTimer.singleShot(20000, self.hide)
        threading.Thread(target=lambda: self.sig.trouvee.emit(mise_a_jour.verifier()), daemon=True).start()

    def _trouvee(self, v) -> None:
        if v is None:
            return
        self.v = v
        self._style(False)
        self.icone.setText("🔄")
        self.titre.setText(f"Nouvelle version {v.version} disponible")
        self.texte.setText(v.notes or "Corrections et améliorations.")
        self.b_installer.show()
        self.b_plus_tard.show()
        self.show()

    # -- installation ----------------------------------------------------------------------------
    def installer(self) -> None:
        if self.v is None:
            return
        d = QProgressDialog("Téléchargement…", "", 0, 100, self.fenetre)
        d.setWindowTitle("🔄 Mise à jour en cours")
        d.setCancelButton(None)
        d.setWindowModality(Qt.WindowModality.ApplicationModal)
        d.setMinimumWidth(420)
        d.setMinimumDuration(0)
        d.setValue(0)

        def avance(recu, total):
            if total:
                d.setValue(min(99, recu * 100 // total))
            d.setLabelText(f"Téléchargement : {recu // 1024} Ko" + (f" sur {total // 1024} Ko" if total else "")
                           + "\nLe logiciel va redémarrer tout seul.")

        def fini(err):
            d.close()
            if err:
                QMessageBox.warning(self.fenetre, "Mise à jour", "La mise à jour n'a pas pu se faire :\n"
                                    f"{err}\n\nRien n'a changé : tu peux continuer normalement.")
                return
            mise_a_jour.redemarrer()
            QApplication.quit()

        s = _Signaux(self)
        s.avance.connect(avance)
        s.fini.connect(fini)
        self._s = s

        def tache():
            try:
                mise_a_jour.telecharger(self.v, lambda r, t: s.avance.emit(r, t))
                s.fini.emit("")
            except Exception as e:
                s.fini.emit(str(e) or type(e).__name__)
        threading.Thread(target=tache, daemon=True).start()
