"""Aperçu commun (relevé, étiquettes, affiches) : toutes les feuilles l'une sous l'autre,
à la largeur de la zone. Petite ou grande fenêtre : toujours pareil, jamais coupé."""
from __future__ import annotations

from PySide6.QtCore import QEvent, QObject, Qt, QTimer
from PySide6.QtGui import QColor, QPainter, QPixmap
from PySide6.QtWidgets import QLabel, QScrollArea, QSizePolicy


def feuilles(doc, larg: int, maxi: int = 15, haut_max: int = 0) -> QPixmap:
    """haut_max : chaque feuille A4 tient en entier dans cette hauteur (on la voit toute, sans défiler)."""
    larg = max(140, larg)
    titre0 = 20 if doc.page_count > 1 else 0
    if haut_max and doc.page_count:
        r = doc[0].rect
        larg = max(120, min(larg, int((haut_max - titre0 - 2) * r.width / r.height)))
    n = min(doc.page_count, maxi)
    images = []
    for i in range(n):
        dpi = int(max(12, min(110, larg / (doc[i].rect.width / 72))))
        pm = QPixmap()
        pm.loadFromData(doc[i].get_pixmap(dpi=dpi).tobytes("png"))
        if pm.width() > larg:                                   # arrondi du dpi : jamais plus large que la zone
            pm = pm.scaledToWidth(larg, Qt.TransformationMode.SmoothTransformation)
        images.append(pm)
    titre, ecart = (20, 10) if doc.page_count > 1 else (0, 0)
    haut = sum(titre + im.height() + ecart for im in images) - ecart
    total = QPixmap(larg, max(1, haut))
    total.fill(QColor(0, 0, 0, 0))
    pt = QPainter(total)
    y = 0
    for i, im in enumerate(images):
        if titre:
            pt.setPen(QColor("#555"))
            pt.drawText(0, y, larg, titre, Qt.AlignmentFlag.AlignCenter, f"Feuille {i + 1} / {doc.page_count}")
            y += titre
        x = (larg - im.width()) // 2
        pt.drawPixmap(x, y, im)
        pt.setPen(QColor("#bbb"))
        pt.drawRect(x, y, im.width() - 1, im.height() - 1)
        y += im.height() + ecart
    pt.end()
    return total


class ZoneApercu(QScrollArea):
    """Zone d'aperçu : redessine quand sa largeur change (ouverture, fenêtre agrandie ou réduite)."""

    def __init__(self, redessiner, parent=None):
        super().__init__(parent)
        self.setWidgetResizable(True)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.label = QLabel("")
        self.label.setAlignment(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop)
        self.label.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)   # n'élargit jamais le panneau
        self.label.setMinimumWidth(1)
        self.setWidget(self.label)
        self._redessiner = redessiner
        self._largeur = -1
        self._minuterie = QTimer(self, singleShot=True, interval=120)
        self._minuterie.timeout.connect(self._si_change)
        self.viewport().installEventFilter(self)

    def largeur(self) -> int:
        return self.viewport().width() - 4

    def _taille(self):
        return (self.viewport().width(), self.viewport().height())

    def eventFilter(self, obj, ev):
        if obj is self.viewport() and ev.type() in (QEvent.Type.Resize, QEvent.Type.Show):
            self._minuterie.start()
        return super().eventFilter(obj, ev)

    def _si_change(self) -> None:
        if self._taille() != getattr(self, "_derniere", None) and self.isVisible():
            self._redessiner()

    def montrer(self, doc) -> None:
        self._largeur = self.largeur()
        self._derniere = self._taille()
        pm = feuilles(doc, self._largeur, haut_max=self.viewport().height() - 4)
        self.label.setText("")
        self.label.setPixmap(pm)
        self.label.setMinimumHeight(pm.height())

    def texte(self, t: str) -> None:
        self._largeur = self.largeur()
        self.label.setPixmap(QPixmap())
        self.label.setMinimumHeight(0)
        self.label.setText(t)
