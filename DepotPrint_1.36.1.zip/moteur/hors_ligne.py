"""Catalogue hors ligne : télécharge les rayons du site (produits + photos) pour
générer les affiches sans Internet.

Source : les pages publiques des rayons d'electrodepot.fr, lues page par page
comme un visiteur, à un rythme modéré (une requête par seconde environ).
Chaque page contient déjà code, désignation, couleur, prix et photo.
"""

from __future__ import annotations

import re

from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable

from . import images
from .base import Base
from .coloris import variantes
from .electrodepot import BASE, ClientElectroDepot, Resultat, extraire_produits, lire_prix
from .models import ErreurRecherche
from .reglages import tarif_pour_prix

# (identifiant, libellé, adresse du rayon, coché par défaut)
RAYONS = [
    ("smartphones", "Smartphones neufs", "/smartphone-mobilite/smartphone-telephone/smartphone.html", True),
    ("mobiles", "Téléphones mobiles (séniors…)", "/smartphone-mobilite/smartphone-telephone/telephone-mobile.html", True),
    ("smartphones_recond", "Smartphones reconditionnés", "/smartphone-mobilite/smartphone-reconditionne.html", True),
    ("tablettes", "Tablettes", "/informatique-gaming-tablette/tablette-tactile/tablette.html", True),
    ("ipad_recond", "iPad reconditionnés", "/informatique-gaming-tablette/tablette-tactile/ipad-reconditionne.html", True),
    ("consoles", "Consoles et manettes", "/informatique-gaming-tablette/console.html", True),
    ("stockage", "Stockage", "/informatique-gaming-tablette/stockage.html", False),
    # rayons lus SEULEMENT pour les étiquettes énergie (pas de photos ni d'affiches)
    ("tv", "Téléviseurs", "/tv-image-son/television.html", False),
    ("moniteurs", "Moniteurs", ("/informatique-gaming-tablette/ordinateur/ecran-pc.html",
                                "/informatique-gaming-tablette/pc-gaming/ecran-pc-gamer.html"), False),
    ("refrigerateurs", "Réfrigérateurs et caves à vin", "/gros-electromenager/refrigerateur.html", False),
    ("congelateurs", "Congélateurs", "/gros-electromenager/congelateur.html", False),
    ("lave_linge", "Lave-linge", "/gros-electromenager/lave-linge.html", False),
    ("seche_linge", "Sèche-linge", "/gros-electromenager/seche-linge.html", False),
    ("lave_vaisselle", "Lave-vaisselle", "/gros-electromenager/lave-vaisselle.html", False),
    ("fours", "Fours", ("/gros-electromenager/four-micro-ondes/four-encastrable.html",
                        "/gros-electromenager/four-micro-ondes/mini-four-posable.html"), False),
    ("hottes", "Hottes", "/gros-electromenager/hotte.html", False),
    ("cuisinieres", "Cuisinières", "/gros-electromenager/cuisiniere.html", False),
    ("plaques", "Tables de cuisson", "/gros-electromenager/plaque-de-cuisson.html", False),
    ("climatiseurs", "Climatiseurs", "/maison-entretien-beaute/climatisation-ventilation/climatiseur.html", False),
    ("ampoules", "Ampoules", "/maison-entretien-beaute/electricite-domotique/ampoule.html", False),
]
from .energie import ETIQUETTES_SEULES      # rayons « étiquettes énergie seulement »

# rayons sans affiche (pas de TRAME TEL) : électroménager, TV… et le stockage (relevés de quantités)
SANS_AFFICHE = ETIQUETTES_SEULES | {"stockage"}

# Les mêmes groupes, dans le même ordre, partout : cases de « Mettre à jour le catalogue »
# et catégories de « Parcourir le catalogue ». (clé de catégorie, libellé, rayons du site)
GROUPES = [
    ("neufs", "📱 Smartphones neufs", ["smartphones"]),
    ("recond", "♻️ Smartphones reconditionnés", ["smartphones_recond"]),
    ("mobiles", "☎️ Téléphones mobiles\n(séniors…)", ["mobiles"]),
    ("tablettes", "💻 Tablettes", ["tablettes"]),
    ("ipad_recond", "♻️ iPad reconditionnés", ["ipad_recond"]),
    ("consoles", "🎮 Consoles et manettes", ["consoles"]),
    ("stockage", "💾 Stockage", ["stockage"]),
    ("tv_ecrans", "📺 TV et moniteurs", ["tv", "moniteurs"]),
    ("froid", "❄️ Froid\n(réfrigérateurs, congélateurs)", ["refrigerateurs", "congelateurs"]),
    ("lavage", "🧺 Lavage\n(lave-linge, sèche-linge,\nlave-vaisselle)", ["lave_linge", "seche_linge", "lave_vaisselle"]),
    ("cuisson", "🍳 Cuisson\n(fours, cuisinières,\ntables de cuisson, hottes)", ["fours", "cuisinieres", "plaques", "hottes"]),
    ("clim", "🌬️ Climatisation", ["climatiseurs"]),
    ("eclairage", "💡 Éclairage\n(ampoules)", ["ampoules"]),
]

# le rayon « console » du site mélange consoles, manettes, jeux et produits dérivés :
# on ne garde que les consoles (salon et portables) et les manettes
FILTRES = {"consoles": re.compile(r"^\s*(console|manette)", re.I)}
PAGES_MAX = 40          # garde-fou


@dataclass
class Bilan:
    total: int = 0
    nouveaux: list = field(default_factory=list)            # [(code, nom)]
    prix_modifies: list = field(default_factory=list)       # [(code, nom, ancien, nouveau)]
    tranche_modifiee: list = field(default_factory=list)    # [(code, nom, ancien_tarif, nouveau_tarif)]
    retires: list = field(default_factory=list)             # [(code, nom)]
    photos_manquantes: list = field(default_factory=list)   # [(code, nom)]
    etiquettes: int = 0                                      # étiquettes énergie gardées sur l'ordinateur
    arrete: bool = False
    date: str = ""


def dossier_photos(base_dir: Path) -> Path:
    d = base_dir / "photos" / "catalogue"
    d.mkdir(parents=True, exist_ok=True)
    return d


def lire_rayon(client: ClientElectroDepot, chemin: str, arret: Callable[[], bool] = lambda: False) -> list[dict]:
    """Toutes les pages d'un rayon. Au-delà de la dernière page, le site renvoie la
    page 1 : on s'arrête dès qu'une page n'apporte plus rien de nouveau."""
    vus: dict[str, dict] = {}
    for n in range(1, PAGES_MAX + 1):
        if arret():
            break
        url = BASE + chemin + (f"?page={n}" if n > 1 else "")
        r = client._get(url)
        if r.status_code != 200:
            break
        nouveaux = 0
        for p in extraire_produits(r.text):
            code = (p.get("refCode") or p.get("sku") or "").strip()
            if code and code not in vus:
                vus[code] = p
                nouveaux += 1
        if nouveaux == 0:
            break
    return list(vus.values())


def mettre_a_jour(base: Base, client: ClientElectroDepot, dossier_donnees: Path, rayons: list[str],
                  progres: Callable[[int, int, str], None] = lambda *a: None,
                  arret: Callable[[], bool] = lambda: False) -> Bilan:
    bilan = Bilan()
    choisis = [r for r in RAYONS if r[0] in rayons]
    avant = base.articles()

    # 1) listes des rayons
    articles: dict[str, dict] = {}
    for i, (ident, libelle, chemin, _) in enumerate(choisis):
        progres(i, len(choisis), f"Lecture du rayon « {libelle} »…")
        produits = []
        for ch in (chemin if isinstance(chemin, tuple) else (chemin,)):
            produits += lire_rayon(client, ch, arret)
        for p in produits:
            code = (p.get("refCode") or p.get("sku") or "").strip()
            nom = (p.get("name") or "").strip()
            if not code or not nom or code in articles:
                continue
            if ident in FILTRES and not FILTRES[ident].search(nom):
                continue
            item = p.get("itemUrl", "")
            articles[code] = {
                "code": code, "nom": nom, "coloris": p.get("coloris", ""),
                "prix": lire_prix(p.get("price", "")), "rayon": ident,
                "url_fiche": (BASE + "/" + item + ("" if item.endswith(".html") else ".html")) if item and not item.startswith("http") else item,
                "url_image": p.get("imageUrl", ""), "attributs": p,
            }
        if arret():
            bilan.arrete = True
            return bilan

    # 2) photos (seulement celles qui manquent)
    dossier = dossier_photos(dossier_donnees)
    liste = list(articles.values())
    for i, a in enumerate(liste):
        if arret():
            bilan.arrete = True
            return bilan
        dest = dossier / f"{a['code']}.png"          # tous les rayons : la photo sert de vignette dans Parcourir
        progres(i, len(liste), f"Photos : {a['nom']}")
        if not dest.is_file():
            try:
                data = client.telecharger_photo(Resultat(code=a["code"], nom=a["nom"], url_fiche=a["url_fiche"],
                                                          url_image=a["url_image"]))
                images.preparer(data, dest)
            except (ErreurRecherche, images.ImageInvalide, OSError):
                bilan.photos_manquantes.append((a["code"], a["nom"]))
                continue
        a["photo"] = str(dest)

    # 2 bis) contenu de la boîte : lu sur la fiche de chaque NOUVEAU produit (sinon repris)
    for i, a in enumerate(liste):
        if arret():
            bilan.arrete = True
            return bilan
        if a["rayon"] in SANS_AFFICHE:
            continue
        deja = avant.get(a["code"], {}).get("boite") or ""
        if deja and deja not in ("{}", ""):
            import json as _json
            a["boite"] = _json.loads(deja)
            continue
        progres(i, len(liste), f"Contenu des boîtes : {a['nom']}")
        if a.get("url_fiche"):
            infos = client.lire_fiche(a["url_fiche"])
            if infos:
                a["boite"] = {"acc": infos.get("accessoires", ""), "desc": infos.get("description_boite", "")}

    # 2 ter) étiquettes énergie : seulement les produits qui ont une classe énergétique sur le site
    from . import energie
    for i, a in enumerate(liste):
        if arret():
            bilan.arrete = True
            return bilan
        if not (a.get("attributs") or {}).get("classe_energetique"):
            continue
        if energie.origine(a["code"]) != "EPREL":
            progres(i, len(liste), f"Étiquettes énergie : {a['nom']}")
            try:            # image du site, puis la version officielle nette EPREL si le modèle est sûr
                energie.obtenir(client, a["code"], article=a)
            except (energie.SansEtiquette, ErreurRecherche, OSError):
                continue
        bilan.etiquettes += 1

    # 3) coloris et réseaux, calculés sur tout le catalogue (rayons non mis à jour compris)
    tous = {c: {"refCode": c, "name": v["nom"], "coloris": ""} for c, v in avant.items()
            if not v.get("retire") and c not in articles}
    for a in liste:
        tous[a["code"]] = {"refCode": a["code"], "name": a["nom"], "coloris": a["coloris"]}
    autres = list(tous.values())
    for a in liste:
        a["variantes"] = ([] if a["rayon"] in SANS_AFFICHE
                          else variantes(a["code"], a["nom"], a["coloris"], autres))

    # 4) bilan par rapport à la mise à jour précédente
    for a in liste:
        ancien = avant.get(a["code"])
        if not ancien:
            bilan.nouveaux.append((a["code"], a["nom"]))
        elif abs((ancien["prix"] or 0) - (a["prix"] or 0)) > 0.005:
            bilan.prix_modifies.append((a["code"], a["nom"], ancien["prix"], a["prix"]))
            t1, t2 = tarif_pour_prix(ancien["prix"]), tarif_pour_prix(a["prix"])
            if t1 != t2:
                bilan.tranche_modifiee.append((a["code"], a["nom"], t1, t2))
    # 5) produits disparus du site : GARDÉS dans le catalogue, marqués « retiré du site »
    for c in base.remplacer_catalogue(liste, rayons):
        bilan.retires.append((c, avant[c]["nom"] if c in avant else c))
    bilan.total = base.nb_articles()
    bilan.date = datetime.now().strftime("%d/%m/%Y à %H:%M")
    base.ecrire_valeur("catalogue_date", bilan.date)
    progres(len(liste), len(liste), "Terminé")
    return bilan
