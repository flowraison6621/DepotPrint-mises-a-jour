"""Contenu de la boîte → pictogrammes en orange sur l'affiche (orange = inclus).

Ordre des 5 pictogrammes du modèle : 0 chargeur, 1 câble, 2 écouteurs, 3 coque, 4 écran.

Sources, de la plus fiable à la moins fiable :
  - ligne « Accessoires » de la fiche produit (téléphones) : « Câble de charge »,
    « Coque de protection, Câble de charge », « Socle chargeur »… ;
  - le nom quand c'est un lot (tablettes surtout) : « … + Coque silicone », « + Etui » ;
  - la description : « Câble USB C inclus / chargeur secteur non inclus »,
    « Livré avec accessoires neufs compatibles (câble) et une coque de protection ».
Si le site n'indique rien : câble seul (comme le modèle d'origine) et le logiciel le signale.
"""

from __future__ import annotations

import html
import re
import unicodedata

NOMS = ["Chargeur", "Câble", "Écouteurs", "Coque", "Écran"]
PAR_DEFAUT = [1]          # le modèle d'origine : câble en orange


def _n(s: str) -> str:
    s = "".join(c for c in unicodedata.normalize("NFD", (s or "").lower()) if unicodedata.category(c) != "Mn")
    return re.sub(r"\s+", " ", s)


_REGLES = [
    (0, r"chargeur|adaptateur secteur|bloc secteur", r"chargeur(?: secteur)? (?:non|pas) (?:inclus|fourni)"),
    (1, r"\bcable\b|cordon", r"cable[^.;,]{0,20}(?:non|pas) (?:inclus|fourni)"),
    (2, r"ecouteur|kit pieton|oreillette", r"ecouteurs? (?:non|pas) (?:inclus|fournis?)"),
    (3, r"\bcoque\b|\betui\b|\bfolio\b|\bhousse\b", r"coque (?:non|pas) (?:incluse|fournie)"),
    (4, r"verre trempe|film de protection|protection d.ecran|protege.ecran", r"(?:verre|film)[^.;,]{0,20}(?:non|pas) (?:inclus|fourni)"),
]


def _depuis_texte(texte: str) -> set[int]:
    t = _n(texte)
    trouves = set()
    for k, oui, non in _REGLES:
        if re.search(oui, t) and not re.search(non, t):
            trouves.add(k)
    return trouves


def detecter(accessoires: str = "", nom: str = "", description: str = "",
             reconditionne: bool = False) -> tuple[list[int], bool]:
    """(pictogrammes inclus, le site l'indique-t-il ?).

    - Reconditionnés : câble seul, par sécurité (les fiches du site se contredisent :
      iPhone 12 Mini annoncé « câble, chargeur et coque », livré avec le câble seul).
    - Neufs : la ligne « Accessoires » fait foi ; la description ne sert que si elle manque.
    - Lots (« + Coque silicone », « + Folio ») : toujours ajoutés.
    """
    inclus: set[int] = set()
    indique = False
    if reconditionne:
        accessoires = description = ""
    if accessoires.strip():
        inclus |= _depuis_texte(accessoires)
        indique = True
    elif description.strip():
        k = _depuis_texte(description)
        if k or re.search(r"non inclus|pas inclus", _n(description)):
            inclus |= k
            indique = True
    if not indique:
        inclus = set(PAR_DEFAUT)          # contenu non indiqué : câble, comme le modèle d'origine
    # lots : « + Coque silicone », « + Etui et clavier » → ajoutés dans tous les cas
    for morceau in re.findall(r"\+\s*([^+]+)", nom or ""):
        inclus |= _depuis_texte(morceau)
    return sorted(inclus), indique


def texte(inclus: list[int]) -> str:
    return ", ".join(NOMS[k] for k in sorted(inclus)) if inclus else "rien de signalé"


# --- lecture sur la fiche produit -----------------------------------------------------

def depuis_fiche(page: str) -> tuple[str, str]:
    """(valeur de la ligne « Accessoires », phrases de la description sur le contenu)."""
    m = re.search(r"<t[dh][^>]*>\s*Accessoires\.?\s*</t[dh]>\s*<td[^>]*>(.*?)</td>", page, re.S | re.I)
    acc = " ".join(html.unescape(re.sub(r"<[^>]+>", " ", m.group(1))).split()) if m else ""
    # description du produit uniquement (bloc principal, sans menus ni produits recommandés)
    debut = page.find('class="prodItem"')
    corps = page[debut:] if debut >= 0 else page
    for coupe in ("Recommandé avec ce produit", "Rated ", "productlist-item"):
        i = corps.find(coupe)
        if i > 0:
            corps = corps[:i]
    txt = " ".join(html.unescape(re.sub(r"<[^>]+>", " ", re.sub(r"<script.*?</script>", " ", corps, flags=re.S))).split())
    phrases = re.findall(r"(?:Livr[ée]e? avec|[Ff]ourni(?:e|s)? avec|[Cc]ontenu de la bo[iî]te)[^.]{0,160}"
                         r"|[^.;:]{0,60}\b(?:inclus|incluse|incluses)\b[^.]{0,60}", txt)
    phrases = [p for p in phrases if not re.search(r"livraison|retrait|reprise|garantie|TVA|prix", p, re.I)]
    return acc, " / ".join(dict.fromkeys(p.strip() for p in phrases))[:400]
