"""Lanceur de Dépôt Print (c'est ce fichier que PyInstaller transforme en .exe)."""

import sys
import traceback


def _demarrage_maj():
    """Mise à jour téléchargée : mise en place avant de charger le logiciel.
    Nouvelle version qui n'avait pas réussi à démarrer : l'ancienne revient."""
    import importlib.util
    from pathlib import Path
    r = Path(__file__).resolve().parent
    f = r / "moteur" / "mise_a_jour.py"
    if not f.is_file() or getattr(sys, "frozen", False):
        return None, r
    try:
        spec = importlib.util.spec_from_file_location("_maj_demarrage", f)
        m = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = m                     # nécessaire pour @dataclass
        spec.loader.exec_module(m)
        if "--apres-maj" in sys.argv:
            import time
            time.sleep(2)                              # l'ancienne fenêtre a le temps de se fermer
        if (r / m.A_CONFIRMER).is_file() and "--apres-maj" not in sys.argv:
            m.revenir(r)                               # dernier démarrage raté : on revient en arrière
        m.mettre_en_place(r)
        return m, r
    except Exception:
        traceback.print_exc()
        return None, r


def main() -> int:
    maj, racine = _demarrage_maj()
    try:
        return _main()
    except Exception:
        # la nouvelle version ne démarre pas : l'ancienne revient et se relance
        if maj is not None and (racine / maj.A_CONFIRMER).is_file() and maj.revenir(racine):
            import subprocess
            subprocess.Popen([sys.executable, "-E", "-s", str(racine / "DepotPrint.py")], cwd=str(racine))
            return 1
        raise


def _main() -> int:
    from PySide6.QtCore import QLibraryInfo, QLocale, QTranslator
    from PySide6.QtWidgets import QApplication, QMessageBox

    app = QApplication(sys.argv)
    app.setApplicationName("Dépôt Print")
    app.setOrganizationName("DepotPrint")
    QLocale.setDefault(QLocale(QLocale.Language.French, QLocale.Country.France))

    # Boîtes de dialogue Qt (impression, fichiers) en français
    trad = QTranslator(app)
    if trad.load(QLocale(QLocale.Language.French), "qtbase", "_",
                 QLibraryInfo.path(QLibraryInfo.LibraryPath.TranslationsPath)):
        app.installTranslator(trad)

    from PySide6.QtCore import Qt
    from moteur.gui.style import QSS
    # Toujours l'apparence claire validée, même si Windows est en mode sombre
    try:
        app.styleHints().setColorScheme(Qt.ColorScheme.Light)
    except AttributeError:
        pass
    app.setStyle("Fusion")
    app.setPalette(app.style().standardPalette())
    app.setStyleSheet(QSS)

    def erreur_globale(typ, val, tb):
        texte = "".join(traceback.format_exception(typ, val, tb))
        try:
            from moteur import paths
            (paths.data_dir() / "erreurs.log").open("a", encoding="utf-8").write(texte + "\n")
        except Exception:
            pass
        QMessageBox.critical(None, "Dépôt Print — erreur",
                             f"Une erreur inattendue s'est produite :\n\n{val}\n\n"
                             "Le logiciel reste utilisable.\nDétails enregistrés dans erreurs.log.")

    sys.excepthook = erreur_globale

    # plantage brutal (sans message) : la trace est écrite dans plantage.log
    try:
        import faulthandler
        from moteur import paths as _p
        _journal = (_p.data_dir() / "plantage.log").open("a", encoding="utf-8")
        _journal.write("\n--- lancement ---\n")
        _journal.flush()
        faulthandler.enable(file=_journal, all_threads=True)
    except Exception:
        pass

    # une seule fenêtre à la fois
    from moteur.gui import unique
    if unique.deja_ouvert():
        b = QMessageBox(QMessageBox.Icon.Information, "Dépôt Print",
                        "Dépôt Print est déjà ouvert.\n"
                        "(la fenêtre déjà ouverte passe au premier plan)")
        b.setStyleSheet("QLabel#qt_msgbox_label { min-width: 380px; }")
        b.exec()
        return 0

    from moteur.gui.fenetre import FenetrePrincipale
    try:
        f = FenetrePrincipale()
    except Exception as e:
        from pathlib import Path
        if (Path(__file__).resolve().parent / "maj_a_confirmer.txt").is_file():
            raise                                       # nouvelle version : l'ancienne va revenir
        QMessageBox.critical(None, "Dépôt Print", f"Démarrage impossible :\n{e}")
        return 1
    unique.ecouter(f)
    f.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
