"""Mise à jour automatique de Dépôt Print.

À l'ouverture, le logiciel lit un petit fichier en ligne (MANIFESTE) qui donne la dernière
version. S'il y a plus récent : bandeau « Nouvelle version disponible ».

« Installer maintenant » télécharge un petit zip (le code du logiciel seulement : dossier
« moteur », « assets » et DepotPrint.py), vérifie son empreinte SHA-256, le décompresse dans
« maj_attente » puis redémarre. Au démarrage suivant, DepotPrint.py met la nouvelle version
en place (l'ancienne est gardée dans « maj_ancienne »). Si la nouvelle version ne démarre
pas, l'ancienne revient toute seule.

Python, catalogue, photos, réglages et PDF ne sont jamais touchés.
Sans Internet : rien ne se passe, le logiciel démarre normalement.
"""
from __future__ import annotations

import hashlib
import json
import re
import shutil
import subprocess
import sys
import zipfile
from dataclasses import dataclass
from pathlib import Path


MANIFESTE = "https://raw.githubusercontent.com/flowraison6621/DepotPrint-mises-a-jour/main/derniere.json"
TIMEOUT = (4, 20)
ELEMENTS = ("moteur", "assets", "DepotPrint.py")        # ce qu'une mise à jour peut remplacer
ATTENTE = "maj_attente"
ANCIENNE = "maj_ancienne"
A_CONFIRMER = "maj_a_confirmer.txt"


@dataclass
class Version:
    version: str
    notes: str
    url: str
    sha256: str
    taille: int


def racine() -> Path:
    """Dossier du logiciel (là où est DepotPrint.py)."""
    return Path(__file__).resolve().parent.parent


def possible() -> bool:
    """Pas pour l'exe PyInstaller (tout est dans l'exe) ni un dossier en lecture seule."""
    if getattr(sys, "frozen", False):
        return False
    r = racine()
    if not (r / "DepotPrint.py").is_file():
        return False
    try:
        essai = r / ".essai_maj"
        essai.write_text("x")
        essai.unlink()
        return True
    except OSError:
        return False


def _num(v: str) -> tuple:
    return tuple(int(x) for x in re.findall(r"\d+", v or "")[:4])


def version_actuelle() -> str:
    m = re.search(r'APP_VERSION\s*=\s*"([^"]+)"', (racine() / "moteur" / "__init__.py").read_text(encoding="utf-8"))
    return m.group(1) if m else "0"


def plus_recente(v: str, actuelle: str | None = None) -> bool:
    return _num(v) > _num(actuelle or version_actuelle())


def chercher() -> tuple[Version | None, str]:
    """Bouton « Rechercher une mise à jour » : (nouvelle version ou None, message d'erreur ou '')."""
    if not possible():
        return None, "cette version du logiciel ne peut pas se mettre à jour toute seule"
    try:
        import requests
        r = requests.get(MANIFESTE, timeout=TIMEOUT, headers={"Cache-Control": "no-cache"})
        if r.status_code != 200:
            return None, f"le site des mises à jour ne répond pas ({r.status_code})"
        d = json.loads(r.text)
        v = Version(str(d["version"]), str(d.get("notes") or ""), str(d["url"]),
                    str(d["sha256"]).lower(), int(d.get("taille") or 0))
    except Exception:
        return None, "pas de connexion Internet"
    return (v if plus_recente(v.version) else None), ""


def verifier(session=None) -> Version | None:
    """La nouvelle version si elle existe, sinon None (aussi sans Internet : jamais d'erreur)."""
    if not possible():
        return None
    try:
        import requests
        r = (session or requests).get(MANIFESTE, timeout=TIMEOUT, headers={"Cache-Control": "no-cache"})
        if r.status_code != 200:
            return None
        d = json.loads(r.text)
        v = Version(str(d["version"]), str(d.get("notes") or ""), str(d["url"]),
                    str(d["sha256"]).lower(), int(d.get("taille") or 0))
    except Exception:
        return None
    return v if plus_recente(v.version) else None


def telecharger(v: Version, progression=None) -> Path:
    """Télécharge et vérifie le zip, puis le prépare dans « maj_attente »."""
    r = racine()
    dossier = r / ATTENTE
    shutil.rmtree(dossier, ignore_errors=True)
    dossier.mkdir()
    zip_ = dossier / "paquet.zip"
    h = hashlib.sha256()
    import requests
    with requests.get(v.url, stream=True, timeout=TIMEOUT) as rep:
        rep.raise_for_status()
        total = int(rep.headers.get("Content-Length") or v.taille or 0)
        recu = 0
        with zip_.open("wb") as f:
            for bloc in rep.iter_content(64 * 1024):
                f.write(bloc)
                h.update(bloc)
                recu += len(bloc)
                if progression:
                    progression(recu, total)
    if h.hexdigest() != v.sha256:
        shutil.rmtree(dossier, ignore_errors=True)
        raise ValueError("le fichier téléchargé est abîmé (empreinte différente)")
    preparer(zip_, dossier, v.version)
    zip_.unlink()
    return dossier


def preparer(zip_: Path, dossier: Path, version: str) -> None:
    """Décompresse et contrôle : bon contenu, bonne version, code Python lisible."""
    with zipfile.ZipFile(zip_) as z:
        for n in z.namelist():
            if n.startswith("/") or ".." in Path(n).parts or Path(n).parts[0] not in ELEMENTS:
                raise ValueError(f"contenu inattendu dans la mise à jour : {n}")
        z.extractall(dossier)
    init = dossier / "moteur" / "__init__.py"
    if not init.is_file():
        raise ValueError("mise à jour incomplète")
    m = re.search(r'APP_VERSION\s*=\s*"([^"]+)"', init.read_text(encoding="utf-8"))
    if not m or _num(m.group(1)) != _num(version):
        raise ValueError("la version du paquet ne correspond pas")
    for f in dossier.rglob("*.py"):
        compile(f.read_text(encoding="utf-8"), str(f), "exec")
    (dossier / "pret.txt").write_text(version, encoding="utf-8")


def redemarrer() -> None:
    """Relance Dépôt Print (la mise en place se fait au démarrage, dans DepotPrint.py)."""
    exe = Path(sys.executable)
    if exe.name.lower() == "python.exe" and (exe.parent / "pythonw.exe").is_file():
        exe = exe.parent / "pythonw.exe"
    opts = {}
    if sys.platform == "win32":
        opts["creationflags"] = 0x00000008 | 0x00000200        # DETACHED_PROCESS | NEW_PROCESS_GROUP
    subprocess.Popen([str(exe), "-E", "-s", str(racine() / "DepotPrint.py"), "--apres-maj"],
                     cwd=str(racine()), close_fds=True, **opts)


# -- au démarrage (appelé par DepotPrint.py, avant d'importer le reste) -------------------------
# Ces fonctions n'importent rien du logiciel : DepotPrint.py charge ce fichier tout seul.
def mettre_en_place(r: Path) -> str:
    """Remplace le code par celui de « maj_attente ». Renvoie la version installée ('' sinon)."""
    att = r / ATTENTE
    if not (att / "pret.txt").is_file():
        return ""
    version = (att / "pret.txt").read_text(encoding="utf-8").strip()
    anc = r / ANCIENNE
    shutil.rmtree(anc, ignore_errors=True)
    anc.mkdir()
    deplaces = []
    try:
        for nom in ELEMENTS:
            if (att / nom).exists():
                if (r / nom).exists():
                    (r / nom).rename(anc / nom)
                    deplaces.append(nom)
                (att / nom).rename(r / nom)
    except OSError:
        for nom in deplaces:                     # on remet tout comme avant
            if (r / nom).exists():
                shutil.rmtree(r / nom, ignore_errors=True) if (r / nom).is_dir() else (r / nom).unlink()
            (anc / nom).rename(r / nom)
        return ""
    shutil.rmtree(att, ignore_errors=True)
    (r / A_CONFIRMER).write_text(version, encoding="utf-8")
    return version


def revenir(r: Path) -> bool:
    """La nouvelle version n'a pas démarré : l'ancienne revient."""
    anc = r / ANCIENNE
    if not anc.is_dir() or not any(anc.iterdir()):
        return False
    for nom in ELEMENTS:
        if (anc / nom).exists():
            cible = r / nom
            if cible.is_dir():
                shutil.rmtree(cible, ignore_errors=True)
            elif cible.exists():
                cible.unlink()
            (anc / nom).rename(cible)
    (r / A_CONFIRMER).unlink(missing_ok=True)
    shutil.rmtree(anc, ignore_errors=True)
    return True


def confirmer() -> str:
    """Appelé quand la fenêtre est bien ouverte : la nouvelle version est validée.
    Renvoie la version qui vient d'être installée ('' s'il n'y en avait pas)."""
    f = racine() / A_CONFIRMER
    if not f.is_file():
        return ""
    v = f.read_text(encoding="utf-8").strip()
    f.unlink(missing_ok=True)
    shutil.rmtree(racine() / ANCIENNE, ignore_errors=True)
    return v
