"""Onglet « Relevé des quantités » : listes de produits du catalogue → fiche A4 à remplir au stylo."""
from __future__ import annotations

from datetime import datetime

from PySide6.QtCore import QSize, Qt, QTimer, QUrl
from PySide6.QtGui import QDesktopServices, QIcon, QPixmap
from PySide6.QtWidgets import (QAbstractItemView, QButtonGroup, QCheckBox, QDialog, QDialogButtonBox, QHBoxLayout,
                               QHeaderView, QLabel, QLineEdit, QListWidget, QListWidgetItem, QMenu, QMessageBox,
                               QPushButton, QScrollArea, QSpinBox, QTableWidget, QTableWidgetItem, QVBoxLayout,
                               QWidget)

from .. import paths, releve
from ..paths import retrouver_photo

TAILLE_PHOTO = 54


class _NouvelleListe(QDialog):
    """Nom de la liste + rayons du catalogue où prendre les produits."""

    def __init__(self, parent):
        super().__init__(parent)
        from ..hors_ligne import GROUPES
        self.setWindowTitle("➕ Nouvelle liste")
        v = QVBoxLayout(self)
        v.addWidget(QLabel("Nom de la liste :"))
        self.nom = QLineEdit()
        self.nom.setPlaceholderText("ex. Cartes mémoire, Clés USB…")
        v.addWidget(self.nom)
        v.addWidget(QLabel("Produits pris dans :"))
        self.cases = {}
        for cle, lib, rayons in GROUPES:
            c = QCheckBox(lib.replace(",\n", ", "))
            v.addWidget(c)
            self.cases[cle] = (c, rayons)
        b = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        b.button(QDialogButtonBox.StandardButton.Ok).setText("Créer la liste")
        b.button(QDialogButtonBox.StandardButton.Cancel).setText("Annuler")
        b.accepted.connect(self._ok)
        b.rejected.connect(self.reject)
        v.addWidget(b)

    def _ok(self):
        if not self.nom.text().strip() or not self.rayons():
            QMessageBox.warning(self, "Nouvelle liste", "Donne un nom à la liste\net coche au moins un rayon.")
            return
        self.accept()

    def rayons(self) -> list[str]:
        return [r for c, rs in self.cases.values() if c.isChecked() for r in rs]


class OngletReleve(QWidget):
    def __init__(self, fenetre):
        super().__init__()
        self.fenetre = fenetre
        self.cat = fenetre.cat
        self.donnees = releve.charger_listes()
        self.catalogue: list[dict] = []
        self.produits: list[dict] = []          # produits de la liste choisie
        self.filtre = ""                         # sous-catégorie (chip), '' = tout
        self._icones: dict[str, QIcon | None] = {}
        self.doc = None
        self._minuterie = QTimer(self, singleShot=True, interval=350)
        self._minuterie.timeout.connect(self._apercu)

        racine = QHBoxLayout(self)
        racine.setContentsMargins(22, 18, 22, 18)
        racine.setSpacing(16)

        # gauche : « Ma sélection » (ce qui sera imprimé) ; les listes passent en pastilles au milieu
        g = QVBoxLayout()
        self.t_selection = QLabel("✔ Ma sélection")
        self.t_selection.setObjectName("etiquette")
        g.addWidget(self.t_selection)
        self.l_listes = QListWidget()
        self.l_listes.setStyleSheet("QListWidget::item { padding: 9px 6px; }")
        self.l_listes.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.l_listes.customContextMenuRequested.connect(self._menu_liste)
        self.l_listes.currentRowChanged.connect(self._liste_choisie)
        self.l_listes.hide()
        g.addWidget(self._panneau_selection(), 1)
        gw = QWidget()
        gw.setLayout(g)
        gw.setFixedWidth(430)
        racine.addWidget(gw)

        # milieu : produits
        m = QVBoxLayout()
        # listes de relevé : en pastilles, tout en haut
        hl = QHBoxLayout()
        hl.setSpacing(8)
        tl = QLabel("📋 Listes :")
        tl.setObjectName("etiquette")
        hl.addWidget(tl)
        self.w_listes = QHBoxLayout()
        self.w_listes.setSpacing(8)
        hl.addLayout(self.w_listes)
        self.b_new = QPushButton("＋ Nouvelle liste")
        self.b_new.setObjectName("chip")
        self.b_new.setStyleSheet("QPushButton { color: #E68A00; border: 1px dashed #E68A00; }")
        self.b_new.setCursor(Qt.CursorShape.PointingHandCursor)
        self.b_new.clicked.connect(self.nouvelle_liste)
        hl.addWidget(self.b_new)
        hl.addStretch()
        m.addLayout(hl)
        self.groupe_listes = QButtonGroup(self)
        self.groupe_listes.setExclusive(True)
        self.titre = QLabel("")
        self.titre.setObjectName("etiquette")
        m.addWidget(self.titre)
        self.recherche = QLineEdit()
        self.recherche.setPlaceholderText("🔎 Un mot : 128, Edenwood, Samsung…")
        self.recherche.textChanged.connect(lambda _: self._remplir())
        m.addWidget(self.recherche)
        self.chips = QHBoxLayout()
        self.chips.setSpacing(6)
        self.groupe_chips = QButtonGroup(self)
        self.groupe_chips.setExclusive(True)
        self.chips.setContentsMargins(0, 0, 0, 0)
        self.w_chips = QWidget()
        self.w_chips.setObjectName("chips")
        self.w_chips.setStyleSheet("QWidget#chips { background: transparent; border: none; }")
        self.w_chips.setLayout(self.chips)
        m.addWidget(self.w_chips)
        ht = QHBoxLayout()
        self.b_tout = QPushButton("✖  Tout décocher")         # un seul bouton, qui alterne
        self.b_tout.setMinimumWidth(170)
        self.b_tout.clicked.connect(lambda: self._tout(not self._coches_visibles()))
        ht.addWidget(self.b_tout)
        ht.addStretch()
        m.addLayout(ht)
        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["✔", "Photo", "Réf.", "Produit"])
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(TAILLE_PHOTO + 8)
        self.table.setIconSize(QSize(TAILLE_PHOTO, TAILLE_PHOTO))
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setShowGrid(False)
        h = self.table.horizontalHeader()
        for col, larg in ((0, 40), (1, TAILLE_PHOTO + 16), (2, 100)):
            h.setSectionResizeMode(col, QHeaderView.ResizeMode.Fixed)
            self.table.setColumnWidth(col, larg)
        h.setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        self.table.cellClicked.connect(self._clic)
        self.table.itemChanged.connect(self._coche_changee)
        m.addWidget(self.table, 1)
        racine.addLayout(m, 1)

        # droite : impression
        d = QVBoxLayout()
        t = QLabel("🖨️ Impression")
        t.setObjectName("etiquette")
        d.addWidget(t)
        modes = QHBoxLayout()
        self.groupe_modes = QButtonGroup(self)
        for cle, lib in (("compact", "Compact"), ("standard", "Standard"), ("illustre", "Illustré")):
            b = QPushButton(lib)
            b.setCheckable(True)
            b.setProperty("mode", cle)
            b.setObjectName("mode")
            self.groupe_modes.addButton(b)
            modes.addWidget(b)
        self.groupe_modes.buttonClicked.connect(lambda _: self._options_changees())
        d.addLayout(modes)
        o1 = QHBoxLayout()
        self.c_codes = QCheckBox("Codes-barres")
        self.c_photos = QCheckBox("Photos")
        self.c_nb = QCheckBox("Noir et blanc")
        for c in (self.c_codes, self.c_photos, self.c_nb):
            o1.addWidget(c)
            c.toggled.connect(lambda _: self._options_changees())
        d.addLayout(o1)
        o2 = QHBoxLayout()
        self.c_paysage = QCheckBox("Paysage")
        self.c_paysage.toggled.connect(lambda _: self._options_changees())
        o2.addWidget(self.c_paysage)
        o2.addWidget(QLabel("Hauteur des lignes :"))
        self.s_haut = QSpinBox()
        self.s_haut.setRange(0, 40)
        self.s_haut.setSuffix(" mm")
        self.s_haut.setSpecialValueText("auto")
        self.s_haut.valueChanged.connect(lambda _: self._options_changees())
        o2.addWidget(self.s_haut)
        o2.addStretch()
        d.addLayout(o2)
        o3 = QHBoxLayout()
        o3.addWidget(QLabel("Employé :"))
        self.e_employe = QLineEdit()
        self.e_employe.setPlaceholderText("(facultatif)")
        self.e_employe.textChanged.connect(lambda _: self._options_changees())
        o3.addWidget(self.e_employe)
        d.addLayout(o3)
        from .apercu_feuilles import ZoneApercu
        self.zone_apercu = ZoneApercu(self._apercu)          # toutes les pages, à la largeur du panneau
        self.l_apercu = self.zone_apercu.label
        d.addWidget(self.zone_apercu, 1)
        self.l_pages = QLabel("")
        self.l_pages.setObjectName("petit")
        d.addWidget(self.l_pages)
        b_pdf = QPushButton("📄  EXPORTER EN PDF")
        b_pdf.clicked.connect(self.exporter)
        d.addWidget(b_pdf)
        self.b_imp = QPushButton("🖨️  IMPRIMER LE RELEVÉ")
        self.b_imp.setObjectName("energie")
        self.b_imp.setMinimumHeight(48)
        self.b_imp.clicked.connect(self.imprimer)
        d.addWidget(self.b_imp)
        dw = QWidget()
        dw.setLayout(d)
        dw.setFixedWidth(360)
        racine.addWidget(dw)

        self._poser_options()
        self.charger()

    # -- données ----------------------------------------------------------------------------------
    def charger(self) -> None:
        """(Re)lit le catalogue : après une mise à jour, les listes gardent leurs cases."""
        try:
            self.catalogue = self.cat.base.catalogue_complet()
        except Exception:
            self.catalogue = []
        ligne = max(0, self.l_listes.currentRow())
        self.l_listes.blockSignals(True)
        self.l_listes.clear()
        for li in self.donnees["listes"]:
            self.l_listes.addItem(QListWidgetItem(f"{li.get('emoji') or '📋'}  {li['nom']}"))
        self.l_listes.blockSignals(False)
        self._pastilles_listes(min(ligne, max(0, len(self.donnees["listes"]) - 1)))
        if self.donnees["listes"]:
            self.l_listes.setCurrentRow(min(ligne, len(self.donnees["listes"]) - 1))
            self._liste_choisie(self.l_listes.currentRow())

    def _pastilles_listes(self, actuelle: int) -> None:
        while self.w_listes.count():
            it = self.w_listes.takeAt(0)
            if it.widget():
                self.groupe_listes.removeButton(it.widget())
                it.widget().hide()
                it.widget().deleteLater()
        for r, li in enumerate(self.donnees["listes"]):
            b = QPushButton(f"{li.get('emoji') or '📋'} {li['nom']}")
            b.setObjectName("chip")
            b.setCheckable(True)
            b.setChecked(r == actuelle)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.setToolTip("Clic droit : supprimer la liste")
            b.clicked.connect(lambda _=False, k=r: self.l_listes.setCurrentRow(k))
            b.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
            b.customContextMenuRequested.connect(lambda pos, k=r, bb=b: self._supprimer_liste(k, bb.mapToGlobal(pos)))
            self.groupe_listes.addButton(b)
            self.w_listes.addWidget(b)

    def _supprimer_liste(self, r: int, pos_globale) -> None:
        menu = QMenu(self)
        a_sup = menu.addAction("🗑️  Supprimer cette liste")
        if menu.exec(pos_globale) is a_sup:
            nom = self.donnees["listes"][r]["nom"]
            if QMessageBox.question(self, "Supprimer la liste",
                                    f"Supprimer la liste « {nom} » ?\n"
                                    "Les produits restent dans le catalogue.") == QMessageBox.StandardButton.Yes:
                del self.donnees["listes"][r]
                self._sauver()
                self.charger()

    # -- « Ma sélection » à gauche : ce qui sera imprimé ------------------------------------------
    def _panneau_selection(self) -> QWidget:
        from PySide6.QtWidgets import QFrame
        cadre = QFrame()
        cadre.setObjectName("selection")
        cadre.setStyleSheet("QFrame#selection { background: white; border: 1px solid #D5DBE3; border-radius: 8px; }")
        v = QVBoxLayout(cadre)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)
        zone = QScrollArea()
        zone.setWidgetResizable(True)
        zone.setFrameShape(QFrame.Shape.NoFrame)
        zone.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.w_sel = QWidget()
        self.w_sel.setObjectName("selInterne")
        self.w_sel.setStyleSheet("QWidget#selInterne { background: white; }")
        self.v_sel = QVBoxLayout(self.w_sel)
        self.v_sel.setContentsMargins(0, 0, 0, 0)
        self.v_sel.setSpacing(6)                      # un espace blanc entre deux produits
        self.v_sel.addStretch(1)
        zone.setWidget(self.w_sel)
        v.addWidget(zone, 1)
        bas = QHBoxLayout()
        bas.setContentsMargins(10, 8, 10, 10)
        self.b_retirer = QPushButton("✖  Tout retirer")
        self.b_retirer.clicked.connect(lambda: self._tout_liste(False))
        bas.addStretch()
        bas.addWidget(self.b_retirer)
        bas.addStretch()
        v.addLayout(bas)
        return cadre

    def _ligne_selection(self, a: dict) -> QWidget:
        import html
        from PySide6.QtGui import QFont, QFontMetrics
        from PySide6.QtWidgets import QFrame, QSizePolicy
        from .parcourir import _CodeBarres, deux_lignes
        w = QFrame()
        w.setObjectName("ligneSel")
        w.setStyleSheet("QFrame#ligneSel { background: white; border: none; border-bottom: 2px solid #C9D3DE; }")
        h = QHBoxLayout(w)
        h.setContentsMargins(10, 6, 6, 6)
        h.setSpacing(8)
        ph = QLabel()
        ic = self._icone(a)
        if ic is not None:
            ph.setPixmap(ic.pixmap(QSize(28, 38)))
        ph.setFixedSize(30, 40)
        ph.setAlignment(Qt.AlignmentFlag.AlignCenter)
        ph.setStyleSheet("background: transparent;")
        h.addWidget(ph)
        t = QLabel()
        t.setStyleSheet("background: transparent;")
        t.ensurePolished()
        fb = QFont(t.font())
        fb.setBold(True)
        mfb = QFontMetrics(fb)
        lignes, reste = [], a["nom"].split()
        while reste:                                   # le nom entier, jamais un mot seul en fin
            l = deux_lignes(" ".join(reste), mfb.horizontalAdvance, 190)
            lignes.append(l[0])
            if len(l) == 1:
                break
            reste = l[1].split()
        sc = releve.sous_categorie(a["nom"], a.get("rayon", ""))
        t.setText("<b>" + "<br>".join(html.escape(x) for x in lignes) + "</b>"
                  + (f"<br><span style='color:#6B7380; font-size:9pt'>{html.escape(sc)}</span>" if sc else ""))
        t.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        t.setMinimumWidth(1)
        h.addWidget(t, 1)
        h.addWidget(_CodeBarres(a["code"]), 0, Qt.AlignmentFlag.AlignVCenter)
        x = QPushButton("✕")
        x.setFixedSize(26, 26)
        x.setStyleSheet("QPushButton { border: none; padding: 0; min-width: 26px; max-width: 26px; color: #8A93A0;"
                        " font-size: 12pt; background: transparent; } QPushButton:hover { color: #D32F2F; }")
        x.setToolTip("Retirer de la sélection")
        x.clicked.connect(lambda _=False, c=a["code"]: QTimer.singleShot(0, lambda: self._retirer(c)))
        h.addWidget(x, 0, Qt.AlignmentFlag.AlignTop)
        return w

    def _retirer(self, code: str) -> None:
        self._poser_sel(self._sel() - {code})
        self._remplir()

    def _tout_liste(self, coche: bool) -> None:
        """« Tout retirer » : vide toute la sélection (toutes les catégories de la liste)."""
        self._poser_sel(self._sel() | {a["code"] for a in self.produits} if coche else set())
        self._remplir()

    def _maj_selection(self) -> None:
        if not hasattr(self, "v_sel"):
            return
        while self.v_sel.count() > 1:
            it = self.v_sel.takeAt(0)
            if it.widget() is not None:
                it.widget().hide()
                it.widget().deleteLater()
        paires = self._selection_par_liste()
        sel = [a for _, a in paires]
        plusieurs = len({id(li) for li, _ in paires}) > 1
        derniere = None
        for li, a in paires[:150]:
            if plusieurs and li is not derniere:            # petit titre : de quelle liste viennent les produits
                t = QLabel(f"{li.get('emoji') or '📋'} {li['nom'].upper()}")
                t.setStyleSheet("color: #8A93A0; font-weight: 700; font-size: 9pt; padding: 8px 12px 2px 12px;"
                                " background: transparent;")
                self.v_sel.insertWidget(self.v_sel.count() - 1, t)
                derniere = li
            self.v_sel.insertWidget(self.v_sel.count() - 1, self._ligne_selection(a))
        if len(sel) > 150:
            l = QLabel(f"… et {len(sel) - 150} autres")
            l.setObjectName("petit")
            l.setContentsMargins(12, 8, 12, 8)
            self.v_sel.insertWidget(self.v_sel.count() - 1, l)
        if not sel:
            l = QLabel("Coche des produits :\nils apparaissent ici.")
            l.setAlignment(Qt.AlignmentFlag.AlignCenter)
            l.setStyleSheet("color: #8A93A0; padding: 30px 10px; background: transparent;")
            self.v_sel.insertWidget(0, l)
        self.t_selection.setText(f"✔ Ma sélection · {len(sel)}" if sel else "✔ Ma sélection")
        self.b_retirer.setEnabled(bool(sel))

    def _sel(self) -> set:
        return set(self.donnees.get("selection") or [])

    def _poser_sel(self, codes: set) -> None:
        self.donnees["selection"] = sorted(codes)
        self._sauver()

    def _selection_par_liste(self) -> list[tuple[dict, dict]]:
        """(liste, produit) cochés, toutes listes confondues : rangés par liste puis dans l'ordre du rayon."""
        sel, vus, res = self._sel(), set(), []
        if not sel:
            return res
        for li in self.donnees["listes"]:
            for a in releve.produits_de(li, self.catalogue):
                if a["code"] in sel and a["code"] not in vus:
                    res.append((li, a))
                    vus.add(a["code"])
        return res

    def _liste(self) -> dict | None:
        r = self.l_listes.currentRow()
        return self.donnees["listes"][r] if 0 <= r < len(self.donnees["listes"]) else None

    def _sauver(self) -> None:
        try:
            releve.enregistrer_listes(self.donnees)
        except OSError:
            pass

    def _liste_choisie(self, _r: int) -> None:
        for k, b in enumerate(self.groupe_listes.buttons()):
            b.setChecked(k == self.l_listes.currentRow())
        li = self._liste()
        self.produits = releve.produits_de(li, self.catalogue) if li else []
        self.filtre = ""
        self._chips()
        self._remplir()

    def _chips(self) -> None:
        """Catégories en haut (Stockage : HDD, SSD interne…) ; rien pour une liste sans sous-catégorie."""
        while self.chips.count():
            it = self.chips.takeAt(0)
            if it.widget():
                self.groupe_chips.removeButton(it.widget())
                it.widget().deleteLater()
        presentes = {releve.sous_categorie(a["nom"], a.get("rayon", "")) for a in self.produits} - {""}
        self.w_chips.setVisible(bool(presentes))
        if not presentes:
            return
        rayon = self.produits[0].get("rayon", "") if self.produits else ""
        for sc in [""] + [c for c in releve.categories(rayon, self.produits)
                         if rayon not in ("accessoires_apple", *releve.PAR_MARQUE) or c in presentes]:
            b = QPushButton(sc or "Tout")
            b.setCheckable(True)
            b.setChecked(sc == self.filtre)
            b.setObjectName("chip")
            b.clicked.connect(lambda _=False, v=sc: self._choisir_chip(v))
            self.groupe_chips.addButton(b)
            self.chips.addWidget(b)
        self.chips.addStretch()

    def _choisir_chip(self, sc: str) -> None:
        self.filtre = sc
        for b in self.groupe_chips.buttons():
            b.setChecked(b.text() == (sc or "Tout"))
        self._remplir()

    def visibles(self) -> list[dict]:
        mots = self.recherche.text().lower().split()
        res = []
        for a in self.produits:
            if self.filtre and releve.sous_categorie(a["nom"], a.get("rayon", "")) != self.filtre:
                continue
            texte = f"{a['code']} {a['nom']}".lower()
            if all(m in texte for m in mots):
                res.append(a)
        return res

    def _icone(self, a: dict):
        code = a["code"]
        if code not in self._icones:
            ic = None
            f = retrouver_photo(a.get("photo") or "")
            if f:
                from PySide6.QtGui import QImageReader
                lecteur = QImageReader(f)
                taille = lecteur.size()
                if taille.isValid() and max(taille.width(), taille.height()) > 0:
                    lecteur.setScaledSize(taille * (TAILLE_PHOTO * 2 / max(taille.width(), taille.height())))
                img = lecteur.read()
                if not img.isNull():
                    ic = QIcon(QPixmap.fromImage(img))
            self._icones[code] = ic
        return self._icones[code]

    def _remplir(self) -> None:
        sel = self._sel()
        vis = self.visibles()
        self.table.blockSignals(True)
        self.table.setUpdatesEnabled(False)
        self.table.setRowCount(len(vis))
        for r, a in enumerate(vis):
            c = QTableWidgetItem()
            c.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled)
            c.setCheckState(Qt.CheckState.Checked if a["code"] in sel else Qt.CheckState.Unchecked)
            c.setData(Qt.ItemDataRole.UserRole, a["code"])
            self.table.setItem(r, 0, c)
            p = QTableWidgetItem()
            ic = self._icone(a)
            if ic is not None:
                p.setIcon(ic)
            self.table.setItem(r, 1, p)
            self.table.setItem(r, 2, QTableWidgetItem(a["code"]))
            self.table.setItem(r, 3, QTableWidgetItem(a["nom"]))
            self._teinte(r, a["code"] in sel)
        self.table.setUpdatesEnabled(True)
        self.table.blockSignals(False)
        self._maj_titre()
        self._minuterie.start()

    def _maj_titre(self) -> None:
        li = self._liste()
        if not li:
            self.titre.setText("")
            return
        n = len(self.produits)
        k = len(self._a_imprimer())
        if hasattr(self, "b_tout"):
            self.b_tout.setText("✖  Tout décocher" if self._coches_visibles() else "☑️  Tout cocher")
        self._maj_selection()
        if not n:
            self.titre.setText(f"{li.get('emoji') or '📋'} {li['nom']} · aucun produit\n"
                               "(fais la mise à jour du catalogue avec ce rayon coché)")
        else:
            self.titre.setText(f"{li.get('emoji') or '📋'} {li['nom']} · {n} produit{'s' if n > 1 else ''}"
                               f" · ✔ {k} à imprimer")

    def _clic(self, rang: int, col: int) -> None:
        if col == 0:
            return
        it = self.table.item(rang, 0)
        if it is not None:
            it.setCheckState(Qt.CheckState.Unchecked if it.checkState() == Qt.CheckState.Checked
                             else Qt.CheckState.Checked)

    def _coche_changee(self, it) -> None:
        li = self._liste()
        if it.column() != 0 or li is None:
            return
        code = it.data(Qt.ItemDataRole.UserRole)
        sel = self._sel()
        if it.checkState() == Qt.CheckState.Checked:
            sel.add(code)
        else:
            sel.discard(code)
        self._poser_sel(sel)
        self._teinte(it.row(), it.checkState() == Qt.CheckState.Checked)
        self._maj_titre()
        self._minuterie.start()

    def _teinte(self, r: int, coche: bool) -> None:
        """Ligne cochée : bleu clair (comme dans « Parcourir »)."""
        from PySide6.QtGui import QBrush, QColor
        self.table.blockSignals(True)
        for col in range(4):
            it = self.table.item(r, col)
            if it is not None:
                it.setBackground(QColor("#EAF3FD") if coche else QBrush())
        self.table.blockSignals(False)

    def _tout(self, coche: bool) -> None:
        codes = {a["code"] for a in self.visibles()}
        self._poser_sel(self._sel() | codes if coche else self._sel() - codes)
        self._remplir()

    # -- listes -----------------------------------------------------------------------------------
    def nouvelle_liste(self) -> None:
        dlg = _NouvelleListe(self)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        rayons = dlg.rayons()
        emoji = "💾" if rayons == ["stockage"] else ("☎️" if rayons == ["mobiles"] else
                                                   ("🍎" if rayons == ["accessoires_apple"] else
                                                    {"passerelles": "📺", "videoprojecteurs": "📽"}.get(rayons[0] if len(rayons) == 1 else "", "📋")))
        self.donnees["listes"].append({"nom": dlg.nom.text().strip(), "emoji": emoji, "rayons": rayons,
                                       "decoches": []})
        self._sauver()
        self.charger()
        self.l_listes.setCurrentRow(len(self.donnees["listes"]) - 1)

    def _menu_liste(self, pos) -> None:
        r = self.l_listes.indexAt(pos).row()
        if r < 0:
            return
        menu = QMenu(self)
        a_sup = menu.addAction("🗑️  Supprimer cette liste")
        if menu.exec(self.l_listes.mapToGlobal(pos)) is a_sup:
            nom = self.donnees["listes"][r]["nom"]
            if QMessageBox.question(self, "Supprimer la liste",
                                    f"Supprimer la liste « {nom} » ?\n"
                                    "Les produits restent dans le catalogue.") == QMessageBox.StandardButton.Yes:
                del self.donnees["listes"][r]
                self._sauver()
                self.charger()

    # -- impression -------------------------------------------------------------------------------
    def _poser_options(self) -> None:
        o = self.donnees["options"]
        for b in self.groupe_modes.buttons():
            b.setChecked(b.property("mode") == o["mode"])
        for c, cle in ((self.c_codes, "codes_barres"), (self.c_photos, "photos"), (self.c_nb, "noir_blanc"),
                       (self.c_paysage, "paysage")):
            c.blockSignals(True)
            c.setChecked(bool(o[cle]))
            c.blockSignals(False)
        self.s_haut.blockSignals(True)
        self.s_haut.setValue(int(o["hauteur_mm"] or 0))
        self.s_haut.blockSignals(False)
        self.e_employe.setText(o.get("employe") or "")
        self.c_photos.setEnabled(o["mode"] == "illustre")

    def _options_changees(self) -> None:
        o = self.donnees["options"]
        b = self.groupe_modes.checkedButton()
        o["mode"] = b.property("mode") if b else "illustre"
        o["codes_barres"] = self.c_codes.isChecked()
        o["photos"] = self.c_photos.isChecked()
        o["noir_blanc"] = self.c_nb.isChecked()
        o["paysage"] = self.c_paysage.isChecked()
        o["hauteur_mm"] = self.s_haut.value()
        o["employe"] = self.e_employe.text().strip()
        self.c_photos.setEnabled(o["mode"] == "illustre")
        self._sauver()
        self._minuterie.start()

    def _a_imprimer(self) -> list[dict]:
        """Toute la sélection (toutes les listes), rangée par liste puis dans l'ordre du rayon."""
        return [a for _, a in self._selection_par_liste()]

    def _coches_visibles(self) -> list[dict]:
        sel = self._sel()
        return [a for a in self.visibles() if a["code"] in sel]

    def _document(self):
        o = self.donnees["options"]
        paires = self._selection_par_liste()
        listes = []
        for li_, _ in paires:
            if li_["nom"] not in listes:
                listes.append(li_["nom"])
        plusieurs = len(listes) > 1
        lignes = []
        for li_, a in paires:
            sc = releve.sous_categorie(a["nom"], a.get("rayon", ""))
            section = (li_["nom"] + (f" · {sc}" if sc else "")) if plusieurs else sc
            lignes.append(releve.Ligne(a["code"], a["nom"], retrouver_photo(a.get("photo") or ""), section))
        if not lignes:
            return None
        titre = " + ".join(listes)
        opt = releve.Options(mode=o["mode"], paysage=o["paysage"], photos=o["photos"],
                             codes_barres=o["codes_barres"], noir_blanc=o["noir_blanc"],
                             hauteur_mm=float(o["hauteur_mm"] or 0), titre=titre, employe=o.get("employe") or "")
        return releve.creer_pdf(lignes, opt)

    def _apercu(self) -> None:
        try:
            self.doc = self._document()
        except Exception as e:                       # jamais de plantage pour un aperçu
            self.doc = None
            self.zone_apercu.texte(f"Aperçu impossible :\n{e}")
            return
        if self.doc is None:
            self.zone_apercu.texte("\nCoche au moins un produit.")
            self.l_pages.setText("")
            self.b_imp.setEnabled(False)
            return
        try:
            self.zone_apercu.montrer(self.doc)
        except Exception as e:
            self.zone_apercu.texte(f"Aperçu impossible :\n{e}")
            return
        n = self.doc.page_count
        self.l_pages.setText(f"{n} page{'s' if n > 1 else ''} A4")
        self.b_imp.setEnabled(True)

    def exporter(self) -> None:
        self._apercu()
        if self.doc is None:
            return
        li = self._liste()
        nom = "Releve_" + "".join(ch if ch.isalnum() else "_" for ch in li["nom"]) + \
              datetime.now().strftime("_%Y-%m-%d_%Hh%M")
        dest = paths.output_dir() / f"{nom}.pdf"
        try:
            dest.parent.mkdir(parents=True, exist_ok=True)
            self.doc.save(dest)
        except (PermissionError, OSError) as e:
            QMessageBox.warning(self, "PDF", f"Impossible d'enregistrer le PDF :\n{e}")
            return
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(dest)))

    def imprimer(self) -> None:
        self._apercu()
        if self.doc is None:
            return
        from . import impression
        try:
            impression.imprimer(self, self.doc, "Relevé des quantités")
        except Exception as e:
            QMessageBox.critical(self, "Impression impossible", str(e))
