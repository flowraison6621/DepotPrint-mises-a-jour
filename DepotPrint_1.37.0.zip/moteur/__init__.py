"""Dépôt Print — générateur d'affiches rayon Electro Dépôt (smartphones, tablettes)."""

APP_NAME = "Dépôt Print"
APP_VERSION = "1.37.0"
