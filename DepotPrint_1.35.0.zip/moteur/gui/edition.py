"""Fenêtre « Modifier » : nom, photo et cadrage, avec aperçu immédiat de l'affiche."""

from __future__ import annotations

from dataclasses import replace

import copy
import os
import re
from pathlib import Path

from PySide6.QtCore import QPoint, QRect, QSize, Qt, QTimer
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFileDialog, QFrame, QGridLayout, QHBoxLayout, QLabel,
    QLayout, QLineEdit, QMessageBox, QPushButton, QSlider, QVBoxLayout, QWidget,
)

from .. import affiche, images
from ..catalogue import Catalogue
from ..models import Cadrage, Mentions, Produit
from ..noms import nom_court
from ..reglages import charger_grille, tarif_pour_prix, texte_tarif
from . import taches

ETATS = ["EXCELLENT ÉTAT", "ÉTAT CORRECT"]          # les deux états utilisés par le site
FILTRE_IMAGES = "Images (*.png *.jpg *.jpeg *.webp *.avif *.bmp *.tif *.tiff)"


class _Flux(QLayout):
    """Disposition « en ligne » : les éléments se suivent et passent à la ligne s'il manque de place."""

    def __init__(self, parent=None, ecart_h: int = 12, ecart_v: int = 4):
        super().__init__(parent)
        self._items, self._h, self._v = [], ecart_h, ecart_v
        self.setContentsMargins(0, 0, 0, 0)

    def addItem(self, item): self._items.append(item)
    def count(self): return len(self._items)
    def itemAt(self, i): return self._items[i] if 0 <= i < len(self._items) else None
    def takeAt(self, i): return self._items.pop(i) if 0 <= i < len(self._items) else None
    def expandingDirections(self): return Qt.Orientation(0)
    def hasHeightForWidth(self): return True
    def heightForWidth(self, w): return self._placer(QRect(0, 0, w, 0), False)
    def setGeometry(self, r):
        super().setGeometry(r)
        self._placer(r, True)
    def sizeHint(self): return self.minimumSize()
    def minimumSize(self):
        t = QSize()
        for it in self._items:
            t = t.expandedTo(it.minimumSize())
        return t

    def _placer(self, r, appliquer: bool) -> int:
        x, y, haut = r.x(), r.y(), 0
        for it in self._items:
            sh = it.sizeHint()
            if x + sh.width() > r.right() + 1 and haut > 0:
                x, y, haut = r.x(), y + haut + self._v, 0
            if appliquer:
                it.setGeometry(QRect(QPoint(x, y), sh))
            x += sh.width() + self._h
            haut = max(haut, sh.height())
        return y + haut - r.y()


def _pastille(hexa: str):
    """Petit rond de la couleur, à côté du nom (contour gris pour les couleurs claires)."""
    from PySide6.QtGui import QColor, QIcon, QPainter, QPen
    pm = QPixmap(28, 28)
    pm.fill(Qt.GlobalColor.transparent)
    pt = QPainter(pm)
    pt.setRenderHint(QPainter.RenderHint.Antialiasing)
    c = QColor(hexa)
    pt.setPen(QPen(QColor("#8A8F98"), 2) if c.lightness() > 215 else Qt.PenStyle.NoPen)
    pt.setBrush(c)
    pt.drawEllipse(3, 3, 22, 22)
    pt.end()
    return QIcon(pm)


def _etiquette(texte: str) -> QLabel:
    l = QLabel(texte)
    l.setObjectName("etiquette")
    return l


class FenetreEdition(QDialog):
    def __init__(self, parent: QWidget, catalogue: Catalogue, produit: Produit):
        super().__init__(parent)
        self.setWindowTitle(f"Modifier l'affiche — {produit.code}"
                            + (f" + {produit.version2.code}" if produit.version2 is not None else ""))
        self.cat = catalogue
        self.p = copy.deepcopy(produit)
        self._surligne = False          # aide à la sélection : seulement après un clic sur Version / Produit
        self._eprel: dict[str, str] = {}   # étiquette énergie choisie, par code : '' auto, 'site', n° EPREL
        self.c_eprel = None
        self.resize(1040, 720)

        racine = QHBoxLayout(self)
        racine.setSpacing(18)

        # Aperçu d'une affiche
        gauche = QVBoxLayout()
        gauche.addWidget(_etiquette("Aperçu (une affiche)"))
        self.apercu = QLabel()
        self.apercu.setObjectName("apercu")
        self.apercu.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.apercu.setMinimumSize(420, 520)
        self.apercu.installEventFilter(self)          # clic sur un téléphone = choisir sa version
        if self.p.version2 is not None:
            self.apercu.setCursor(Qt.CursorShape.PointingHandCursor)
            self.apercu.setToolTip("Cliquez sur un téléphone pour le modifier")
        gauche.addWidget(self.apercu, 1)
        racine.addLayout(gauche, 1)

        # Réglages : dans une zone qui défile (petits écrans), boutons toujours visibles en bas
        zone_droite = QWidget()
        zone_droite.setObjectName("zoneDroite")
        droite = QVBoxLayout(zone_droite)
        droite.setContentsMargins(0, 0, 8, 0)
        droite.setSpacing(10)
        carte = QFrame()
        carte.setObjectName("carte")
        cl = QVBoxLayout(carte)
        cl.setContentsMargins(16, 14, 16, 14)
        cl.addWidget(_etiquette("🏷️ Nom imprimé sur l'affiche"))
        self.champ_nom = QLineEdit(self.p.nom_affiche)
        self.champ_nom.setStyleSheet("font-size: 13pt; font-weight: 700;")
        # deux téléphones différents : un nom par produit (chacun imprimé sous son téléphone)
        from ..affiche import modeles_differents
        self.champ_nom2 = None
        self.leg_noms = []
        if self.p.version2 is not None and modeles_differents(self.p, self.p.version2):
            self.champ_nom2 = QLineEdit(self.p.version2.nom_affiche)
            self.champ_nom2.setStyleSheet("font-size: 13pt; font-weight: 700;")
            for k, ch in enumerate((self.champ_nom, self.champ_nom2)):
                hn = QHBoxLayout()
                lg = QLabel(f"Produit {k + 1}")
                lg.setFixedWidth(78)
                lg.setAlignment(Qt.AlignmentFlag.AlignCenter)
                lg.setStyleSheet("background:#1C1F24; color:white; font-weight:700; border-radius:4px; padding:3px 0;")
                self.leg_noms.append(lg)
                hn.addWidget(lg)
                hn.addWidget(ch, 1)
                cl.addLayout(hn)
        else:
            cl.addWidget(self.champ_nom)
        self.info_nom = QLabel()
        self.info_nom.setObjectName("petit")
        self.info_nom.setWordWrap(True)
        cl.addWidget(self.info_nom)
        ligne = QHBoxLayout()
        b_court = QPushButton("Nom court automatique")
        b_court.clicked.connect(self._nom_court)
        b_complet = QPushButton("Désignation complète")
        b_complet.clicked.connect(self._nom_complet)
        for b in (b_court, b_complet):
            b.setEnabled(bool(self.p.nom_site))
            ligne.addWidget(b)
        ligne.addStretch()
        cl.addLayout(ligne)
        self.c_code = QCheckBox("Afficher les codes produits sur l'affiche" if self.p.version2 is not None
                                else "Afficher le code produit sur l'affiche")
        self.c_code.setToolTip("« Réf. 10013681 » en petit, en bas de l'affiche")
        self.c_code.setChecked(self.p.mentions.afficher_code)
        cl.addWidget(self.c_code)
        self.l_designation = None
        if self.p.nom_site:
            ds = QLabel(self._texte_designation())
            self.l_designation = ds
            ds.setObjectName("petit")
            ds.setWordWrap(True)
            ds.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            cl.addWidget(ds)
        droite.addWidget(carte)

        # mentions : pour une affiche « deux versions », un sélecteur choisit la version modifiée
        carte_m = QFrame()
        carte_m.setObjectName("carte")
        self.v_mentions = QVBoxLayout(carte_m)
        self.v_mentions.setContentsMargins(16, 14, 16, 14)
        self.v_mentions.addWidget(_etiquette("📝 Mentions sur l'affiche"))
        self._versions = [self.p] + ([self.p.version2] if self.p.version2 is not None else [])
        self._v = 0
        self.zone_m: QWidget | None = None
        self.c_recond_commun = None
        from ..reglages import genre_deux_versions
        # deux neufs (4G / 5G) : pas d'onglets, les couleurs 4G et 5G sont déjà rangées par réseau
        # (seulement le MÊME téléphone en 4G et en 5G : deux téléphones différents ont chacun leur onglet)
        from ..affiche import _reseau, modeles_differents
        # plus de mode particulier 4G + 5G : mêmes menus que pour deux produits, onglets « Version 1 / 2 »
        self._mode_reseau = False
        meme_recond = len(self._versions) == 2 and (self._versions[0].mentions.reconditionne
                                                     == self._versions[1].mentions.reconditionne)
        # même modèle (ex. deux iPhone 15) : « Reconditionné » commun, bandeau en haut comme avant ;
        # deux téléphones différents : une case par version (onglet Version 1 / Version 2)
        from ..affiche import modeles_differents
        meme_recond = False                            # « Reconditionné » : toujours une case par téléphone
        if len(self._versions) == 2 and not self._mode_reseau:
            self.c_recond_commun = QCheckBox("♻️ Reconditionné") if meme_recond else None
        if self.c_recond_commun is not None:
            self.c_recond_commun.setToolTip("Commun aux deux versions")
            self.c_recond_commun.setChecked(all(v.mentions.reconditionne for v in self._versions))
            self.c_recond_commun.toggled.connect(self._recond_commun)
            self.c_recond_commun.hide()                # montrée à la même place que pour un produit seul
        if len(self._versions) == 2 and not self._mode_reseau:
            sel = QHBoxLayout()
            sel.setSpacing(0)
            self.b_versions = []
            for k, v in enumerate(self._versions):
                b = QPushButton(_nom_version(k, v, self._versions))
                b.setCheckable(True)
                b.setChecked(k == 0)
                b.setCursor(Qt.CursorShape.PointingHandCursor)
                b.setStyleSheet(
                    "QPushButton { border: 1px solid #C9CDD4; padding: 5px 16px; font-weight: 700; text-align: center;"
                    f"border-radius: 0; {'border-top-left-radius:6px;border-bottom-left-radius:6px;' if k == 0 else 'border-top-right-radius:6px;border-bottom-right-radius:6px;'} }}"
                    "QPushButton:checked { background: #FF9900; border-color: #E68A00; color: #1C1F24; }")
                b.clicked.connect(lambda _=False, k=k: self._cliquer_version(k))
                sel.addWidget(b)
                self.b_versions.append(b)
            sel.addSpacing(12)
            sel.addWidget(self._bouton_inverser())
            sel.addStretch()
            self.v_mentions.addLayout(sel)
            aide_v = QLabel(("Nom, boîte et « Reconditionné » : communs aux deux versions.\n"
                             "État, batterie, couleurs, protection et photo : propres à chaque version.")
                            if meme_recond else
                            ("Boîte : commune aux deux produits.\n"
                             "Nom, reconditionné, état, batterie, couleurs, protection et photo :\n"
                             "propres à chaque produit.") if modeles_differents(*self._versions) else
                            ("Nom et boîte : communs aux deux versions.\n"
                             "Reconditionné, état, batterie, couleurs, protection et photo :\n"
                             "propres à chaque version."))
            aide_v.setObjectName("petit")
            self.v_mentions.addWidget(aide_v)
        if self._mode_reseau:                          # 4G + 5G : pas d'onglets, le bouton seul
            ligne_inv = QHBoxLayout()
            ligne_inv.addWidget(self._bouton_inverser())
            ligne_inv.addStretch()
            self.v_mentions.addLayout(ligne_inv)
        self._construire_mentions(self._versions[0])
        if self._mode_reseau:
            self._completer_reseau()
        droite.addWidget(carte_m)
        mm = self.p.mentions

        # contenu de la boîte : pictogrammes en orange = inclus dans la boîte
        from ..boite import NOMS
        carte_b = QFrame()
        carte_b.setObjectName("carte")
        cb = QGridLayout(carte_b)
        cb.setContentsMargins(16, 14, 16, 14)
        cb.addWidget(_etiquette("📦 Dans la boîte"), 0, 0, 1, 5)
        self.c_boite = []
        for k, n in enumerate(NOMS):
            c = QCheckBox(n)
            c.setChecked(k in (mm.boite or []))
            c.toggled.connect(lambda _: self._minuteur.start())
            cb.addWidget(c, 1, k)
            self.c_boite.append(c)
        self._boite_origine = sorted(mm.boite or [])
        if mm.boite_manuel:
            info_b = QLabel("Corrigé à la main")
        elif mm.reconditionne:
            info_b = QLabel("Reconditionné : câble seul par sécurité\n(les fiches du site ne sont pas fiables sur ce point)")
        elif mm.boite_indique:
            info_b = QLabel("D'après la fiche du site")
        else:
            info_b = QLabel("Contenu de la boîte non indiqué sur le site :\ncâble par défaut, à vérifier")
        info_b.setObjectName("petit")
        info_b.setWordWrap(True)
        cb.addWidget(info_b, 2, 0, 1, 5)
        o = QLabel("Orange sur l'affiche = inclus dans la boîte")
        o.setObjectName("petit")
        cb.addWidget(o, 3, 0, 1, 5)
        droite.addWidget(carte_b)

        carte2 = QFrame()
        carte2.setObjectName("carte")
        c2 = QVBoxLayout(carte2)
        c2.setContentsMargins(16, 14, 16, 14)
        c2.addWidget(_etiquette("📷 Photographie"))
        lb = QHBoxLayout()
        b_fichier = QPushButton("Choisir une photo sur l'ordinateur…")
        b_fichier.clicked.connect(self._photo_fichier)
        lb.addWidget(b_fichier)
        self.b_galerie = QPushButton("Autres photos du site…")
        self.b_galerie.setEnabled(bool(self.p.galerie))
        self.b_galerie.setToolTip("Photos de la fiche produit portant le même code article")
        self.b_galerie.clicked.connect(self._charger_galerie)
        lb.addWidget(self.b_galerie)
        lb.addStretch()
        c2.addLayout(lb)
        self.zone_galerie = QHBoxLayout()
        self.zone_galerie.setSpacing(6)
        c2.addLayout(self.zone_galerie)
        self.info_photo = QLabel("")
        self.info_photo.setObjectName("petit")
        self.info_photo.setWordWrap(True)
        c2.addWidget(self.info_photo)
        droite.addWidget(carte2)

        carte3 = QFrame()
        carte3.setObjectName("carte")
        g = QGridLayout(carte3)
        g.setContentsMargins(16, 14, 16, 14)
        g.addWidget(_etiquette("✂️ Cadrage de la photo"), 0, 0, 1, 3)
        self.s_zoom = self._curseur(50, 130, round(self.p.cadrage.zoom * 100))
        self.s_x = self._curseur(-100, 100, round(self.p.cadrage.decal_x * 100))
        self.s_y = self._curseur(-100, 100, round(self.p.cadrage.decal_y * 100))
        for i, (txt, s) in enumerate([("Taille", self.s_zoom), ("Gauche ↔ droite", self.s_x),
                                      ("Haut ↕ bas", self.s_y)], start=1):
            g.addWidget(QLabel(txt), i, 0)
            g.addWidget(s, i, 1)
        b_reinit = QPushButton("Réinitialiser le cadrage")
        b_reinit.clicked.connect(self._reinit_cadrage)
        g.addWidget(b_reinit, 4, 0, 1, 2, Qt.AlignmentFlag.AlignLeft)
        g.setColumnStretch(1, 1)
        droite.addWidget(carte3)
        droite.addStretch()

        boutons = QDialogButtonBox()
        ok = boutons.addButton("💾 Enregistrer", QDialogButtonBox.ButtonRole.AcceptRole)
        ok.setObjectName("principal")
        boutons.addButton("Annuler", QDialogButtonBox.ButtonRole.RejectRole)
        boutons.accepted.connect(self._valider)
        boutons.rejected.connect(self.reject)
        from PySide6.QtWidgets import QScrollArea
        defil = QScrollArea()
        defil.setWidgetResizable(True)
        defil.setFrameShape(QFrame.Shape.NoFrame)
        defil.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        defil.setStyleSheet("QScrollArea { background: transparent; } #zoneDroite { background: transparent; }")
        defil.setWidget(zone_droite)
        defil.setMinimumWidth(zone_droite.sizeHint().width() + 24)
        colonne = QVBoxLayout()
        colonne.addWidget(defil, 1)
        colonne.addWidget(boutons)
        racine.addLayout(colonne, 1)
        # taille adaptée à l'écran (barre des tâches comprise)
        from PySide6.QtWidgets import QApplication
        ecran = (parent.screen() if parent is not None else None) or QApplication.primaryScreen()
        if ecran is not None:
            dispo = ecran.availableGeometry()
            # même largeur qu'avant (1040), toute la hauteur de l'écran sans la barre des tâches
            self.resize(min(1040, dispo.width() - 20), dispo.height() - 40)
            self.move(dispo.left() + max(0, (dispo.width() - self.width()) // 2), dispo.top())

        self._minuteur = QTimer(self, singleShot=True, interval=120)
        self._minuteur.timeout.connect(self._rafraichir)
        self.champ_nom.textChanged.connect(lambda _: self._minuteur.start())
        if self.champ_nom2 is not None:
            self.champ_nom2.textChanged.connect(lambda _: self._minuteur.start())
        self.c_code.toggled.connect(lambda _: self._minuteur.start())
        self._rafraichir()

    # -- outils -------------------------------------------------------------------
    def _curseur(self, a: int, b: int, v: int) -> QSlider:
        s = QSlider(Qt.Orientation.Horizontal)
        s.setRange(a, b)
        s.setValue(v)
        s.valueChanged.connect(lambda _: self._minuteur.start())
        return s

    def _nom_court(self) -> None:
        self.champ_nom.setText(nom_court(self.p.nom_site))
        if self.champ_nom2 is not None and self.p.version2 is not None and self.p.version2.nom_site:
            self.champ_nom2.setText(nom_court(self.p.version2.nom_site))

    def _nom_complet(self) -> None:
        self.champ_nom.setText(self.p.nom_site.upper())
        if self.champ_nom2 is not None and self.p.version2 is not None and self.p.version2.nom_site:
            self.champ_nom2.setText(self.p.version2.nom_site.upper())

    def _texte_designation(self) -> str:
        if self.champ_nom2 is not None and self.p.version2 is not None:
            return ("Désignations sur la source :\n"
                    f"Produit 1 : {self.p.nom_site}\nProduit 2 : {self.p.version2.nom_site or '—'}")
        return f"Désignation sur la source : {self.p.nom_site}"

    def _lire(self) -> None:
        self.p.nom_affiche = " ".join(self.champ_nom.text().split())
        if self.champ_nom2 is not None and self.p.version2 is not None:
            self.p.version2.nom_affiche = " ".join(self.champ_nom2.text().split())
        self.p.cadrage = Cadrage(self.s_zoom.value() / 100, self.s_x.value() / 100, self.s_y.value() / 100)
        self._lire_mentions(self._versions[self._v])
        if self._mode_reseau:
            self._lire_reseau()
        ancien = self.p.mentions
        boite = [k for k, c in enumerate(self.c_boite) if c.isChecked()]
        manuel = ancien.boite_manuel or boite != self._boite_origine
        self.p.mentions = replace(ancien, boite=boite, boite_manuel=manuel, afficher_code=self.c_code.isChecked())

    def _lire_mentions(self, v: Produit) -> None:
        ancien = v.mentions
        v.mentions = replace(
            ancien,
            reconditionne=self._recond(),
            etat=self.c_etat.currentText() if self._recond() else "",
            batterie_neuve=self.c_batt.isChecked(),
            coloris=self.c_coloris.isChecked(),
            protection=self.c_protec.isChecked(),
            tarif_protection=float(self.c_tarif.currentData() or 0),
            # les couleurs d'un réseau non affiché (autre produit à deux codes) gardent leur choix
            coloris_exclus=[cle for cle, case, aj in self.c_couleurs if not aj and not case.isChecked()]
            + [k for k in ancien.coloris_exclus if k not in {c for c, _, _ in self.c_couleurs}]
            if self.c_couleurs else list(ancien.coloris_exclus),
            coloris_ajoutes=[cle for cle, case, aj in self.c_couleurs if aj and case.isChecked()]
            + [k for k in ancien.coloris_ajoutes if k not in {c for c, _, _ in self.c_couleurs}]
            if self.c_couleurs else list(ancien.coloris_ajoutes),
            reseau=(self.c_reseau.currentData() or "") if getattr(self, "c_reseau", None) is not None
            else ancien.reseau,
        )
        if self.c_eprel is not None:
            d = self.c_eprel.currentData()
            if d is not None and d != "?":
                self._eprel[v.code] = d

    def _bouton_inverser(self) -> QPushButton:
        b = QPushButton("⇄")
        b.setFixedSize(40, 40)
        b.setStyleSheet("QPushButton { font-size: 17pt; font-weight: 800; color: #E68A00; background: white;"
                        "border: 2px solid #FF9900; border-radius: 8px; padding: 0; }"
                        "QPushButton:hover { background: #FFF3E0; }")
        b.setToolTip("Inverser gauche / droite\n(échanger les deux produits sur l'affiche)")
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        b.clicked.connect(self._inverser)
        return b

    def _inverser(self) -> None:
        """Échange les deux versions. Ce qui est commun (nom, boîte, code sur l'affiche) reste commun."""
        from ..affiche import modeles_differents
        self._lire()
        v1, v2 = self._versions
        n1 = copy.copy(v2)
        n1.version2 = v1
        v1.version2 = None
        n1.mentions = replace(v2.mentions, boite=list(v1.mentions.boite), boite_manuel=v1.mentions.boite_manuel,
                              afficher_code=v1.mentions.afficher_code)
        if not modeles_differents(v1, v2):
            n1.nom_affiche = v1.nom_affiche               # même téléphone : le nom imprimé ne change pas
        self.p = n1
        self._versions = [n1, v1]
        self._v = 0
        for k, b in enumerate(getattr(self, "b_versions", [])):
            b.setText(_nom_version(k, self._versions[k], self._versions))
            b.setChecked(k == 0)
        if self.l_designation is not None:
            self.l_designation.setText(self._texte_designation())
        for ch, v in ((self.champ_nom, n1), (self.champ_nom2, v1)):
            if ch is not None:
                ch.blockSignals(True)
                ch.setText(v.nom_affiche)
                ch.blockSignals(False)
        for s, v in ((self.s_zoom, round(n1.cadrage.zoom * 100)), (self.s_x, round(n1.cadrage.decal_x * 100)),
                     (self.s_y, round(n1.cadrage.decal_y * 100))):
            s.blockSignals(True)
            s.setValue(v)
            s.blockSignals(False)
        self._construire_mentions(n1)
        if self._mode_reseau:
            self._completer_reseau()
        self.setWindowTitle(f"Modifier l'affiche — {n1.code} + {v1.code}")
        self._minuteur.start()

    def _completer_reseau(self) -> None:
        """Affiche 4G + 5G : une seule liste de couleurs (déjà rangée par réseau), et pour chaque
        réseau sa protection et sa photo."""
        from ..affiche import _reseau
        v1, v2 = self._versions
        r1, r2 = _reseau(v1) or "Version 1", _reseau(v2) or "Version 2"
        for w in (self.c_recond, self.c_etat, self.c_batt, self._lab_etat):
            if w is not None:
                w.hide()
        self.c_protec.setText(f"🛡️ Protection {r1}")
        cm = self.zone_m.layout()
        self.c_protec2 = QCheckBox(f"🛡️ Protection {r2}")
        self.c_protec2.setChecked(v2.mentions.protection)
        self.c_tarif2 = QComboBox()
        auto = tarif_pour_prix(v2.prix)
        self.c_tarif2.addItem(f"Automatique ({texte_tarif(auto)} €/mois)" if auto
                              else "Automatique (prix inconnu : aucun tarif)", 0)
        for t in sorted({g["tarif"] for g in charger_grille()}):
            self.c_tarif2.addItem(f"{texte_tarif(t)} €/mois", t)
        i = self.c_tarif2.findData(v2.mentions.tarif_protection) if v2.mentions.tarif_protection else 0
        self.c_tarif2.setCurrentIndex(max(0, i))
        self.c_tarif2.setEnabled(v2.mentions.protection)
        self.c_protec2.toggled.connect(self.c_tarif2.setEnabled)
        self.c_protec2.toggled.connect(lambda _: self._minuteur.start())
        self.c_tarif2.currentIndexChanged.connect(lambda _: self._minuteur.start())
        cm.addWidget(self.c_protec2, 8, 0)
        cm.addWidget(self.c_tarif2, 8, 1)
        cm.itemAtPosition(6, 0).widget().setText(f"📷 Photo {r1}")
        cm.addWidget(QLabel(f"📷 Photo {r2}"), 9, 0)
        cm.addWidget(self._combo_photo(v2, v1.mentions.coloris_ajoutes), 9, 1)

    def _lire_reseau(self) -> None:
        """Couleurs communes aux deux réseaux ; protection propre à chacun."""
        v1, v2 = self._versions
        m1 = v1.mentions
        v2.mentions = replace(v2.mentions, coloris=m1.coloris, coloris_exclus=list(m1.coloris_exclus),
                              coloris_ajoutes=list(m1.coloris_ajoutes), protection=self.c_protec2.isChecked(),
                              tarif_protection=float(self.c_tarif2.currentData() or 0))

    def _combo_photo(self, v: Produit, ajouts: list) -> QComboBox:
        """Liste des couleurs pour la photo : celles du catalogue (photo du site) puis celles en réserve
        (photo à choisir sur l'ordinateur, gardée pour la suite)."""
        from ..affiche import _reseau
        from ..coloris import teinte
        c = QComboBox()
        from ..coloris import couleur_produit
        choix = self.cat.photos_couleurs(v) or [(couleur_produit(v.nom_site) or "Photo actuelle", v.code, v.photo)]
        noms = {x[0] for x in choix}
        r = _reseau(v)
        for cle in ajouts:                                   # couleurs en réserve de ce réseau
            res, _, nom = cle.partition("|")
            if nom and nom not in noms and (not r or not res or res == r):
                choix.append((nom, None, ""))
                noms.add(nom)
        actuelle = 0
        for k, (couleur, code, chemin) in enumerate(choix):
            c.addItem(_pastille(teinte(couleur)), couleur + (" (réserve)" if code is None else ""), (code, chemin, couleur))
            if (v.mentions.photo_couleur or "") == (couleur if k else ""):
                actuelle = k
        c.setCurrentIndex(actuelle)
        c._precedent = actuelle
        c.currentIndexChanged.connect(lambda i, v=v, c=c: self._changer_photo(v, i, c))
        return c

    def _changer_photo(self, v: Produit, i: int, combo=None) -> None:
        combo = combo or self.c_photo
        code, chemin, couleur = combo.itemData(i)
        if code is None:                                     # couleur en réserve : photo de l'ordinateur
            dest = self.cat.chemin_photo(v.code, "_" + re.sub(r"[^A-Za-z0-9]+", "_", couleur))
            trouvee = "" if dest.is_file() else self.cat.photo_couleur(v, couleur)
            if trouvee:                                  # photo trouvée (catalogue ou site) : rien à demander
                dest = Path(trouvee)
            elif not dest.is_file():
                f, _ = QFileDialog.getOpenFileName(self, f"Photo du téléphone {couleur}", str(Path.home()),
                                                   FILTRE_IMAGES)
                try:
                    if not f:
                        raise OSError("aucun fichier")
                    self.cat.remplacer_photo_fichier(copy.copy(v), Path(f), dest)
                except (images.ImageInvalide, OSError) as e:
                    if str(e) != "aucun fichier":
                        QMessageBox.warning(self, "Photo refusée", f"Impossible d'utiliser cette image :\n{e}")
                    combo.blockSignals(True)
                    combo.setCurrentIndex(combo._precedent)
                    combo.blockSignals(False)
                    return
            chemin = str(dest)
        combo._precedent = i
        v.photo = chemin
        v.cadrage = Cadrage()
        v.mentions = replace(v.mentions, photo_couleur="" if i == 0 else couleur)
        if v is self.p:
            self._reinit_cadrage()
        self._minuteur.start()

    def _ajouter_couleur(self, v: Produit, reseau: str | None = None) -> None:
        """Petite fenêtre : nom de la couleur (liste ou saisie libre), sur le réseau de la ligne cliquée."""
        from ..coloris import _TEINTES, cle_couleur, teinte
        dlg = QDialog(self)
        dlg.setWindowTitle("Ajouter une couleur en réserve")
        g = QGridLayout(dlg)
        # couleurs déjà vues pour ce téléphone (retirées du site, autres capacités ou états) : un clic suffit
        deja = {c.lower() for _, cs in v.mentions.variantes_affichees() for c in cs}
        vues = [c for c in self.cat.couleurs_connues(v) if c["couleur"].lower() not in deja]
        ligne = 0
        if vues:
            t = QLabel("Couleurs déjà vues pour ce téléphone :")
            t.setStyleSheet("font-weight: 700;")
            g.addWidget(t, 0, 0, 1, 2)
            zone = QWidget()
            fl = _Flux(zone, 8, 6)
            for c in vues:
                b = QPushButton(f"{c['couleur']}\n{c['motif']}")
                b.setIcon(_pastille(teinte(c["couleur"])))
                b.setStyleSheet("text-align: left; padding: 4px 10px;")
                b.clicked.connect(lambda _=False, n=c["couleur"]: (c_nom.setCurrentText(n), dlg.accept()))
                fl.addWidget(b)
            g.addWidget(zone, 1, 0, 1, 2)
            autre = QLabel("Ou une autre couleur :")
            autre.setObjectName("petit")
            g.addWidget(autre, 2, 0, 1, 2)
            ligne = 3
        g.addWidget(QLabel("Couleur"), ligne, 0)
        c_nom = QComboBox()
        c_nom.setEditable(True)
        for n in sorted({k.capitalize() for k in _TEINTES}):
            c_nom.addItem(_pastille(teinte(n)), n)
        c_nom.setCurrentText("")
        c_nom.setMinimumWidth(240)                    # place pour taper le nom de la couleur
        c_nom.lineEdit().setPlaceholderText("ex. Vert sauge")
        g.addWidget(c_nom, ligne, 1)
        reseaux = [r for r, cs in v.mentions.variantes if cs]
        if reseau is not None:
            reseaux = [reseau]
            if reseau:
                dlg.setWindowTitle(f"Ajouter une couleur en réserve · {reseau}")
        c_res = None
        if len(reseaux) > 1:
            g.addWidget(QLabel("Réseau"), ligne + 1, 0)
            c_res = QComboBox()
            c_res.addItems([r or "Autre" for r in reseaux])
            g.addWidget(c_res, ligne + 1, 1)
        bb = QDialogButtonBox()
        bb.addButton("Ajouter", QDialogButtonBox.ButtonRole.AcceptRole).setObjectName("principal")
        bb.addButton("Annuler", QDialogButtonBox.ButtonRole.RejectRole)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        g.addWidget(bb, ligne + 2, 0, 1, 2)
        from .icones import appliquer
        appliquer(dlg)
        if not dlg.exec():
            return
        nom = " ".join(c_nom.currentText().split()).capitalize()
        if not nom:
            return
        res = reseaux[c_res.currentIndex()] if c_res else (reseaux[0] if reseaux else "")
        self._lire_mentions(v)
        cle = cle_couleur(res, nom)
        if cle not in v.mentions.coloris_ajoutes:
            v.mentions = replace(v.mentions, coloris=True,
                                 coloris_ajoutes=list(v.mentions.coloris_ajoutes) + [cle],
                                 coloris_exclus=[x for x in v.mentions.coloris_exclus if x != cle])
        self._construire_mentions(v)
        if self._mode_reseau:
            self._completer_reseau()
        self._minuteur.start()

    def _recond(self) -> bool:
        return (self.c_recond_commun or self.c_recond).isChecked()

    def _recond_commun(self, oui: bool) -> None:
        for v in self._versions:                       # s'applique aux deux versions
            v.mentions = replace(v.mentions, reconditionne=oui, etat=v.mentions.etat if oui else "")
        self.c_etat.setEnabled(oui)
        self._minuteur.start()

    def _choisir_version(self, k: int) -> None:
        for i, b in enumerate(self.b_versions):
            b.setChecked(i == k)
        if k == self._v:
            return
        self._lire_mentions(self._versions[self._v])
        self._v = k
        self._construire_mentions(self._versions[k])
        self._minuteur.start()

    def _construire_mentions(self, v: Produit) -> None:
        """Cases des mentions (état, batterie, couleurs, protection) de la version v."""
        if self.zone_m is not None:
            self.zone_m.hide()                       # sinon l'ancienne liste reste visible un instant dessous
            self.v_mentions.removeWidget(self.zone_m)
            self.zone_m.deleteLater()
        self.zone_m = QWidget()
        cm = QGridLayout(self.zone_m)
        cm.setContentsMargins(0, 4, 0, 0)
        mm = v.mentions
        self._lab_etat = None
        self.c_recond = QCheckBox("♻️ Reconditionné")
        self.c_recond.setChecked(mm.reconditionne)
        self.c_etat = QComboBox()                       # deux choix, comme sur le site
        self.c_etat.addItems(ETATS)
        self.c_etat.setPlaceholderText("Choisissez l'état…")
        self.c_etat.setCurrentIndex(ETATS.index(mm.etat) if mm.etat in ETATS else -1)
        self.c_etat.setToolTip("État affiché après « RECONDITIONNÉ · »")
        self.c_batt = QCheckBox("🔋 Batterie neuve")
        self.c_batt.setChecked(mm.batterie_neuve)
        # plus de case « Plusieurs coloris disponibles » : l'étiquette dépend des couleurs cochées
        self.c_coloris = QCheckBox("Plusieurs coloris disponibles")
        self.c_coloris.setChecked(mm.coloris or bool(mm.variantes))
        self.c_coloris.hide()
        if self.c_recond_commun is None:
            cm.addWidget(self.c_recond, 1, 0)
        else:                                          # même téléphone : même place, case commune aux deux
            self.c_recond.setChecked(self.c_recond_commun.isChecked())
            self.c_recond.setToolTip("Commun aux deux versions")
            self.c_recond.toggled.connect(self.c_recond_commun.setChecked)
            cm.addWidget(self.c_recond, 1, 0)
        cm.addWidget(self.c_etat, 1, 1)
        cm.addWidget(self.c_batt, 2, 0)

        from ..coloris import plusieurs, resume_variantes
        if plusieurs(mm.variantes):
            info_c = QLabel("Trouvé sur le site : " + resume_variantes(mm.variantes))
        elif mm.variantes:
            info_c = QLabel("Un seul coloris trouvé sur le site pour ce modèle")
        elif mm.iphone:
            info_c = QLabel("Coloris non vérifiés sur le site :\nrond « Plusieurs coloris disponibles »")
        else:
            info_c = QLabel("Coloris non vérifiés sur le site")
        info_c.setObjectName("petit")
        info_c.setWordWrap(True)
        cm.addWidget(info_c, 2, 1)
        # couleurs une par une : décocher celles qu'on n'a plus, ajouter celles qu'on a en réserve
        from ..coloris import ajouter, cle_couleur, teinte
        self.c_couleurs = []                      # [(clé, case, ajoutée à la main)]
        groupes = [(r, cs) for r, cs in ajouter(mm.variantes, mm.coloris_ajoutes) if cs]
        if not self._mode_reseau and len(groupes) > 1:
            # un code = un réseau : seulement les couleurs de SON réseau (comme l'affiche) ;
            # 4G et 5G ensemble seulement pour une affiche à deux produits (4G + 5G)
            from ..affiche import _reseau
            siens = [(r, cs) for r, cs in groupes if not r or r == _reseau(v)]
            groupes = siens or groupes
        ajoutes = set(mm.coloris_ajoutes)
        if mm.variantes:
            if plusieurs(mm.variantes):
                info_c.setText("Couleurs trouvées sur le site :\n(décochez celles que vous n'avez plus)")
            else:
                info_c.setText("Un seul coloris trouvé sur le site :\n(« + » : couleur en réserve)")
            zone = QWidget()
            vz = QVBoxLayout(zone)
            vz.setContentsMargins(0, 2, 0, 0)
            vz.setSpacing(4)
            exclus = set(mm.coloris_exclus)
            for r, cs in groupes:
                hz = QHBoxLayout()
                hz.setSpacing(10)
                if len(groupes) > 1:
                    lab = QLabel(r or "Autre")
                    lab.setFixedWidth(42)
                    lab.setAlignment(Qt.AlignmentFlag.AlignCenter)
                    lab.setStyleSheet("background:#1C1F24; color:white; font-weight:700;"
                                      "border-radius:4px; padding:1px 6px;")
                    hz.addWidget(lab, 0, Qt.AlignmentFlag.AlignTop)
                cases = QWidget()
                flux = _Flux(cases, 16, 4)        # remplit la ligne, descend seulement s'il manque de place
                for nom in cs:
                    cle = cle_couleur(r, nom)
                    ajoutee = cle in ajoutes
                    case = QCheckBox(nom + (" (réserve)" if ajoutee else ""))
                    case.setIcon(_pastille(teinte(nom)))
                    if ajoutee:
                        case.setToolTip("Couleur ajoutée à la main (pas sur le site).\nDécochez pour la retirer.")
                        case.setStyleSheet("font-style: italic;")
                    case.setChecked(ajoutee or cle not in exclus)
                    case.toggled.connect(lambda _: self._minuteur.start())
                    flux.addWidget(case)
                    self.c_couleurs.append((cle, case, ajoutee))
                plus = QPushButton("+")                 # ajouter une couleur en réserve sur CE réseau
                plus.setFixedSize(24, 24)
                plus.setCursor(Qt.CursorShape.PointingHandCursor)
                plus.setToolTip("Ajouter une couleur en réserve\n(en magasin mais pas sur le site)")
                plus.setStyleSheet("QPushButton { background: white; color: #E68A00; border: 2px solid #FF9900;"
                                   "border-radius: 5px; font-size: 13pt; font-weight: 800; padding: 0; }"
                                   "QPushButton:hover { background: #FFF3E0; }")
                plus.clicked.connect(lambda _=False, v=v, r=r: self._ajouter_couleur(v, r))
                flux.addWidget(plus)
                hz.addWidget(cases, 1)
                vz.addLayout(hz)
            cm.addWidget(zone, 4, 0, 1, 2)

        # protection casse / vol / oxydation (Electrosur)
        from ..affiche import est_jeu
        from ..reglages import TARIF_TRANQUILLITE
        jeu = est_jeu(v)
        self.c_protec = QCheckBox("🛡️ Garantie Tranquillité · panne" if jeu
                                  else "🛡️ Protection casse · vol · oxydation")
        self.c_protec.setChecked(mm.protection)
        self.c_tarif = QComboBox()
        auto = TARIF_TRANQUILLITE if jeu else tarif_pour_prix(v.prix)
        self.c_tarif.addItem(f"Automatique ({texte_tarif(auto)} €/mois)" if auto
                             else "Automatique (prix inconnu : aucun tarif)", 0)
        for t in sorted({g["tarif"] for g in charger_grille()}):
            self.c_tarif.addItem(f"{texte_tarif(t)} €/mois", t)
        i = self.c_tarif.findData(mm.tarif_protection) if mm.tarif_protection else 0
        self.c_tarif.setCurrentIndex(max(0, i))
        self.c_tarif.setEnabled(mm.protection)
        self.c_protec.toggled.connect(self.c_tarif.setEnabled)
        self.c_tarif.currentIndexChanged.connect(lambda _: self._minuteur.start())
        cm.addWidget(self.c_protec, 5, 0)
        cm.addWidget(self.c_tarif, 5, 1)
        # couleur du téléphone sur la photo : toujours proposée (couleurs du site + couleurs en réserve)
        cm.addWidget(QLabel("🎨 Couleur sur la photo"), 6, 0)
        self.c_photo = self._combo_photo(v, v.mentions.coloris_ajoutes)
        cm.addWidget(self.c_photo, 6, 1)
        # réseau : toujours affiché (écrit sur le site, déduit du modèle, ou choisi ici)
        from ..reseau import reseau_auto
        self.c_reseau = None
        auto = reseau_auto(v)
        if (auto or mm.reseau) and not self._mode_reseau:
            self.c_reseau = QComboBox()
            self.c_reseau.addItem(f"Automatique ({auto})" if auto else "Automatique (aucun)", "")
            self.c_reseau.addItem("4G", "4G")
            self.c_reseau.addItem("5G", "5G")
            self.c_reseau.setCurrentIndex(max(0, self.c_reseau.findData(mm.reseau)))
            self.c_reseau.setToolTip("Réseau affiché dans la mention verte\n(et dans le nom pour un produit seul)")
            self.c_reseau.currentIndexChanged.connect(lambda _: self._minuteur.start())
            cm.addWidget(QLabel("📶 Réseau"), 7, 0)
            cm.addWidget(self.c_reseau, 7, 1)
        self._ligne_eprel(v, cm, 8)
        cm.setColumnStretch(1, 1)
        for c in (self.c_recond, self.c_batt, self.c_coloris, self.c_protec):
            c.toggled.connect(lambda _: self._minuteur.start())
        self.c_recond.toggled.connect(self.c_etat.setEnabled)
        self.c_etat.setEnabled(self._recond() if self.c_recond_commun is not None else mm.reconditionne)
        self.c_etat.currentTextChanged.connect(lambda _: self._minuteur.start())
        self.v_mentions.addWidget(self.zone_m)

    # -- étiquette énergie : fiche officielle EPREL --------------------------------------------
    def _ligne_eprel(self, v: Produit, cm: QGridLayout, rang: int) -> None:
        """« 🍃 Étiquette énergie » : automatique, image du site, ou une fiche EPREL précise."""
        self.c_eprel = None
        try:
            art = self.cat.base.article(v.code)
        except Exception:
            art = None
        from .. import eprel
        choix = self._eprel.get(v.code, eprel.choix(v.code))
        if not ((art or {}).get("attributs") or {}).get("classe_energetique") and not choix:
            return
        self._art_eprel = art
        info = eprel.memoire().get(v.code) or {}
        if info.get("numero"):
            auto = f"Automatique (EPREL n° {info['numero']})"
        elif info.get("aucun"):
            auto = "Automatique (image du site)"
        else:
            auto = "Automatique"
        c = QComboBox()
        c.setMinimumWidth(300)
        c.addItem(auto, "")
        c.addItem("🖼️ Image du site Electro Dépôt", "site")
        if choix and choix != "site":
            c.addItem(f"📄 EPREL n° {choix}", choix)
        c.addItem("✏️ Saisir un numéro EPREL…", "?")
        c.setCurrentIndex(max(0, c.findData(choix)))
        c.setToolTip("Étiquette énergie imprimée.\n"
                     "EPREL = base officielle européenne : étiquette nette (PDF).\n"
                     "Le numéro EPREL est sous le QR code de l'étiquette,\n"
                     "la référence du modèle (ex. XT2535-3) est sur la boîte.")
        c.activated.connect(lambda i, cb=c, code=v.code: self._eprel_active(cb, code))
        b = QPushButton("🔎")
        b.setToolTip("Chercher les fiches EPREL de ce modèle")
        b.setFixedWidth(44)
        b.clicked.connect(lambda _=False, cb=c: self._eprel_chercher(cb))
        ligne = QHBoxLayout()                       # toute la largeur : le nom du modèle n'est jamais coupé
        ligne.setContentsMargins(0, 0, 0, 0)
        ligne.addWidget(QLabel("🍃 Étiquette énergie"))
        ligne.addWidget(c, 1)
        ligne.addWidget(b)
        w = QWidget()
        w.setLayout(ligne)
        cm.addWidget(w, rang, 0, 1, 2)
        self.c_eprel = c

    def _eprel_ajouter(self, cb: QComboBox, numero: str, texte: str) -> int:
        i = cb.findData(numero)
        if i < 0:
            i = cb.count() - 1                       # avant « Saisir un numéro… »
            cb.insertItem(i, texte, numero)
        else:
            cb.setItemText(i, texte)
        return i

    def _eprel_active(self, cb: QComboBox, code: str) -> None:
        if cb.currentData() != "?":
            self._eprel[code] = cb.currentData()
            return
        from PySide6.QtWidgets import QInputDialog
        texte, ok = QInputDialog.getText(self, "🍃 Numéro EPREL",
                                         "Numéro EPREL de l'étiquette énergie\n"
                                         "(écrit sous le QR code de l'étiquette, ex. 2348184) :")
        num = re.sub(r"\D", "", texte or "")
        if not ok or not num:
            cb.setCurrentIndex(max(0, cb.findData(self._eprel.get(code, ""))))
            return
        cb.setCurrentIndex(self._eprel_ajouter(cb, num, f"📄 EPREL n° {num}"))
        self._eprel[code] = num

    def _eprel_chercher(self, cb: QComboBox) -> None:
        from PySide6.QtWidgets import QApplication
        from .. import eprel
        art = getattr(self, "_art_eprel", None) or {}
        self.setCursor(Qt.CursorShape.WaitCursor)
        QApplication.processEvents()
        try:
            fiches = eprel.candidats(art) if art else []
        except eprel.EprelInjoignable as e:
            QMessageBox.warning(self, "🍃 EPREL", f"{e}.\nRéessayez plus tard, ou saisissez le numéro à la main.")
            return
        finally:
            self.unsetCursor()
        if not fiches:
            QMessageBox.information(self, "🍃 EPREL", "Aucune fiche EPREL trouvée pour ce modèle.\n"
                                    "L'image du site Electro Dépôt sera imprimée.")
            return
        for f in fiches:
            self._eprel_ajouter(cb, f.numero, f"📄 {f.modele} · n° {f.numero}")
        if len(fiches) == 1:
            cb.setCurrentIndex(cb.findData(fiches[0].numero))
        texte = ("1 fiche trouvée." if len(fiches) == 1 else
                 f"{len(fiches)} fiches trouvées.\nChoisissez celle dont la référence\n"
                 "est écrite sur la boîte du produit.")
        QMessageBox.information(self, "🍃 EPREL", texte)
        if len(fiches) > 1:
            cb.showPopup()

    def _reinit_cadrage(self) -> None:
        for s, v in ((self.s_zoom, 100), (self.s_x, 0), (self.s_y, 0)):
            s.setValue(v)

    def _rafraichir(self) -> None:
        from .icones import appliquer
        appliquer(self)                               # textes changés (onglets, réseau…) : émoticônes
        self._lire()
        nom = self.p.nom_affiche
        if not nom:
            self.info_nom.setText("⚠ Le nom ne peut pas être vide.")
        else:
            mf = affiche.mettre_en_forme_nom(nom)
            if mf.trop_long:
                self.info_nom.setText("⚠ Nom trop long, même en petit : raccourcissez-le.")
            elif len(mf.lignes) == 2:
                self.info_nom.setText(f"Nom long : affiché sur 2 lignes en {mf.taille:g} pt.")
            elif mf.reduit:
                self.info_nom.setText(f"Nom un peu long : taille réduite à {mf.taille:g} pt.")
            else:
                self.info_nom.setText("Taille d'origine du modèle (13 pt).")
        if not self.p.photo or not Path(self.p.photo).is_file():
            self.apercu.setText("Aucune photo.\nChoisissez-en une à droite.")
            return
        try:
            png = affiche.apercu_png(self.p if nom else _avec_nom(self.p, " "), dpi=150, une_seule=True,
                                     surligner=self._v if len(self._versions) == 2 and self._surligne else None)
        except Exception as e:
            self.apercu.setText(f"Aperçu impossible : {e}")
            return
        pm = QPixmap()
        pm.loadFromData(png)
        self.apercu.setPixmap(pm.scaled(self.apercu.size() * 0.96, Qt.AspectRatioMode.KeepAspectRatio,
                                        Qt.TransformationMode.SmoothTransformation))

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._minuteur.start()

    # -- photo ---------------------------------------------------------------------
    def _photo_fichier(self) -> None:
        f, _ = QFileDialog.getOpenFileName(self, "Choisir la photo du produit", str(Path.home()), FILTRE_IMAGES)
        if not f:
            return
        try:
            self.cat.remplacer_photo_fichier(self.p, Path(f), self._chemin_temp())
        except (images.ImageInvalide, OSError) as e:
            QMessageBox.warning(self, "Photo refusée", f"Impossible d'utiliser cette image :\n{e}")
            return
        self.info_photo.setText("Photo remplacée. Les bords blancs ont été retirés automatiquement.")
        self._reinit_cadrage()
        self._rafraichir()

    def _charger_galerie(self) -> None:
        self.b_galerie.setEnabled(False)
        self.info_photo.setText("Chargement des photos du site…")
        urls = list(self.p.galerie)[:7]

        def charger():
            res = []
            for u in urls:
                try:
                    res.append((u, self.cat.client.telecharger_url(u)))
                except Exception:
                    pass
            return res

        taches.lancer(charger, fini=self._galerie_chargee,
                      erreur=lambda e: self.info_photo.setText(f"Photos indisponibles : {e}"))

    def _galerie_chargee(self, res) -> None:
        while self.zone_galerie.count():
            w = self.zone_galerie.takeAt(0).widget()
            if w:
                w.deleteLater()
        if not res:
            self.info_photo.setText("Aucune autre photo n'a pu être chargée.")
            return
        for url, data in res:
            pm = QPixmap()
            if not pm.loadFromData(data):
                try:
                    import io
                    im = images.sur_fond_blanc(images.ouvrir(data))
                    buf = io.BytesIO()
                    im.save(buf, "PNG")
                    pm.loadFromData(buf.getvalue())
                except Exception:
                    continue
            b = QPushButton()
            b.setFixedSize(76, 76)
            b.setIcon(pm.scaled(70, 70, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
            b.setIconSize(pm.scaled(70, 70, Qt.AspectRatioMode.KeepAspectRatio).size())
            b.setToolTip("Utiliser cette photo")
            b.clicked.connect(lambda _=False, d=data: self._utiliser(d))
            self.zone_galerie.addWidget(b)
        self.zone_galerie.addStretch()
        self.info_photo.setText("Cliquez sur une photo pour l'utiliser. Évitez celles avec du texte ou des accessoires.")

    def _utiliser(self, data: bytes) -> None:
        try:
            dest = self._chemin_temp()
            images.preparer(data, dest, verifier_taille=False)
        except images.ImageInvalide as e:
            QMessageBox.warning(self, "Photo refusée", str(e))
            return
        self.p.photo = str(dest)
        self._reinit_cadrage()
        self._rafraichir()

    # -- validation ------------------------------------------------------------------
    def _valider(self) -> None:
        self._lire()
        if not self.p.nom_affiche:
            QMessageBox.warning(self, "Nom manquant", "Indiquez le nom à imprimer sur l'affiche.")
            return
        if self.champ_nom2 is not None and not self.p.version2.nom_affiche:
            QMessageBox.warning(self, "Nom manquant", "Indiquez le nom du produit 2.")
            return
        if affiche.mettre_en_forme_nom(self.p.nom_affiche).trop_long:
            QMessageBox.warning(self, "Nom trop long", "Ce nom ne tient pas lisiblement sur l'affiche.\nRaccourcissez-le.")
            return
        if not self.p.photo or not Path(self.p.photo).is_file():
            QMessageBox.warning(self, "Photo manquante", "Choisissez une photo du produit.")
            return
        for k, v in enumerate(self._versions):
            if v.mentions.reconditionne and v.mentions.etat not in ETATS:
                if len(self._versions) == 2:
                    self._choisir_version(k)
                QMessageBox.warning(self, "État manquant", "Un produit reconditionné a forcément un état :\n"
                                    "choisissez « EXCELLENT ÉTAT » ou « ÉTAT CORRECT ».")
                return
        if Path(self.p.photo) == self._chemin_temp():      # nouvelle photo validée
            final = self.cat.chemin_photo(self.p.code)
            os.replace(self.p.photo, final)
            self.p.photo = str(final)
            if self.p.source in ("electrodepot.fr", "catalogue hors ligne"):
                self.p.avertissement = "Photo choisie manuellement."
        from .. import eprel
        for code, valeur in self._eprel.items():
            try:
                eprel.choisir(code, valeur)
            except OSError:
                pass
        self.cat.enregistrer(self.p)
        self.cat.base.noter(self.p.code, "modification")
        if self.p.version2 is not None:                     # la 2e version garde ses propres mentions
            self.cat.enregistrer(self.p.version2)
            self.cat.base.noter_paire(self.p.code, self.p.version2.code)   # ordre gauche / droite gardé
            self.cat.base.noter(self.p.version2.code, "modification")
        self.accept()

    def produit(self) -> Produit:
        return self.p

    def _chemin_temp(self) -> Path:
        return self.cat.chemin_photo(self.p.code, "_edition")

    def _cliquer_version(self, k: int) -> None:
        """Clic sur l'onglet Version / Produit : on le montre sur l'aperçu (encadré orange)."""
        self._surligne = True
        if not getattr(self, "_filtre_pose", False):
            from PySide6.QtWidgets import QApplication
            QApplication.instance().installEventFilter(self)
            self._filtre_pose = True
        self._choisir_version(k)
        self._minuteur.start()

    def _colonne_cliquee(self, pos) -> int | None:
        """Version (0 / 1) sous le clic dans l'aperçu, ou None (à côté des téléphones)."""
        pm = self.apercu.pixmap()
        if pm is None or pm.isNull() or len(self._versions) != 2:
            return None
        ox = (self.apercu.width() - pm.width()) / 2
        oy = (self.apercu.height() - pm.height()) / 2
        fx = (pos.x() - ox) / pm.width()
        fy = (pos.y() - oy) / pm.height()
        if not (0 <= fx <= 1 and 0 <= fy <= 1):
            return None
        x0, y0, x1, y1 = affiche.CADRE
        x, y = x0 + fx * (x1 - x0), y0 + fy * (y1 - y0)
        for k, (a, b, c, d) in enumerate(affiche.COLONNES_DUO):
            if a <= x <= c and b <= y <= d:
                return k
        return None

    def eventFilter(self, obj, ev):
        """Clic sur un téléphone de l'aperçu : choisit sa version. Après une sélection, un clic
        n'importe où ailleurs dans la fenêtre l'enlève."""
        from PySide6.QtCore import QEvent
        if obj is self.apercu and ev.type() == QEvent.Type.MouseButtonPress:
            k = self._colonne_cliquee(ev.position().toPoint())
            if k is not None:
                if getattr(self, "b_versions", None):
                    for i, b in enumerate(self.b_versions):
                        b.setChecked(i == k)
                self._cliquer_version(k)
                return True
        if (self._surligne and ev.type() == QEvent.Type.MouseButtonPress and isinstance(obj, QWidget)
                and obj.window() is self
                and not any(b is obj or b.isAncestorOf(obj) for b in getattr(self, "b_versions", []))):
            self._surligne = False
            self._minuteur.start()
        return False

    def done(self, r: int) -> None:
        if getattr(self, "_filtre_pose", False):
            from PySide6.QtWidgets import QApplication
            QApplication.instance().removeEventFilter(self)
            self._filtre_pose = False
        t = self._chemin_temp()
        if t.exists():
            try:
                t.unlink()
            except OSError:
                pass
        super().done(r)


def _nom_version(k: int, v: Produit, versions: list | None = None) -> str:
    """Nom de l'onglet : « Version 1 » (ou « Produit 1 » pour deux téléphones différents), puis le code."""
    lib = f"Version {k + 1}"
    if versions and len(versions) == 2:
        from ..affiche import libelle_version
        lib = libelle_version(versions[0], versions[1], k)
    return f"{lib}\n{v.code}"


def _avec_nom(p: Produit, nom: str) -> Produit:
    q = copy.copy(p)
    q.nom_affiche = nom
    return q
