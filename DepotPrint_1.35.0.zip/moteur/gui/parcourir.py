"""Onglet « Parcourir » : trouver un produit dans le catalogue hors ligne par catégorie,
marque ou mot, sans chercher son code sur le site."""
from __future__ import annotations

from PySide6.QtCore import QSize, Qt
from PySide6.QtGui import QColor, QIcon, QPixmap
from PySide6.QtWidgets import (QAbstractItemView, QComboBox, QHBoxLayout, QHeaderView, QLabel, QLineEdit,
                               QListWidget, QListWidgetItem, QMessageBox, QPushButton, QTableWidget,
                               QTableWidgetItem, QVBoxLayout, QWidget, QCheckBox)

from .. import energie
from ..paths import retrouver_photo

from ..hors_ligne import GROUPES
CATEGORIES = [("tout", "🗂️ Tout le catalogue")] + [(cle, lib) for cle, lib, _ in GROUPES]
from ..hors_ligne import SANS_AFFICHE
# rayon du site -> catégorie, déduit des mêmes GROUPES (jamais désynchronisé)
_CAT_ENERGIE = {r: cle for cle, _, rayons in GROUPES for r in rayons if r in SANS_AFFICHE}


def etiquette_seulement(a: dict) -> bool:
    """TV, électroménager, stockage… : pas d'affiche."""
    return (a.get("rayon") or "") in _CAT_ENERGIE


def categorie(a: dict) -> str:
    r = a.get("rayon") or ""
    if r in _CAT_ENERGIE:
        return _CAT_ENERGIE[r]
    recond = (a.get("attributs") or {}).get("flap_reconditionne") == "Oui" or "reconditionn" in a["nom"].lower()
    if r == "ipad_recond":
        return "ipad_recond"
    if r == "tablettes":
        return "tablettes"
    if r == "mobiles":
        return "mobiles"
    if r == "consoles":
        return "consoles"
    return "recond" if (recond or r == "smartphones_recond") else "neufs"


def _nom_court(nom: str) -> str:
    """« Smartphone SAMSUNG Galaxy A17 4G 128Go Noir » → « SAMSUNG A17 128 GO 4G » (sous l'étiquette)."""
    from ..noms import nom_court
    return nom_court(nom) or nom


def _noter_erreur(quoi: str) -> None:
    """Erreur dans un bouton : écrite dans erreurs.log et expliquée, sans fermer le logiciel."""
    import traceback
    texte = traceback.format_exc()
    try:
        from ..paths import data_dir
        with (data_dir() / "erreurs.log").open("a", encoding="utf-8") as f:
            f.write(f"--- {quoi} ---\n{texte}\n")
    except Exception:
        pass
    QMessageBox.warning(None, "Dépôt Print", f"« {quoi} » n'a pas fonctionné.\n"
                        "(détails enregistrés dans erreurs.log)")


def _mots(texte: str) -> list[str]:
    import re
    return [m for m in re.split(r"[^0-9a-zàâäéèêëîïôöùûüç+]+", texte.lower()) if m]


def correspond(a: dict, mot: str) -> bool:
    """« 13 » trouve « iPhone 13 » mais pas « 128Go » ; un code se tape en entier ou par le début ;
    « iphone13 » ou « 128go » collés marchent aussi."""
    mot = mot.lower()
    if a["code"].startswith(mot):
        return True
    mots = _mots(a["nom"] + " " + (a.get("coloris") or ""))
    if any(m.startswith(mot) for m in mots):
        return True
    return any((x + y).startswith(mot) for x, y in zip(mots, mots[1:]))


def marque(a: dict) -> str:
    m = ((a.get("attributs") or {}).get("brand") or "").strip()
    if m:
        import re
        return re.sub(r"\s+(RECOND\w*|RECONDITIONN\w*)$", "", m.upper()).strip()
    mots = [x for x in a["nom"].split() if x.isupper() and len(x) > 1]
    return mots[0] if mots else "—"


class OngletParcourir(QWidget):
    def __init__(self, fenetre):
        super().__init__()
        self.fenetre = fenetre
        self.cat = fenetre.cat
        self.articles: list[dict] = []
        self.coches: set[str] = set()          # produits cochés (gardés quand on change de catégorie)
        self._icones: dict[str, QIcon] = {}    # vignettes déjà préparées (sinon la liste rame)
        racine = QHBoxLayout(self)
        racine.setContentsMargins(22, 18, 22, 18)
        racine.setSpacing(16)

        # gauche : catégories
        g = QVBoxLayout()
        t = QLabel("Catégories")
        t.setObjectName("etiquette")
        g.addWidget(t)
        self.l_cat = QListWidget()
        self.l_cat.setObjectName("categories")
        self.l_cat.setFixedWidth(250)
        self.l_cat.setStyleSheet("QListWidget#categories { font-size: 11pt; } "
                                 "QListWidget#categories::item { padding: 9px 6px; }")
        for cle, lib in CATEGORIES:
            it = QListWidgetItem(lib)
            it.setData(Qt.ItemDataRole.UserRole, cle)
            if cle == "—":                         # titre de groupe : ni sélectionnable ni cliquable
                it.setFlags(Qt.ItemFlag.NoItemFlags)
                f = it.font()
                f.setBold(True)
                it.setFont(f)
            self.l_cat.addItem(it)
        self.l_cat.currentRowChanged.connect(lambda _: self.filtrer())
        self.l_cat.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.l_cat.customContextMenuRequested.connect(self._menu_categorie)
        g.addWidget(self.l_cat, 1)
        self.b_ajout_cat = QPushButton("➕  Ajouter une catégorie")
        self.b_ajout_cat.setObjectName("modifier")
        self.b_ajout_cat.setFixedWidth(250)
        self.b_ajout_cat.clicked.connect(self.ajouter_categorie)
        self.b_ajout_cat.setVisible(False)
        g.addWidget(self.b_ajout_cat)
        racine.addLayout(g)

        # droite : filtres + liste
        d = QVBoxLayout()
        h = QHBoxLayout()
        self.recherche = QLineEdit()
        self.recherche.setPlaceholderText("🔎 Un mot : A17, iPhone 13, 256, bleu…")
        self.recherche.setClearButtonEnabled(True)
        self.recherche.textChanged.connect(lambda _: self.filtrer())
        h.addWidget(self.recherche, 1)
        h.addWidget(QLabel("Marque"))
        self.c_marque = QComboBox()
        self.c_marque.setMinimumWidth(170)
        self.c_marque.currentIndexChanged.connect(lambda _: self.filtrer())
        h.addWidget(self.c_marque)
        self.c_retires = QCheckBox("Produits plus sur le site")
        self.c_retires.toggled.connect(lambda _: self.filtrer())
        h.addWidget(self.c_retires)
        d.addLayout(h)

        hc = QHBoxLayout()
        self.compte = QLabel("")
        self.compte.setObjectName("petit")
        hc.addWidget(self.compte)
        hc.addStretch()
        self.b_tout = QPushButton("☑️ Tout cocher")
        self.b_tout.clicked.connect(self.tout_cocher)
        self.b_rien = QPushButton("✖ Tout décocher")
        self.b_rien.clicked.connect(self.tout_decocher)
        for b in (self.b_tout, self.b_rien):
            hc.addWidget(b)
        d.addLayout(hc)

        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["✔", "", "Produit", "Code", "Couleur", "🍃"])
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(54)
        self.table.setIconSize(QSize(46, 46))
        hh = self.table.horizontalHeader()
        hh.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        for i, larg in ((0, 40), (1, 60), (3, 92), (4, 110), (5, 40)):   # largeurs fixes : liste rapide
            hh.setSectionResizeMode(i, QHeaderView.ResizeMode.Fixed)
            self.table.setColumnWidth(i, larg)
        hh.setMinimumSectionSize(40)
        self.table.horizontalHeaderItem(5).setToolTip("Étiquette énergie disponible sans Internet")
        self.table.itemDoubleClicked.connect(lambda it: it.column() != 0 and self.ouvrir(it.row()))
        self.table.cellClicked.connect(self._clic)
        self.table.itemChanged.connect(self._coche_changee)
        self.table.itemSelectionChanged.connect(self._maj_boutons)
        d.addWidget(self.table, 1)

        self.aide = aide = QLabel("Cochez les produits (un clic sur la ligne), puis « Affiches » ou « Étiquettes énergie » :\n"
                      "le PDF s'ouvre tout de suite. Double-clic sur un produit : il s'ouvre dans « Un produit ».")
        aide.setObjectName("petit")
        d.addWidget(aide)
        hb = QHBoxLayout()
        self.b_ouvrir = QPushButton("🖼️  Faire l'affiche")
        self.b_ouvrir.setObjectName("principal")
        self.b_ouvrir.clicked.connect(lambda: self.ouvrir(self.table.currentRow()))
        self.b_lot = QPushButton("🖼️  Affiches")
        self.b_lot.setObjectName("principal")
        self.b_lot.setToolTip("Le PDF des affiches des produits cochés, ouvert tout de suite")
        self.b_lot.clicked.connect(self.vers_lot)
        self.b_energie = QPushButton("🍃  Étiquettes énergie")
        self.b_energie.setObjectName("energie")
        self.b_energie.clicked.connect(self.etiquettes)
        self.b_ouvrir.hide()                          # double-clic suffit : deux boutons seulement
        for b in (self.b_lot, self.b_energie):
            hb.addWidget(b)
        d.addLayout(hb)
        racine.addLayout(d, 1)
        for b in (self.b_lot, self.b_energie):         # remplacés par le panneau « Impression » à droite
            b.hide()
        self.b_lot.setVisible = self.b_energie.setVisible = lambda *_: None
        racine.addWidget(self._panneau_impression())
        self.charger()
        self.l_cat.setCurrentRow(0)

    # -- données ---------------------------------------------------------------
    # catégories utiles selon la carte choisie à l'accueil
    CAT_SANS_ENERGIE = {"consoles", "stockage", "recond", "ipad_recond"}   # pas d'étiquette énergie
    # affiches : pas les mobiles seniors (leurs étiquettes sont déjà en magasin)
    CAT_AFFICHES = {"neufs", "recond", "tablettes", "ipad_recond", "consoles"}

    def mode_energie(self, actif: bool) -> None:
        """Accueil : « Étiquettes énergie » = bouton 🍃 seul ; « Étiquettes produits » = bouton Affiches seul.
        Chaque mode ne montre que ses rayons."""
        self.mode = "energie" if actif else "produits"
        self.b_lot.setVisible(not actif)
        self.b_energie.setVisible(actif)
        self.table.setColumnHidden(5, not actif)            # colonne 🍃 : seulement pour les étiquettes énergie
        self._maj_categories()
        if hasattr(self, "_minuterie"):
            self._poser_options()
        self.aide.setText("Cochez les produits (un clic sur la ligne) : l'aperçu est à droite." if actif else
                          "Cochez les produits (un clic sur la ligne) : l'aperçu est à droite.\n"
                          "Double-clic sur un produit : il s'ouvre dans « Un produit ».")
        self.tout_decocher() if hasattr(self, "tout_decocher") else None
        self.filtrer()

    def _ajoutees(self) -> list[str]:
        """Catégories remises à la main dans ce mode (bouton « Ajouter une catégorie »)."""
        from ..reglages import lire_reglage
        return list(lire_reglage(f"categories_ajoutees_{getattr(self, 'mode', '')}", []) or [])

    def _cat_permise(self, cle: str) -> bool:
        mode = getattr(self, "mode", "")
        if cle == "tout" or not mode:
            return True
        if cle in self._ajoutees():
            return True
        return cle not in self.CAT_SANS_ENERGIE if mode == "energie" else cle in self.CAT_AFFICHES

    def _cachees(self) -> list[tuple[str, str]]:
        return [(cle, lib) for cle, lib in CATEGORIES if cle != "tout" and not self._cat_permise(cle)]

    def _maj_categories(self) -> None:
        for i in range(self.l_cat.count()):
            cle = self.l_cat.item(i).data(Qt.ItemDataRole.UserRole)
            self.l_cat.item(i).setHidden(not self._cat_permise(cle))
        if self.l_cat.currentItem() is not None and self.l_cat.currentItem().isHidden():
            self.l_cat.setCurrentRow(0)
        self.b_ajout_cat.setVisible(bool(getattr(self, "mode", "")) and bool(self._cachees()))

    def ajouter_categorie(self) -> None:
        """Remettre une catégorie enlevée de ce mode (ex. reconditionnés dans l'énergie)."""
        from PySide6.QtWidgets import QDialog, QDialogButtonBox, QCheckBox as _Case
        from ..reglages import enregistrer_reglage
        dlg = QDialog(self)
        dlg.setWindowTitle("➕ Ajouter une catégorie")
        v = QVBoxLayout(dlg)
        v.addWidget(QLabel("Catégories à ajouter ici :"))
        cases = []
        for cle, lib in self._cachees():
            c = _Case(lib)
            v.addWidget(c)
            cases.append((cle, c))
        b = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        b.button(QDialogButtonBox.StandardButton.Ok).setText("Ajouter")
        b.button(QDialogButtonBox.StandardButton.Cancel).setText("Annuler")
        b.accepted.connect(dlg.accept)
        b.rejected.connect(dlg.reject)
        v.addWidget(b)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        choix = [cle for cle, c in cases if c.isChecked()]
        if choix:
            enregistrer_reglage(f"categories_ajoutees_{self.mode}", self._ajoutees() + choix)
            self._maj_categories()
            self.filtrer()

    def _menu_categorie(self, pos) -> None:
        """Clic droit sur une catégorie ajoutée à la main : la retirer de ce mode."""
        it = self.l_cat.itemAt(pos)
        if it is None:
            return
        cle = it.data(Qt.ItemDataRole.UserRole)
        if cle not in self._ajoutees():
            return
        from PySide6.QtWidgets import QMenu
        from ..reglages import enregistrer_reglage
        m = QMenu(self)
        a = m.addAction("➖  Retirer cette catégorie d'ici")
        if m.exec(self.l_cat.mapToGlobal(pos)) is a:
            enregistrer_reglage(f"categories_ajoutees_{self.mode}", [c for c in self._ajoutees() if c != cle])
            self._maj_categories()
            self.filtrer()

    def charger(self) -> None:
        self.articles = self.cat.base.catalogue_complet()
        self._icones = {}
        for a in self.articles:
            a["_cat"] = categorie(a)
            a["_marque"] = marque(a)
        actuelle = self.c_marque.currentText()
        self.c_marque.blockSignals(True)
        self.c_marque.clear()
        self.c_marque.addItem("Toutes")
        for m in sorted({a["_marque"] for a in self.articles if a["_marque"] != "—"}):
            self.c_marque.addItem(m)
        i = self.c_marque.findText(actuelle)
        self.c_marque.setCurrentIndex(max(0, i))
        self.c_marque.blockSignals(False)
        self.filtrer()

    def filtrer(self) -> None:
        it = self.l_cat.currentItem()
        cle = it.data(Qt.ItemDataRole.UserRole) if it else "tout"
        mq = self.c_marque.currentText()
        mots = self.recherche.text().lower().split()
        liste = []
        permises = {c for c, _ in CATEGORIES if self._cat_permise(c)}   # lu une fois (pas à chaque produit)
        ajoutees = set(self._ajoutees())
        for a in self.articles:
            if a.get("retire") and not self.c_retires.isChecked():
                continue
            if cle != "tout" and a["_cat"] != cle:
                continue
            if a["_cat"] not in permises:                   # rayons de l'autre mode : cachés
                continue
            if (getattr(self, "mode", "") == "energie" and energie._reconditionne(a)
                    and a["_cat"] not in ajoutees):
                continue                                     # reconditionnés : jamais d'étiquette énergie
            if mq and mq != "Toutes" and a["_marque"] != mq:
                continue
            if not all(correspond(a, m) for m in mots):
                continue
            liste.append(a)
        self.visibles = liste
        self.table.blockSignals(True)
        self.table.setUpdatesEnabled(False)
        self.table.setRowCount(0)
        self.table.setRowCount(len(liste))
        for i, a in enumerate(liste):
            c = QTableWidgetItem()
            c.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsUserCheckable)
            c.setCheckState(Qt.CheckState.Checked if a["code"] in self.coches else Qt.CheckState.Unchecked)
            c.setData(Qt.ItemDataRole.UserRole, a["code"])
            self.table.setItem(i, 0, c)
            ph = QTableWidgetItem()
            ic = self._icone(a)
            if ic is not None:
                ph.setIcon(ic)
            self.table.setItem(i, 1, ph)
            nom = QTableWidgetItem(a["nom"] + ("  (plus sur le site)" if a.get("retire") else ""))
            nom.setData(Qt.ItemDataRole.UserRole, a["code"])
            self.table.setItem(i, 2, nom)
            self.table.setItem(i, 3, QTableWidgetItem(a["code"]))
            self.table.setItem(i, 4, QTableWidgetItem(a.get("coloris") or ""))
            e = QTableWidgetItem("✔" if energie.fichier_local(a["code"]) else "")
            e.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            e.setForeground(Qt.GlobalColor.darkGreen)
            self.table.setItem(i, 5, e)
        self.table.setUpdatesEnabled(True)
        self.table.blockSignals(False)
        self._maj_boutons()

    def _codes(self) -> list[str]:
        """Produits cochés (dans l'ordre du catalogue) ; sinon la ligne sélectionnée."""
        if self.coches:
            return [a["code"] for a in self.articles if a["code"] in self.coches]
        rangs = sorted({i.row() for i in self.table.selectedIndexes()})
        return [self.table.item(r, 2).data(Qt.ItemDataRole.UserRole) for r in rangs]

    def _clic(self, rang: int, col: int) -> None:
        """Un clic sur la ligne (hors bouton) coche ou décoche le produit."""
        if col == 0:
            return
        it = self.table.item(rang, 0)
        if it is not None:
            it.setCheckState(Qt.CheckState.Unchecked if it.checkState() == Qt.CheckState.Checked
                             else Qt.CheckState.Checked)

    def _coche_changee(self, it) -> None:
        if it.column() != 0:
            return
        code = it.data(Qt.ItemDataRole.UserRole)
        if it.checkState() == Qt.CheckState.Checked:
            self.coches.add(code)
        else:
            self.coches.discard(code)
        self._maj_boutons()

    def _icone(self, a: dict):
        """Vignette du produit, préparée une seule fois (petite image en mémoire)."""
        code = a["code"]
        if code not in self._icones:
            ic = None
            f = retrouver_photo(a.get("photo") or "")
            if f:
                from PySide6.QtGui import QImageReader
                lecteur = QImageReader(f)
                taille = lecteur.size()
                if taille.isValid() and max(taille.width(), taille.height()) > 0:
                    r = 92 / max(taille.width(), taille.height())
                    lecteur.setScaledSize(taille * r)          # lit directement en petit : rapide
                img = lecteur.read()
                if not img.isNull():
                    ic = QIcon(QPixmap.fromImage(img))
            self._icones[code] = ic
        return self._icones[code]

    def _cases_visibles(self, coche: bool) -> None:
        """Coche / décoche les lignes affichées sans reconstruire la liste (instantané)."""
        etat = Qt.CheckState.Checked if coche else Qt.CheckState.Unchecked
        self.table.blockSignals(True)
        for r in range(self.table.rowCount()):
            it = self.table.item(r, 0)
            if it is not None:
                it.setCheckState(etat)
        self.table.blockSignals(False)
        self._maj_boutons()

    def tout_cocher(self) -> None:
        self.coches.update(a["code"] for a in self.visibles)
        self._cases_visibles(True)

    def tout_decocher(self) -> None:
        self.coches.clear()
        self._cases_visibles(False)

    def _ajouter_un(self, code: str) -> None:
        self.fenetre.lot.ajouter_codes([code])
        nom = next((a["nom"] for a in self.articles if a["code"] == code), code)
        self.compte.setText(f"✅ Ajouté à « Plusieurs produits » :\n{nom}")

    def _maj_boutons(self) -> None:
        n = len(self._codes())
        nb = len(self.visibles) if hasattr(self, "visibles") else 0
        coche = len(self.coches)
        self.compte.setText(f"{nb} produit{'s' if nb > 1 else ''}"
                            + (f"  ·  ✔ {coche} coché{'s' if coche > 1 else ''}" if coche else ""))
        na = len(self._codes_affiches())
        self.b_ouvrir.setEnabled(n == 1)
        self.b_lot.setEnabled(na >= 1)
        self.b_energie.setEnabled(n >= 1)
        self.b_lot.setText("🖼️  Affiches" + (f" ({na})" if na else ""))
        self.b_energie.setText("🍃  Étiquettes énergie" + (f" ({n})" if n else ""))
        if hasattr(self, "_minuterie"):
            self._maj_panneau()
            self._minuterie.start()

    # -- actions ---------------------------------------------------------------
    def ouvrir(self, rang: int) -> None:
        if rang < 0 or rang >= self.table.rowCount() or getattr(self.fenetre, "mode", "") == "energie":
            return
        code = self.table.item(rang, 2).data(Qt.ItemDataRole.UserRole)
        if code not in self._codes_affiches() and any(a["code"] == code and etiquette_seulement(a)
                                                      for a in self.articles):
            return                                   # pas d'affiche pour une TV ou un frigo
        f = self.fenetre
        f.onglets.setCurrentIndex(0)
        f._deux_cases(False)
        f._mettre_code(code)
        f.rechercher()

    def vers_lot(self) -> None:
        try:
            self._vers_lot()
        except Exception:
            _noter_erreur("Affiches")

    def _codes_affiches(self) -> list[str]:
        """Codes cochés qui peuvent avoir une affiche (téléphonie : pas les TV ni l'électroménager)."""
        seuls = {a["code"] for a in self.articles if etiquette_seulement(a)}
        return [c for c in self._codes() if c not in seuls]

    def _vers_lot(self) -> None:
        """« Affiches » : le PDF des affiches des produits cochés, ouvert tout de suite."""
        codes = self._codes_affiches()
        if not codes or not self._confirmer_beaucoup(len(codes), "affiches"):
            return
        from datetime import datetime
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QDesktopServices
        from PySide6.QtWidgets import QApplication
        from .. import affiche, paths
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        prets, rates = [], []
        try:
            for c in codes:
                try:
                    p = getattr(self.cat.obtenir(c), "produit", None)
                except Exception as e:
                    rates.append((c, str(e).split("\n")[0]))
                    continue
                if p is not None and p.pret:
                    prets.append(p)
                else:
                    rates.append((c, "photo ou nom manquant : à compléter dans « Un produit »"))
            if not prets:
                raise RuntimeError("aucune affiche n'a pu être faite")
            horo = datetime.now().strftime("%Y-%m-%d_%Hh%M")
            nom = (self.fenetre.nom_fichier(prets[0]) if len(prets) == 1
                   else f"Affiches_{horo}_{len(prets)}_produits.pdf")
            dest = affiche.creer_pdf(prets, paths.output_dir() / nom, f"Affiches rayon ({len(prets)})")
            for p in prets:
                self.cat.base.noter_affiche(p, "PDF", str(dest))
        except PermissionError:
            QApplication.restoreOverrideCursor()
            QMessageBox.warning(self, "Fichier ouvert", "Ce PDF est ouvert dans un autre programme.\n"
                                                        "Fermez-le puis réessayez.")
            return
        except RuntimeError as e:
            QApplication.restoreOverrideCursor()
            QMessageBox.warning(self, "Affiches", f"Le PDF n'a pas été créé :\n{e}.\n\n"
                                + "\n".join(f"{c} : {r}" for c, r in rates[:10]))
            return
        QApplication.restoreOverrideCursor()
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(dest)))
        self.fenetre.rafraichir_historique()
        self._bilan(f"✅ PDF des affiches ouvert ({len(prets)})", rates)
        self.tout_decocher()

    # -- panneau « Impression » (comme le relevé) -------------------------------------------------
    OPTIONS_ENERGIE = {"marges": False, "texte": True, "pointilles": True, "eprel": True}
    OPTIONS_AFFICHES = {"par_feuille": 2, "protection": True, "pointilles": True, "un_par_produit": False}

    def _panneau_impression(self) -> QWidget:
        from PySide6.QtCore import QTimer
        from PySide6.QtWidgets import QButtonGroup, QScrollArea
        w = QWidget()
        w.setFixedWidth(340)
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 0, 0, 0)
        t = QLabel("🖨️ Impression")
        t.setObjectName("etiquette")
        v.addWidget(t)
        hm = QHBoxLayout()
        self.groupe_modes = QButtonGroup(self)
        self.b_mode = []
        for k in range(2):
            b = QPushButton("")
            b.setCheckable(True)
            b.setObjectName("mode")
            self.groupe_modes.addButton(b, k)
            hm.addWidget(b)
            self.b_mode.append(b)
        self.groupe_modes.idClicked.connect(lambda _: self._options_changees())
        v.addLayout(hm)
        self.l_mode_aide = QLabel("")
        self.l_mode_aide.setObjectName("petit")
        v.addWidget(self.l_mode_aide)
        self.c_opt = []
        for _ in range(3):
            c = QCheckBox("")
            c.toggled.connect(lambda _: self._options_changees())
            v.addWidget(c)
            self.c_opt.append(c)
        zone = QScrollArea()
        zone.setWidgetResizable(True)
        zone.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.l_apercu = QLabel("")
        self.l_apercu.setAlignment(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop)
        zone.setWidget(self.l_apercu)
        zone.viewport().installEventFilter(self)          # fenêtre agrandie / réduite : aperçu refait
        self._zone_apercu = zone
        v.addWidget(zone, 1)
        self.l_pages = QLabel("")
        self.l_pages.setObjectName("petit")
        v.addWidget(self.l_pages)
        self.b_export = QPushButton("📄  EXPORTER EN PDF")
        self.b_export.clicked.connect(lambda: self._sortie(imprimer=False))
        v.addWidget(self.b_export)
        self.b_imprimer = QPushButton("🖨️  IMPRIMER")
        self.b_imprimer.setMinimumHeight(48)
        self.b_imprimer.clicked.connect(lambda: self._sortie(imprimer=True))
        v.addWidget(self.b_imprimer)
        self._minuterie = QTimer(self, singleShot=True, interval=450)
        self._minuterie.timeout.connect(self._apercu)
        self._poser_options()
        return w

    def eventFilter(self, obj, ev):
        from PySide6.QtCore import QEvent
        if (ev.type() == QEvent.Type.Resize and getattr(self, "_zone_apercu", None) is not None
                and obj is self._zone_apercu.viewport() and ev.oldSize().width() != ev.size().width()):
            self._minuterie.start()
        return super().eventFilter(obj, ev)

    def _energie_active(self) -> bool:
        return getattr(self, "mode", "") == "energie"

    def _opts(self) -> dict:
        from ..reglages import lire_reglage
        if self._energie_active():
            return {**self.OPTIONS_ENERGIE, **(lire_reglage("impression_energie", {}) or {})}
        return {**self.OPTIONS_AFFICHES, **(lire_reglage("impression_affiches", {}) or {})}

    def _poser_options(self) -> None:
        o = self._opts()
        e = self._energie_active()
        modes = (("Taille réelle", "Avec marges") if e else ("2 par feuille", "1 par feuille"))
        for b, txt in zip(self.b_mode, modes):
            b.setText(txt)
        k = (1 if o["marges"] else 0) if e else (1 if o["par_feuille"] == 1 else 0)
        self.b_mode[k].setChecked(True)
        self.l_mode_aide.setText(
            "Taille réelle : collées en haut de la feuille.\nAvec marges : centrées, pour les imprimantes\n"
            "qui coupent les bords." if e else
            "2 par feuille : deux affiches côte à côte\n(A4 paysage).\n1 par feuille : une grande affiche par page.")
        libs = (("Code et nom sous l'étiquette", "texte"), ("Pointillés de coupe", "pointilles"),
                ("Étiquette nette EPREL si possible", "eprel")) if e else \
               (("Bandeau protection / garantie", "protection"), ("Pointillés de coupe", "pointilles"),
                ("Un PDF par produit", "un_par_produit"))
        self._cles_opt = [c for _, c in libs]
        for c, (lib, cle) in zip(self.c_opt, libs):
            c.blockSignals(True)
            c.setText(lib)
            c.setChecked(bool(o[cle]))
            c.blockSignals(False)
        self.b_imprimer.setText("🖨️  IMPRIMER LES ÉTIQUETTES" if e else "🖨️  IMPRIMER LES AFFICHES")
        self.b_imprimer.setObjectName("energie" if e else "modifier")
        self.b_imprimer.style().unpolish(self.b_imprimer)
        self.b_imprimer.style().polish(self.b_imprimer)
        self._maj_panneau()
        self._minuterie.start()

    def _options_changees(self) -> None:
        from ..reglages import enregistrer_reglage
        o = self._opts()
        k = self.groupe_modes.checkedId()
        if self._energie_active():
            o["marges"] = k == 1
        else:
            o["par_feuille"] = 1 if k == 1 else 2
        for c, cle in zip(self.c_opt, self._cles_opt):
            o[cle] = c.isChecked()
        enregistrer_reglage("impression_energie" if self._energie_active() else "impression_affiches", o)
        self._minuterie.start()

    def _codes_sortie(self) -> list[str]:
        return self._codes() if self._energie_active() else self._codes_affiches()

    def _maj_panneau(self) -> None:
        n = len(self._codes_sortie())
        quoi = "étiquette" if self._energie_active() else "affiche"
        self.b_export.setText(f"📄  EXPORTER EN PDF" + (f" ({n})" if n else ""))
        for b in (self.b_export, self.b_imprimer):
            b.setEnabled(n > 0)
        if not n:
            self.l_pages.setText(f"Coche des produits pour voir les {quoi}s.")

    def _etiquettes_doc(self, codes: list[str], apercu: bool):
        """(document, étiquettes trouvées, ratés). Aperçu : seulement les étiquettes déjà sur l'ordinateur."""
        o = self._opts()
        noms = {a["code"]: a["nom"] for a in self.articles}
        articles = {a["code"]: a for a in self.articles}
        trouvees, rates = [], []
        for c in codes:
            art = articles.get(c)
            try:
                if apercu:
                    f = None
                    if o["eprel"]:
                        from .. import eprel
                        info = eprel.memoire().get(c) or {}
                        num = info.get("choix") if info.get("choix") not in (None, "", "site") else info.get("numero")
                        if num and energie.fichier_eprel(num).is_file():
                            f = energie.fichier_eprel(num)
                    f = f or energie.fichier_local(c)
                    if f is None:
                        rates.append((c, "pas encore téléchargée"))
                        continue
                elif o["eprel"]:
                    f = energie.obtenir(self.cat.client, c, article=art)
                else:
                    f = energie.obtenir_image_site(self.cat.client, c)
                trouvees.append(energie.Etiquette(c, _nom_court(noms.get(c, c)), f, energie.format_de(art)))
            except energie.SansEtiquette as e:
                rates.append((c, str(e)))
            except Exception as e:
                rates.append((c, str(e).split(".")[0]))
        doc = energie.creer_pdf(trouvees, marges=o["marges"], texte=o["texte"], pointilles=o["pointilles"]) \
            if trouvees else None
        return doc, trouvees, rates

    def _affiches_doc(self, codes: list[str], apercu: bool = False):
        from pathlib import Path
        from .. import affiche
        o = self._opts()
        prets, rates = [], []
        for c in codes:
            try:
                if apercu:                    # aperçu : jamais d'Internet, rien dans l'historique
                    art = self.cat.base.article(c)
                    if not (art and art.get("photo") and Path(retrouver_photo(art["photo"])).is_file()):
                        rates.append((c, "photo pas encore téléchargée"))
                        continue
                    p = self.cat._obtenir_un(c).produit
                else:
                    p = getattr(self.cat.obtenir(c), "produit", None)
            except Exception as e:
                rates.append((c, str(e).split("\n")[0]))
                continue
            if p is not None and p.pret:
                prets.append(p)
            else:
                rates.append((c, "photo ou nom manquant : à compléter dans « Un produit »"))
        doc = affiche.pdf_affiches(prets, o["par_feuille"], o["pointilles"], o["protection"]) if prets else None
        return doc, prets, rates

    def _apercu(self) -> None:
        from PySide6.QtGui import QPixmap
        codes = self._codes_sortie()
        if not codes:
            self.l_apercu.setPixmap(QPixmap())
            self.l_apercu.setMinimumHeight(0)
            self.l_apercu.setText("")
            return
        try:
            if self._energie_active():
                doc, ok, rates = self._etiquettes_doc(codes, apercu=True)
                manque = sum(1 for _, r in rates if r == "pas encore téléchargée")
                n_txt = f"{len(ok)} étiquette{'s' if len(ok) > 1 else ''}"
                if manque:
                    n_txt += f"\n{manque} à télécharger au moment d'imprimer"
            else:
                doc, ok, rates = self._affiches_doc(codes[:12], apercu=True)
                par = self._opts()["par_feuille"]
                f = len(codes) if par == 1 else (len(codes) + 1) // 2
                n_txt = f"{len(codes)} affiche{'s' if len(codes) > 1 else ''} · {f} feuille{'s' if f > 1 else ''} A4"
            if doc is None:
                self.l_apercu.setPixmap(QPixmap())
                self.l_apercu.setMinimumHeight(0)
                self.l_apercu.setText("\nPas encore d'aperçu :\nles photos seront téléchargées\nau moment d'imprimer.")
                self.l_pages.setText(n_txt)
                return
            self.l_apercu.setText("")
            pm = self._feuilles(doc)
            self.l_apercu.setPixmap(pm)
            self.l_apercu.setMinimumHeight(pm.height())     # la barre de défilement = les feuilles, rien de plus
            if self._energie_active():
                n_txt += f" · {doc.page_count} feuille{'s' if doc.page_count > 1 else ''} A4"
            self.l_pages.setText(n_txt)
        except Exception as e:
            self.l_apercu.setPixmap(QPixmap())
            self.l_apercu.setMinimumHeight(0)
            self.l_apercu.setText(f"Aperçu impossible :\n{e}")

    def _feuilles(self, doc, maxi: int = 15):
        """Toutes les feuilles l'une sous l'autre, chacune avec son numéro :
        la barre de défilement correspond exactement aux feuilles."""
        from PySide6.QtGui import QColor, QPainter, QPixmap
        larg = max(160, self._zone_apercu.viewport().width() - 4)
        n = min(doc.page_count, maxi)
        images = []
        for i in range(n):
            dpi = int(max(18, min(80, larg / (doc[i].rect.width / 72))))
            pm = QPixmap()
            pm.loadFromData(doc[i].get_pixmap(dpi=dpi).tobytes("png"))
            images.append(pm)
        titre, ecart = 20, 10
        haut = sum(titre + im.height() + ecart for im in images) - ecart
        total = QPixmap(max(im.width() for im in images), haut)
        total.fill(QColor(0, 0, 0, 0))
        pt = QPainter(total)
        y = 0
        for i, im in enumerate(images):
            pt.setPen(QColor("#555"))
            txt = f"Feuille {i + 1} / {doc.page_count}"
            pt.drawText(0, y, total.width(), titre, Qt.AlignmentFlag.AlignCenter, txt)
            y += titre
            pt.setPen(QColor("#bbb"))
            x = (total.width() - im.width()) // 2
            pt.drawPixmap(x, y, im)
            pt.drawRect(x, y, im.width() - 1, im.height() - 1)
            y += im.height() + ecart
        pt.end()
        return total

    def _sortie(self, imprimer: bool) -> None:
        try:
            self._sortie_(imprimer)
        except Exception:
            _noter_erreur("Impression")

    def _sortie_(self, imprimer: bool) -> None:
        from datetime import datetime
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QDesktopServices
        from PySide6.QtWidgets import QApplication
        from .. import paths
        codes = self._codes_sortie()
        e = self._energie_active()
        quoi = "étiquettes énergie" if e else "affiches"
        if not codes or not self._confirmer_beaucoup(len(codes), quoi):
            return
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            doc, ok, rates = self._etiquettes_doc(codes, apercu=False) if e else self._affiches_doc(codes)
        finally:
            QApplication.restoreOverrideCursor()
        if doc is None:
            QMessageBox.information(self, "Dépôt Print", f"Aucune {quoi[:-1]} n'a pu être faite.\n\n"
                                    + "\n".join(f"{c} : " + r.replace(" (", "\n        (") for c, r in rates[:12]))
            return
        horo = datetime.now().strftime("%Y-%m-%d_%Hh%M")
        if imprimer:
            from . import impression
            try:
                impression.imprimer(self, doc, "Étiquettes énergie" if e else "Affiches")
            except Exception as ex:
                QMessageBox.critical(self, "Impression impossible", str(ex))
                return
            if not e:
                for p in ok:
                    self.cat.base.noter_affiche(p, "impression", "")
        else:
            try:
                if not e and self._opts()["un_par_produit"] and len(ok) > 1:
                    from .. import affiche
                    o = self._opts()
                    dest = None
                    for p in ok:
                        d1 = affiche.pdf_affiches([p], o["par_feuille"], o["pointilles"], o["protection"])
                        f = paths.output_dir() / self.fenetre.nom_fichier(p)
                        d1.save(f)
                        self.cat.base.noter_affiche(p, "PDF", str(f))
                        dest = f
                    QDesktopServices.openUrl(QUrl.fromLocalFile(str(dest.parent)))
                else:
                    if e:
                        nom = (f"Etiquette_energie_{ok[0].code}.pdf" if len(ok) == 1
                               else f"Etiquettes_energie_{horo}_{len(ok)}.pdf")
                    else:
                        nom = (self.fenetre.nom_fichier(ok[0]) if len(ok) == 1
                               else f"Affiches_{horo}_{len(ok)}_produits.pdf")
                    dest = paths.output_dir() / nom
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    doc.save(dest)
                    if not e:
                        for p in ok:
                            self.cat.base.noter_affiche(p, "PDF", str(dest))
                    QDesktopServices.openUrl(QUrl.fromLocalFile(str(dest)))
            except PermissionError:
                QMessageBox.warning(self, "Fichier ouvert", "Ce PDF est ouvert dans un autre programme.\n"
                                                            "Fermez-le puis réessayez.")
                return
        if not e:
            self.fenetre.rafraichir_historique()
        self._bilan(("✅ Envoyé à l'imprimante" if imprimer else "✅ PDF ouvert") + f" ({len(ok)})", rates)

    def _confirmer_beaucoup(self, n: int, quoi: str) -> bool:
        """Au-delà de 20 produits, on demande avant de lancer (ça peut prendre un moment)."""
        if n <= 20:
            return True
        r = QMessageBox.question(self, "Dépôt Print", f"Faire les {quoi} des {n} produits cochés ?\n"
                                 "(ça peut prendre un moment)")
        return r == QMessageBox.StandardButton.Yes

    def _bilan(self, titre: str, rates: list) -> None:
        if rates:
            QMessageBox.information(self, "Dépôt Print", titre + "\n\n"
                                    + f"Pas fait pour {len(rates)} produit{'s' if len(rates) > 1 else ''} :\n"
                                    # les précisions entre parenthèses : sur leur propre ligne
                                    + "\n".join(f"{c} : " + r.replace(" (", "\n        (") for c, r in rates[:12]))

    def etiquettes(self) -> None:
        try:
            self._etiquettes()
        except Exception:
            _noter_erreur("Étiquettes énergie")

    def _etiquettes(self) -> None:
        """« Étiquettes énergie » : le PDF des étiquettes des produits cochés, ouvert tout de suite."""
        codes = self._codes()
        if not codes or not self._confirmer_beaucoup(len(codes), "étiquettes énergie"):
            return
        from datetime import datetime
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QDesktopServices
        from PySide6.QtWidgets import QApplication, QProgressDialog
        from .. import paths
        noms = {a["code"]: a["nom"] for a in self.articles}
        articles = {a["code"]: a for a in self.articles}
        attente = QProgressDialog("Recherche des étiquettes énergie…", "Arrêter", 0, len(codes), self)
        attente.setWindowTitle("🍃 Étiquettes énergie")
        attente.setMinimumDuration(400)
        trouvees, rates = [], []
        for n, c in enumerate(codes):
            attente.setValue(n)
            QApplication.processEvents()
            if attente.wasCanceled():
                break
            try:
                f = energie.obtenir(self.cat.client, c, article=articles.get(c))
                trouvees.append(energie.Etiquette(c, _nom_court(noms.get(c, c)), f,
                                                  energie.format_de(articles.get(c))))
            except energie.SansEtiquette as e:
                rates.append((c, str(e)))
            except Exception as e:
                rates.append((c, str(e).split(".")[0]))
        attente.setValue(len(codes))
        if not trouvees:
            QMessageBox.information(self, "🍃 Étiquettes énergie", "Aucune étiquette énergie pour ces produits.\n"
                                    "(reconditionnés et modèles sortis avant juin 2025 n'en ont pas)\n\n"
                                    # les précisions entre parenthèses : sur leur propre ligne
                                    + "\n".join(f"{c} : " + r.replace(" (", "\n        (") for c, r in rates[:12]))
            return
        nom = (f"Etiquette_energie_{trouvees[0].code}.pdf" if len(trouvees) == 1
               else f"Etiquettes_energie_{datetime.now().strftime('%Y-%m-%d_%Hh%M')}_{len(trouvees)}.pdf")
        dest = paths.output_dir() / nom
        try:
            energie.creer_pdf(trouvees, dest)
        except PermissionError:
            QMessageBox.warning(self, "Fichier ouvert", "Ce PDF est ouvert dans un autre programme.\n"
                                                        "Fermez-le puis réessayez.")
            return
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(dest)))
        self._bilan(f"✅ PDF des étiquettes ouvert ({len(trouvees)})", rates)
        for r in range(self.table.rowCount()):           # met à jour la colonne 🍃
            it = self.table.item(r, 5)
            code = self.table.item(r, 2).data(Qt.ItemDataRole.UserRole)
            if it is not None and energie.fichier_local(code):
                it.setText("✔")
