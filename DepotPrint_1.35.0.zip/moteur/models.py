"""Structures de données partagées."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Cadrage:
    """Réglage de la photo dans sa zone (1.0 = remplit la zone)."""

    zoom: float = 1.0       # 0.5 à 1.3
    decal_x: float = 0.0    # -1 à 1 (fraction de la demi-largeur libre)
    decal_y: float = 0.0    # -1 à 1

    def est_defaut(self) -> bool:
        return self.zoom == 1.0 and self.decal_x == 0.0 and self.decal_y == 0.0


@dataclass
class Mentions:
    """Informations affichées en badges sur l'affiche."""

    reconditionne: bool = False      # bandeau vert « RECONDITIONNÉ · <état> »
    etat: str = ""                   # texte du site en majuscules, ex. « EXCELLENT ÉTAT »
    batterie_neuve: bool = False     # pastille « BATTERIE NEUVE »
    coloris: bool = False            # rond « PLUSIEURS COLORIS DISPONIBLES » (iPhone)
    protection: bool = True          # bandeau « PROTECTION CASSE · VOL · OXYDATION x€/MOIS »
    tarif_protection: float = 0      # 0 = automatique d'après le prix du site
    autres_coloris: list = field(default_factory=list)   # coloris trouvés sur le site (autres codes)
    variantes: list = field(default_factory=list)        # [["4G", ["Noir", "Bleu ciel"]], ["5G", [...]]]
    iphone: bool = False             # iPhone : rond « PLUSIEURS COLORIS » si couleurs non vérifiées
    boite: list = field(default_factory=lambda: [1])     # pictogrammes en orange (0 chargeur … 4 écran)
    boite_indique: bool = False      # le site indique-t-il le contenu de la boîte ?
    boite_manuel: bool = False       # corrigé à la main dans « Modifier » : jamais écrasé
    coloris_exclus: list = field(default_factory=list)   # couleurs décochées à la main : ["4G|Bleu clair", …]
    photo_couleur: str = ""          # photo d'une autre couleur choisie dans « Modifier » ('' = la sienne)
    coloris_ajoutes: list = field(default_factory=list)  # couleurs en réserve, absentes du site : ["5G|Vert"]
    afficher_code: bool = False      # « Réf. 10013681 » en petit en bas de l'affiche (choix dans « Modifier »)
    reseau: str = ""                 # « 4G » / « 5G » choisi dans « Modifier » ('' = automatique)

    def variantes_affichees(self) -> list:
        """Variantes du site sans les couleurs décochées à la main (groupes vides retirés)."""
        from .coloris import ajouter, filtrer
        return filtrer(ajouter(self.variantes, self.coloris_ajoutes), self.coloris_exclus)

    def resume(self, tarif=None) -> str:
        r = []
        if self.reconditionne:
            r.append("Reconditionné" + (f" · {self.etat.capitalize()}" if self.etat else ""))
        if self.batterie_neuve:
            r.append("Batterie neuve")
        if self.coloris:
            from .coloris import plusieurs, resume_variantes
            if plusieurs(self.variantes_affichees()):
                r.append("Coloris : " + resume_variantes(self.variantes_affichees()))
            else:
                r.append("Plusieurs coloris")
        if self.protection and tarif:
            r.append(f"Protection {tarif:g} €/mois" if isinstance(tarif, float) else f"Protection {tarif} €/mois")
        return " · ".join(r)


@dataclass
class Produit:
    code: str                        # toujours du texte (zéros initiaux conservés)
    nom_site: str = ""               # désignation exacte trouvée sur la source
    nom_affiche: str = ""            # nom imprimé sur l'affiche
    photo: str = ""                  # chemin local de la photo préparée
    source: str = ""                 # "electrodepot.fr", "catalogue CSV", "manuel"…
    url_fiche: str = ""
    verifie: bool = False            # le code a été vérifié sur la source
    avertissement: str = ""          # raison d'une correspondance incertaine
    cadrage: Cadrage = field(default_factory=Cadrage)
    mentions: Mentions = field(default_factory=Mentions)
    prix: float = 0.0                # prix du site : sert au tarif de protection, JAMAIS imprimé
    galerie: list[str] = field(default_factory=list)  # autres photos possibles (URL)
    maj: str = ""                    # date de dernière mise à jour
    # deux versions dans la même cloche (ex. état correct + excellent état) : UNE affiche pour les deux.
    # Jamais enregistré : chaque code garde ses propres mentions dans la base.
    version2: "Produit | None" = field(default=None, compare=False, repr=False)

    @property
    def pret(self) -> bool:
        """L'affiche peut-elle être générée ?"""
        return bool(self.nom_affiche.strip()) and bool(self.photo)


class ErreurRecherche(Exception):
    """Erreur affichable telle quelle à l'utilisateur."""


class Ambiguite(ErreurRecherche):
    def __init__(self, message: str, candidats: list[dict]):
        super().__init__(message)
        self.candidats = candidats
