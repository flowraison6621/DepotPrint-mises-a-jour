"""Base locale SQLite : produits mémorisés (utilisables hors ligne) et historique."""

from __future__ import annotations

import json
import sqlite3
import threading
from datetime import datetime
from pathlib import Path

from .models import Cadrage, Mentions, Produit

_SCHEMA = """
CREATE TABLE IF NOT EXISTS produits (
    code TEXT PRIMARY KEY,
    nom_site TEXT NOT NULL DEFAULT '',
    nom_affiche TEXT NOT NULL DEFAULT '',
    photo TEXT NOT NULL DEFAULT '',
    source TEXT NOT NULL DEFAULT '',
    url_fiche TEXT NOT NULL DEFAULT '',
    verifie INTEGER NOT NULL DEFAULT 0,
    avertissement TEXT NOT NULL DEFAULT '',
    cadrage TEXT NOT NULL DEFAULT '{}',
    galerie TEXT NOT NULL DEFAULT '[]',
    maj TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS historique (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT NOT NULL,
    action TEXT NOT NULL,
    fichier TEXT NOT NULL DEFAULT '',
    date TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_hist_date ON historique(date);
CREATE TABLE IF NOT EXISTS catalogue (
    code TEXT PRIMARY KEY,
    nom TEXT NOT NULL,
    coloris TEXT NOT NULL DEFAULT '',
    prix REAL NOT NULL DEFAULT 0,
    url_fiche TEXT NOT NULL DEFAULT '',
    url_image TEXT NOT NULL DEFAULT '',
    rayon TEXT NOT NULL DEFAULT '',
    attributs TEXT NOT NULL DEFAULT '{}',
    variantes TEXT NOT NULL DEFAULT '[]',
    photo TEXT NOT NULL DEFAULT '',
    maj TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS paires (
    code1 TEXT NOT NULL, code2 TEXT NOT NULL, date TEXT NOT NULL, PRIMARY KEY (code1, code2)
);
CREATE TABLE IF NOT EXISTS seuls (code TEXT PRIMARY KEY, date TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS reglages_kv (cle TEXT PRIMARY KEY, valeur TEXT NOT NULL);
"""


def maintenant() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


class Base:
    def __init__(self, chemin: Path) -> None:
        self.chemin = chemin
        self._verrou = threading.Lock()
        self._cx = sqlite3.connect(str(chemin), check_same_thread=False)
        self._cx.row_factory = sqlite3.Row
        self._cx.executescript(_SCHEMA)
        # mise à niveau d'une base créée par une version précédente
        cols = {r[1] for r in self._cx.execute("PRAGMA table_info(produits)")}
        if "mentions" not in cols:
            self._cx.execute("ALTER TABLE produits ADD COLUMN mentions TEXT NOT NULL DEFAULT ''")
        cat_cols = {r[1] for r in self._cx.execute("PRAGMA table_info(catalogue)")}
        if "boite" not in cat_cols:
            self._cx.execute("ALTER TABLE catalogue ADD COLUMN boite TEXT NOT NULL DEFAULT ''")
        if "retire" not in cat_cols:     # date à laquelle le produit a disparu du site ('' = en ligne)
            self._cx.execute("ALTER TABLE catalogue ADD COLUMN retire TEXT NOT NULL DEFAULT ''")
        if "prix" not in cols:
            self._cx.execute("ALTER TABLE produits ADD COLUMN prix REAL NOT NULL DEFAULT 0")
        self._cx.commit()

    # -- produits ---------------------------------------------------------------
    def produit(self, code: str) -> Produit | None:
        with self._verrou:
            r = self._cx.execute("SELECT * FROM produits WHERE code = ?", (code,)).fetchone()
        return _vers_produit(r) if r else None

    def enregistrer(self, p: Produit) -> None:
        p.maj = maintenant()
        c = p.cadrage
        with self._verrou:
            self._cx.execute(
                """INSERT INTO produits (code, nom_site, nom_affiche, photo, source, url_fiche,
                       verifie, avertissement, cadrage, galerie, maj, mentions, prix)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
                   ON CONFLICT(code) DO UPDATE SET
                       nom_site=excluded.nom_site, nom_affiche=excluded.nom_affiche,
                       photo=excluded.photo, source=excluded.source, url_fiche=excluded.url_fiche,
                       verifie=excluded.verifie, avertissement=excluded.avertissement,
                       cadrage=excluded.cadrage, galerie=excluded.galerie, maj=excluded.maj,
                       mentions=excluded.mentions, prix=excluded.prix""",
                (p.code, p.nom_site, p.nom_affiche, p.photo, p.source, p.url_fiche,
                 int(p.verifie), p.avertissement,
                 json.dumps({"zoom": c.zoom, "decal_x": c.decal_x, "decal_y": c.decal_y}),
                 json.dumps(p.galerie), p.maj,
                 json.dumps({"reconditionne": p.mentions.reconditionne, "etat": p.mentions.etat,
                             "batterie_neuve": p.mentions.batterie_neuve, "coloris": p.mentions.coloris,
                             "protection": p.mentions.protection,
                             "tarif_protection": p.mentions.tarif_protection,
                             "autres_coloris": list(p.mentions.autres_coloris),
                             "variantes": list(p.mentions.variantes), "iphone": p.mentions.iphone,
                             "boite": list(p.mentions.boite), "boite_indique": p.mentions.boite_indique,
                             "boite_manuel": p.mentions.boite_manuel,
                             "coloris_exclus": list(p.mentions.coloris_exclus),
                             "photo_couleur": p.mentions.photo_couleur,
                             "coloris_ajoutes": list(p.mentions.coloris_ajoutes),
                             "afficher_code": p.mentions.afficher_code,
                             "reseau": p.mentions.reseau}),
                 float(p.prix or 0)),
            )
            self._cx.commit()

    def supprimer(self, code: str) -> None:
        with self._verrou:
            self._cx.execute("DELETE FROM produits WHERE code = ?", (code,))
            self._cx.commit()

    def tous(self, filtre: str = "") -> list[Produit]:
        q = "SELECT * FROM produits"
        args: tuple = ()
        if filtre:
            q += " WHERE code LIKE ? OR nom_affiche LIKE ? OR nom_site LIKE ?"
            f = f"%{filtre}%"
            args = (f, f, f)
        q += " ORDER BY maj DESC"
        with self._verrou:
            rows = self._cx.execute(q, args).fetchall()
        return [_vers_produit(r) for r in rows]

    # -- catalogue hors ligne ---------------------------------------------------------
    def article(self, code: str) -> dict | None:
        with self._verrou:
            r = self._cx.execute("SELECT * FROM catalogue WHERE code = ?", (code,)).fetchone()
        if not r:
            return None
        d = dict(r)
        d["attributs"] = json.loads(d["attributs"] or "{}")
        d["variantes"] = json.loads(d["variantes"] or "[]")
        d["boite"] = json.loads(d.get("boite") or "{}")
        return d

    def articles(self) -> dict[str, dict]:
        with self._verrou:
            rows = self._cx.execute("SELECT code, nom, prix, photo, boite, retire FROM catalogue").fetchall()
        return {r["code"]: dict(r) for r in rows}

    def remplacer_catalogue(self, articles: list[dict], rayons: list[str], date_retrait: str = "") -> list[str]:
        """Met à jour les articles des rayons lus. Les produits qui ont disparu du site ne
        sont PAS supprimés : ils restent dans le catalogue, marqués « retiré du site ».
        Renvoie les codes nouvellement retirés."""
        nouveaux = {a["code"] for a in articles}
        date_retrait = date_retrait or datetime.now().strftime("%d/%m/%Y")
        with self._verrou:
            cx = self._cx
            retires = []
            for r in rayons:
                for row in cx.execute("SELECT code FROM catalogue WHERE rayon = ? AND retire = ''", (r,)).fetchall():
                    if row["code"] not in nouveaux:
                        retires.append(row["code"])
            cx.executemany("UPDATE catalogue SET retire = ? WHERE code = ?", [(date_retrait, c) for c in retires])
            cx.executemany(
                """INSERT OR REPLACE INTO catalogue (code, nom, coloris, prix, url_fiche, url_image, rayon,
                       attributs, variantes, photo, maj, boite, retire) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,'')""",
                [(a["code"], a["nom"], a.get("coloris", ""), float(a.get("prix") or 0), a.get("url_fiche", ""),
                  a.get("url_image", ""), a.get("rayon", ""), json.dumps(a.get("attributs") or {}, ensure_ascii=False),
                  json.dumps(a.get("variantes") or [], ensure_ascii=False), a.get("photo", ""), maintenant(),
                  json.dumps(a.get("boite") or {}, ensure_ascii=False))
                 for a in articles])
            cx.commit()
        return retires

    def tous_articles(self) -> list[dict]:
        """Tout le catalogue, produits retirés du site compris (avec la date de retrait)."""
        with self._verrou:
            rows = self._cx.execute("SELECT code, nom, coloris, photo, retire FROM catalogue").fetchall()
        return [dict(r) for r in rows]

    def catalogue_complet(self) -> list[dict]:
        """Tout le catalogue hors ligne, pour le parcourir par catégorie."""
        with self._verrou:
            rows = self._cx.execute("SELECT code, nom, coloris, prix, rayon, attributs, photo, retire "
                                    "FROM catalogue ORDER BY nom").fetchall()
        out = []
        for r in rows:
            d = dict(r)
            try:
                d["attributs"] = json.loads(d["attributs"] or "{}")
            except ValueError:
                d["attributs"] = {}
            out.append(d)
        return out

    def articles_avec_photo(self) -> list[dict]:
        """Articles en ligne, avec leur photo : sert à choisir la couleur de la photo."""
        with self._verrou:
            rows = self._cx.execute("SELECT code, nom, coloris, photo FROM catalogue WHERE retire = ''").fetchall()
        return [dict(r) for r in rows]

    def articles_pour_coloris(self) -> list[dict]:
        with self._verrou:
            # les produits retirés du site ne comptent pas dans les coloris disponibles
            rows = self._cx.execute("SELECT code, nom, coloris FROM catalogue WHERE retire = ''").fetchall()
        return [{"refCode": r["code"], "name": r["nom"], "coloris": r["coloris"]} for r in rows]

    def nb_articles(self) -> int:
        with self._verrou:
            return self._cx.execute("SELECT COUNT(*) FROM catalogue").fetchone()[0]

    def nb_retires(self) -> int:
        with self._verrou:
            return self._cx.execute("SELECT COUNT(*) FROM catalogue WHERE retire != ''").fetchone()[0]

    def valeur(self, cle: str, defaut: str = "") -> str:
        with self._verrou:
            r = self._cx.execute("SELECT valeur FROM reglages_kv WHERE cle = ?", (cle,)).fetchone()
        return r[0] if r else defaut

    def ecrire_valeur(self, cle: str, valeur: str) -> None:
        with self._verrou:
            self._cx.execute("INSERT OR REPLACE INTO reglages_kv (cle, valeur) VALUES (?, ?)", (cle, valeur))
            self._cx.commit()

    # -- historique --------------------------------------------------------------
    # -- historique des affiches : produit seul ou deux produits (une seule affiche) -------------
    def noter_paire(self, code1: str, code2: str) -> None:
        with self._verrou:
            self._cx.execute("DELETE FROM paires WHERE (code1=? AND code2=?) OR (code1=? AND code2=?)",
                             (code1, code2, code2, code1))
            self._cx.execute("INSERT INTO paires (code1, code2, date) VALUES (?,?,?)", (code1, code2, maintenant()))
            self._cx.commit()

    def noter_seul(self, code: str) -> None:
        with self._verrou:
            self._cx.execute("INSERT OR REPLACE INTO seuls (code, date) VALUES (?,?)", (code, maintenant()))
            self._cx.commit()

    def paires(self) -> list[dict]:
        with self._verrou:
            rows = self._cx.execute("SELECT code1, code2, date FROM paires ORDER BY date DESC").fetchall()
        return [dict(r) for r in rows]

    def codes_seuls(self) -> set[str]:
        with self._verrou:
            return {r[0] for r in self._cx.execute("SELECT code FROM seuls")}

    def retirer_paire(self, code1: str, code2: str) -> None:
        """Retire l'affiche « deux produits » ; un produit qui n'existait que dans cette paire disparaît aussi."""
        with self._verrou:
            self._cx.execute("DELETE FROM paires WHERE code1=? AND code2=?", (code1, code2))
            self._cx.commit()
        restants = {c for p in self.paires() for c in (p["code1"], p["code2"])}
        seuls = self.codes_seuls()
        for c in (code1, code2):
            if c not in seuls and c not in restants:
                self.supprimer(c)

    def retirer_seul(self, code: str) -> None:
        """Retire le produit seul ; s'il sert encore dans une paire, il reste pour elle."""
        dans_paire = any(code in (p["code1"], p["code2"]) for p in self.paires())
        with self._verrou:
            self._cx.execute("DELETE FROM seuls WHERE code=?", (code,))
            self._cx.commit()
        if not dans_paire:
            self.supprimer(code)

    # -- affiches réellement sorties (PDF ou impression) : ce que montre l'historique --------------
    def noter_affiche(self, p, action: str, fichier: str = "") -> None:
        """PDF ou impression d'une affiche ; deux produits : clé « code1 + code2 »."""
        if getattr(p, "version2", None) is not None:
            self.noter_paire(p.code, p.version2.code)
            self.noter(f"{p.code} + {p.version2.code}", action, fichier)
        else:
            self.noter(p.code, action, fichier)

    def impressions(self) -> dict[str, str]:
        """{clé : date de la dernière sortie (PDF ou impression)} ; clé = code ou « code1 + code2 »."""
        with self._verrou:
            rows = self._cx.execute("SELECT code, MAX(date) FROM historique "
                                    "WHERE action IN ('PDF', 'impression') GROUP BY code").fetchall()
        return {r[0]: r[1] for r in rows}

    def oublier_affiche(self, cle: str) -> None:
        """Retire une affiche de l'historique (les produits restent connus, les PDF ne sont pas touchés)."""
        cles = [cle]
        if "+" in cle:
            a, b = [x.strip() for x in cle.split("+")]
            cles.append(f"{b} + {a}")
        with self._verrou:
            self._cx.executemany("DELETE FROM historique WHERE code = ? AND action IN ('PDF', 'impression')",
                                 [(c,) for c in cles])
            self._cx.commit()

    def noter(self, code: str, action: str, fichier: str = "") -> None:
        with self._verrou:
            self._cx.execute(
                "INSERT INTO historique (code, action, fichier, date) VALUES (?,?,?,?)",
                (code, action, fichier, maintenant()),
            )
            self._cx.commit()

    def historique(self, limite: int = 300) -> list[dict]:
        with self._verrou:
            rows = self._cx.execute(
                """SELECT h.code, h.action, h.fichier, h.date, p.nom_affiche
                   FROM historique h LEFT JOIN produits p ON p.code = h.code
                   ORDER BY h.id DESC LIMIT ?""", (limite,),
            ).fetchall()
        return [dict(r) for r in rows]


def _vers_produit(r: sqlite3.Row) -> Produit:
    try:
        c = json.loads(r["cadrage"] or "{}")
    except ValueError:
        c = {}
    try:
        g = json.loads(r["galerie"] or "[]")
    except ValueError:
        g = []
    brut = r["mentions"] if "mentions" in r.keys() else ""
    nom_affiche = r["nom_affiche"]
    if brut:
        try:
            mm = json.loads(brut)
        except ValueError:
            mm = {}
        mentions = Mentions(bool(mm.get("reconditionne")), str(mm.get("etat", "")),
                            bool(mm.get("batterie_neuve")), bool(mm.get("coloris")),
                            bool(mm.get("protection", True)), float(mm.get("tarif_protection", 0) or 0),
                            list(mm.get("autres_coloris") or []), list(mm.get("variantes") or []),
                            bool(mm.get("iphone", "iphone" in (r["nom_site"] or "").lower())),
                            list(mm.get("boite", [1])), bool(mm.get("boite_indique", False)),
                            bool(mm.get("boite_manuel", False)), list(mm.get("coloris_exclus") or []),
                            str(mm.get("photo_couleur") or ""), list(mm.get("coloris_ajoutes") or []),
                            bool(mm.get("afficher_code", False)), str(mm.get("reseau") or ""))
    else:
        # produit enregistré par une version précédente : mentions et nom recalculés
        from .noms import detecter_mentions, nom_court
        mentions = detecter_mentions(r["nom_site"])
        if r["nom_site"]:
            nom_affiche = nom_court(r["nom_site"])
    from .paths import retrouver_photo
    return Produit(
        mentions=mentions,
        prix=float(r["prix"]) if "prix" in r.keys() and r["prix"] else 0.0,
        code=r["code"], nom_site=r["nom_site"], nom_affiche=nom_affiche, photo=retrouver_photo(r["photo"]),
        source=r["source"], url_fiche=r["url_fiche"], verifie=bool(r["verifie"]),
        avertissement=r["avertissement"],
        cadrage=Cadrage(float(c.get("zoom", 1.0)), float(c.get("decal_x", 0.0)), float(c.get("decal_y", 0.0))),
        galerie=list(g), maj=r["maj"],
    )
