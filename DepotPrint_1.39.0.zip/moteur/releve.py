"""Relevé des quantités : fiches A4 à remplir au stylo en rayon.

Une ligne par produit, dans l'ordre physique du rayon (sections : meuble, broche…),
avec une case QUANTITÉ vide. Jamais de stock théorique pré-rempli.

Code-barres : on n'invente jamais d'EAN. Faute de vrai code-barres produit dans le
catalogue, on encode en Code 128 EXACTEMENT la référence Electro Dépôt (texte en clair dessous).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from pathlib import Path

# -- Code 128 (jeux B et C), sans dépendance externe ------------------------------------------
_MOTIFS = [
    "212222", "222122", "222221", "121223", "121322", "131222", "122213", "122312", "132212", "221213",
    "221312", "231212", "112232", "122132", "122231", "113222", "123122", "123221", "223211", "221132",
    "221231", "213212", "223112", "312131", "311222", "321122", "321221", "312212", "322112", "322211",
    "212123", "212321", "232121", "111323", "131123", "131321", "112313", "132113", "132311", "211313",
    "231113", "231311", "112133", "112331", "132131", "113123", "113321", "133121", "313121", "211331",
    "231131", "213113", "213311", "213131", "311123", "311321", "331121", "312113", "312311", "332111",
    "314111", "221411", "431111", "111224", "111422", "121124", "121421", "141122", "141221", "112214",
    "112412", "122114", "122411", "142112", "142211", "241211", "221114", "413111", "241112", "134111",
    "111242", "121142", "121241", "114212", "124112", "124211", "411212", "421112", "421211", "212141",
    "214121", "412121", "111143", "111341", "131141", "114113", "114311", "411113", "411311", "113141",
    "114131", "311141", "411131", "211412", "211214", "211232", "2331112",
]
START_B, START_C, CODE_B, CODE_C, STOP = 104, 105, 100, 99, 106


def code128_valeurs(texte: str) -> list[int]:
    """Valeurs Code 128 (avec départ, somme de contrôle et arrêt). Chiffres par paires en jeu C."""
    if not texte or any(not (32 <= ord(c) <= 126) for c in texte):
        raise ValueError(f"référence non encodable : {texte!r}")
    vals: list[int] = []
    i, jeu = 0, None
    while i < len(texte):
        n = 0
        while i + n < len(texte) and texte[i + n].isdigit():
            n += 1
        if n >= 4 or (n >= 2 and n == len(texte) - i and jeu == "C"):
            if n % 2:                                   # nombre impair de chiffres : le 1er en jeu B
                if jeu != "B":
                    vals.append(START_B if not vals else CODE_B)
                    jeu = "B"
                vals.append(ord(texte[i]) - 32)
                i += 1
                n -= 1
            if jeu != "C":
                vals.append(START_C if not vals else CODE_C)
                jeu = "C"
            for k in range(0, n, 2):
                vals.append(int(texte[i + k:i + k + 2]))
            i += n
        else:
            if jeu != "B":
                vals.append(START_B if not vals else CODE_B)
                jeu = "B"
            vals.append(ord(texte[i]) - 32)
            i += 1
    somme = vals[0] + sum(v * k for k, v in enumerate(vals[1:], 1))
    return vals + [somme % 103, STOP]


def code128_barres(texte: str) -> list[int]:
    """Largeurs successives (barre, espace, barre…) en modules, zones blanches non comprises."""
    return [int(c) for v in code128_valeurs(texte) for c in _MOTIFS[v]]


def dessiner_code128(page, x: float, y: float, h: float, texte: str, module: float) -> float:
    """Dessine le code à (x, y), hauteur h ; renvoie sa largeur (pt)."""
    import pymupdf
    cx = x
    forme = page.new_shape()
    for k, larg in enumerate(code128_barres(texte)):
        if k % 2 == 0:
            forme.draw_rect(pymupdf.Rect(cx, y, cx + larg * module, y + h))
        cx += larg * module
    forme.finish(color=None, fill=(0, 0, 0), width=0)
    forme.commit()
    return cx - x


# -- données d'un relevé -----------------------------------------------------------------------
@dataclass
class Ligne:
    code: str
    nom: str
    photo: str = ""
    section: str = ""          # meuble / tablette / broche : un intertitre quand elle change
    ean: str = ""              # vrai code-barres produit, seulement s'il est connu


@dataclass
class Options:
    mode: str = "standard"     # compact / standard / illustre
    paysage: bool = False
    photos: bool = True        # mode illustré seulement
    codes_barres: bool = True
    noir_blanc: bool = False
    hauteur_mm: float = 0      # 0 : selon le mode
    titre: str = ""
    employe: str = ""
    jour: date = field(default_factory=date.today)


HAUTEURS = {"compact": 9.0, "standard": 15.0, "illustre": 19.0}


def creer_pdf(lignes: list[Ligne], opt: Options, dest: Path | None = None):
    import pymupdf
    from .affiche import police
    mm = 72 / 25.4
    W, H = ((297, 210) if opt.paysage else (210, 297))
    W, H = W * mm, H * mm
    marge = 10 * mm
    f = police()
    noir = (0, 0, 0)
    accent = noir if opt.noir_blanc else (0.95, 0.55, 0.0)
    gris = (0.45, 0.45, 0.45)
    fond_titre = (0.92, 0.92, 0.92) if opt.noir_blanc else (1.0, 0.95, 0.85)
    h_ligne = (opt.hauteur_mm or HAUTEURS.get(opt.mode, 15.0)) * mm
    photos = opt.mode == "illustre" and opt.photos
    codes = opt.codes_barres
    # colonnes (de droite à gauche : quantité, code-barres, puis nom extensible)
    l_qte = (22 if opt.mode == "compact" else 32) * mm
    l_cb = (38 if opt.mode == "compact" else 46) * mm if codes else 0
    l_ref = 22 * mm
    l_photo = (h_ligne - 2 * mm) + 2 * mm if photos else 0
    x0 = marge
    x_photo = x0
    x_ref = x_photo + l_photo
    x_nom = x_ref + l_ref
    x_qte = W - marge - l_qte
    x_cb = x_qte - l_cb
    l_nom = x_cb - x_nom - 2 * mm

    doc = pymupdf.open()
    pages: list = []

    def texte(pg, x, y, s, t, coul=noir, largeur=None):
        if largeur:
            while f.text_length(s, t) > largeur and t > 5.5:
                t -= 0.25
            while f.text_length(s, t) > largeur and len(s) > 4:
                s = s[:-2].rstrip() + "…"
        tw = pymupdf.TextWriter(pg.rect, color=coul)
        tw.append((x, y), s, font=f, fontsize=t)
        tw.write_text(pg)

    def nouvelle_page():
        pg = doc.new_page(width=W, height=H)
        pages.append(pg)
        y = marge
        texte(pg, x0, y + 13, "DÉPÔT PRINT · RELEVÉ DES QUANTITÉS", 13, accent)
        texte(pg, x0, y + 28, opt.titre or "Relevé", 15)
        info = f"Date : {opt.jour:%d/%m/%Y}" + (f"     Employé : {opt.employe}" if opt.employe
                                                 else "     Employé : ..........................")
        texte(pg, W - marge - f.text_length(info, 9.5), y + 13, info, 9.5, gris)
        y += 36
        pg.draw_rect(pymupdf.Rect(x0, y, W - marge, y + 7 * mm), color=None, fill=fond_titre)
        yt = y + 7 * mm - 2.2 * mm
        if photos:
            texte(pg, x_photo + 1 * mm, yt, "Photo", 8, gris)
        texte(pg, x_ref + 1 * mm, yt, "Réf.", 8, gris)
        texte(pg, x_nom + 1 * mm, yt, "Produit", 8, gris)
        if codes:
            texte(pg, x_cb + 1 * mm, yt, "Code-barres", 8, gris)
        texte(pg, x_qte + (l_qte - f.text_length("QUANTITÉ", 9)) / 2, yt, "QUANTITÉ", 9, noir)
        return pg, y + 7 * mm

    pg, y = nouvelle_page()
    bas = H - marge - 6 * mm
    section = None
    for ln in lignes:
        if ln.section and ln.section != section:
            if y + 7 * mm + h_ligne > bas:
                pg, y = nouvelle_page()
            section = ln.section
            texte(pg, x0 + 1 * mm, y + 5.2 * mm, "▸ " + section, 10.5, accent)
            pg.draw_line((x0, y + 7 * mm), (W - marge, y + 7 * mm), color=accent, width=0.8)
            y += 7 * mm
        if y + h_ligne > bas:
            pg, y = nouvelle_page()
            if section:
                texte(pg, x0 + 1 * mm, y + 5.2 * mm, "▸ " + section + " (suite)", 10.5, accent)
                y += 7 * mm
        milieu = y + h_ligne / 2
        if photos and ln.photo and Path(ln.photo).is_file():
            c = h_ligne - 2 * mm
            try:
                pg.insert_image(pymupdf.Rect(x_photo + 1 * mm, y + 1 * mm, x_photo + 1 * mm + c, y + 1 * mm + c),
                                filename=ln.photo, keep_proportion=True)
            except Exception:
                pass
        texte(pg, x_ref + 1 * mm, milieu + 3.5, ln.code, 10 if opt.mode != "compact" else 9)
        t_nom = 10 if opt.mode != "compact" else 8.5
        if f.text_length(ln.nom, t_nom) <= l_nom or opt.mode == "compact":
            texte(pg, x_nom + 1 * mm, milieu + 3.5, ln.nom, t_nom, noir, l_nom)
        else:                                   # nom long : sur deux lignes plutôt qu'en tout petit
            t_nom = 9.5
            mots, l1 = ln.nom.split(), ""
            while mots and f.text_length((l1 + " " + mots[0]).strip(), t_nom) <= l_nom:
                l1 = (l1 + " " + mots.pop(0)).strip()
            if len(mots) == 1 and " " in l1:     # jamais un mot seul sur la 2e ligne
                l1, dernier = l1.rsplit(" ", 1)
                mots.insert(0, dernier)
            texte(pg, x_nom + 1 * mm, milieu - 1.5, l1, t_nom, noir, l_nom)
            texte(pg, x_nom + 1 * mm, milieu + 9.5, " ".join(mots), t_nom, noir, l_nom)
        if codes:
            valeur = ln.ean or ln.code
            hb = min(h_ligne - (5 if opt.mode == "compact" else 7) * mm, 12 * mm)
            nb = len(code128_barres(valeur)) and sum(code128_barres(valeur)) + 20     # + zones blanches
            module = min(0.38 * mm, (l_cb - 2 * mm) / nb)
            larg = sum(code128_barres(valeur)) * module
            xb = x_cb + (l_cb - larg) / 2
            yb = y + 1.2 * mm
            dessiner_code128(pg, xb, yb, hb, valeur, module)
            t = 6.5
            texte(pg, x_cb + (l_cb - f.text_length(valeur, t)) / 2, yb + hb + t + 0.3, valeur, t, gris)
        pg.draw_rect(pymupdf.Rect(x_qte + 1.5 * mm, y + 1.2 * mm, W - marge - 1.5 * mm, y + h_ligne - 1.2 * mm),
                     color=noir, width=1.1)
        pg.draw_line((x0, y + h_ligne), (W - marge, y + h_ligne), color=(0.75, 0.75, 0.75), width=0.4)
        y += h_ligne
    n = doc.page_count
    for k, p in enumerate(doc, 1):              # pages relues dans le document (références à jour)
        s = f"Page {k} / {n}"
        texte(p, W - marge - f.text_length(s, 8), H - marge + 2, s, 8, gris)
        texte(p, x0, H - marge + 2, f"{len(lignes)} références · quantités présentes en rayon, à écrire au stylo", 8, gris)
    if dest is not None:
        dest.parent.mkdir(parents=True, exist_ok=True)
        doc.save(dest)
    return doc


# -- sous-catégories du stockage (ordre du rayon demandé) -------------------------------------
import re as _re

SOUS_CATEGORIES = ["HDD", "SSD interne", "SSD externe", "M.2 interne", "Clé USB", "Micro SD"]


CATS_APPLE = ["Chargeurs", "Câbles et adaptateurs", "Écouteurs", "AirTag", "Apple Pencil", "Apple Watch",
              "Protections", "Claviers et souris", "Autres"]


def categorie_apple(nom: str) -> str:
    n = (nom or "").lower()
    if _re.search(r"airpods|earpods|[ée]couteur|casque|beats", n):
        return "Écouteurs"
    if "airtag" in n:
        return "AirTag"
    if "pencil" in n:
        return "Apple Pencil"
    if _re.search(r"bracelet|\bwatch\b", n):
        return "Apple Watch"
    if _re.search(r"coque|[ée]tui|protection|housse|film", n):
        return "Protections"
    if _re.match(r"\s*c[âa]ble", n):
        return "Câbles et adaptateurs"
    if _re.search(r"chargeur|secteur|magsafe|alimentation", n):
        return "Chargeurs"
    if _re.search(r"c[âa]ble|adaptateur", n):
        return "Câbles et adaptateurs"
    if _re.search(r"clavier|keyboard|souris|mouse|trackpad", n):
        return "Claviers et souris"
    return "Autres"


def categories(rayon: str = "") -> list[str]:
    """Catégories d'une liste, dans l'ordre du rayon."""
    return CATS_APPLE if rayon == "accessoires_apple" else SOUS_CATEGORIES


def sous_categorie(nom: str, rayon: str = "") -> str:
    """Rangement d'un produit d'après son nom sur le site ('' : non classé)."""
    if rayon == "accessoires_apple":
        return categorie_apple(nom)
    n = (nom or "").lower()
    if _re.search(r"micro\s*-?\s*sd", n):
        return "Micro SD"
    if _re.search(r"\bcl[ée]s?\b", n):              # clé, clés (packs de clés USB), cle
        return "Clé USB"
    if _re.search(r"\bm\.?2\b|nvme", n):
        return "M.2 interne"
    if "ssd" in n:
        return "SSD externe" if _re.search(r"externe|portable|nomade", n) else "SSD interne"
    if _re.search(r"disque dur|\bhdd\b", n):
        return "HDD"
    return ""


def capacite_go(nom: str) -> float:
    """« 128 Go » -> 128 ; « 1 To » -> 1000 ; sans capacité : en dernier."""
    for m in _re.finditer(r"(\d+(?:[.,]\d+)?)\s*(go|gb|to|tb|g|t)\b", (nom or "").lower()):
        v = float(m.group(1).replace(",", "."))
        if m.group(2) == "g" and v < 8:            # « 4G », « 5G » : le réseau, pas une capacité
            continue
        return v * 1000 if m.group(2) in ("to", "tb", "t") else v
    return float("inf")


def rang(nom: str, rayon: str = "") -> tuple:
    """Ordre du rayon : catégorie (HDD, SSD interne… ou Chargeurs, Câbles…), puis capacité croissante."""
    sc, cats = sous_categorie(nom, rayon), categories(rayon)
    return (cats.index(sc) if sc in cats else len(cats), capacite_go(nom), nom.lower())


# -- listes de relevé enregistrées --------------------------------------------------------------
import json as _json

LISTES_DEFAUT = [
    {"nom": "Stockage", "emoji": "💾", "rayons": ["stockage"], "decoches": []},
    {"nom": "Téléphones senior", "emoji": "☎️", "rayons": ["mobiles"], "decoches": []},
    {"nom": "Accessoires Apple", "emoji": "🍎", "rayons": ["accessoires_apple"], "decoches": []},
]
OPTIONS_DEFAUT = {"mode": "illustre", "photos": True, "codes_barres": True, "noir_blanc": False,
                  "paysage": False, "hauteur_mm": 0, "employe": ""}


def _fichier() -> Path:
    from . import paths
    return paths.data_dir() / "releves.json"


def charger_listes() -> dict:
    """{'listes': [...], 'options': {...}} ; crée Stockage et Téléphones senior la première fois."""
    try:
        d = _json.loads(_fichier().read_text(encoding="utf-8"))
        if not isinstance(d.get("listes"), list):
            raise ValueError
    except (OSError, ValueError):
        d = {"listes": [dict(x, decoches=[]) for x in LISTES_DEFAUT]}
    d["options"] = {**OPTIONS_DEFAUT, **(d.get("options") or {})}
    # liste « Accessoires Apple » ajoutée une fois aux listes déjà enregistrées (pas remise si on l'efface)
    if not d.get("apple_ajoutee"):
        if not any("accessoires_apple" in (li.get("rayons") or []) for li in d["listes"]):
            d["listes"].append(dict(LISTES_DEFAUT[2], decoches=[]))
        d["apple_ajoutee"] = True
    # une seule sélection pour toutes les listes ; au départ, rien n'est coché
    if not isinstance(d.get("selection"), list):
        d["selection"] = []
    return d


def enregistrer_listes(d: dict) -> None:
    f = _fichier()
    f.parent.mkdir(parents=True, exist_ok=True)
    tmp = f.with_suffix(".tmp")
    tmp.write_text(_json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(f)


def produits_de(liste: dict, catalogue: list[dict]) -> list[dict]:
    """Produits du catalogue pour cette liste (rayons choisis, encore sur le site), dans l'ordre du rayon."""
    rayons = set(liste.get("rayons") or [])
    vus, res = set(), []
    for a in catalogue:
        if a.get("rayon") in rayons and not a.get("retire") and a["code"] not in vus:
            vus.add(a["code"])
            res.append(a)
    return sorted(res, key=lambda a: rang(a.get("nom") or "", a.get("rayon") or ""))
