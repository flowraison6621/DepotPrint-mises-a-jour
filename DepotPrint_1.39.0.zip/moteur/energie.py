"""Étiquettes énergie européennes (smartphones et tablettes, règlement UE 2023/1669).

L'étiquette OFFICIELLE est l'image publiée par le site Electro Dépôt pour chaque produit :
https://www.electrodepot.fr/media/catalog/product/E<code>.jpg
Elle n'est jamais redessinée : on la recadre (bords blancs retirés) et on l'imprime
en taille réelle, 68 × 136 mm, 6 par feuille A4 portrait avec des pointillés de coupe.

Produits sans étiquette (reconditionnés, modèles sortis avant juin 2025) : le site renvoie
une petite image de remplacement ; on le dit clairement, rien n'est inventé.

Quand la fiche EPREL du modèle est trouvée sans doute possible (voir eprel.py), c'est
l'étiquette officielle EPREL en PDF vectoriel qui est imprimée : même contenu, mais nette.
"""
from __future__ import annotations

import io
from dataclasses import dataclass
from pathlib import Path

from . import paths
from .electrodepot import BASE, ErreurRecherche

URL_ETIQUETTE = BASE + "/media/catalog/product/E{code}.jpg"
LARG_MM, HAUT_MM = 68.0, 136.0          # taille officielle de l'étiquette
TAILLE_MIN = 400                        # en dessous : image de remplacement, pas une étiquette
COLONNES, RANGS = 3, 2                  # 6 étiquettes par feuille A4 portrait
ESPACE_MM = 7.0                         # bande sous chaque rangée : code + nom du produit

# taille officielle de l'étiquette selon le rayon (mm) ; téléphones et tablettes : 68 × 136
FORMATS = {
    "tv": (96.0, 192.0), "moniteurs": (96.0, 192.0),                   # règlement UE 2019/2013
    "refrigerateurs": (96.0, 192.0), "congelateurs": (96.0, 192.0),    # 2019/2016
    "lave_linge": (96.0, 192.0), "seche_linge": (96.0, 192.0),         # 2019/2014, 2023/2534
    "lave_vaisselle": (96.0, 192.0),                                   # 2019/2017
    "fours": (85.0, 170.0), "cuisinieres": (85.0, 170.0),             # 65/2014 (étiquette du four)
    "hottes": (60.0, 120.0),                                           # 65/2014
    # tables de cuisson : pas d'étiquette énergie, sauf les tables aspirantes (étiquette de hotte)
    "plaques": (60.0, 120.0),
    "climatiseurs": (110.0, 220.0),                                    # 626/2011
    "ampoules": (36.0, 72.0),                                          # 2019/2015
}
ETIQUETTES_SEULES = set(FORMATS)        # rayons lus seulement pour les étiquettes énergie


def format_de(article: dict | None) -> tuple[float, float]:
    return FORMATS.get((article or {}).get("rayon") or "", (LARG_MM, HAUT_MM))


# Option « Autres rayons en 60 × 120 mm » : toutes les étiquettes plus grandes passent en 60 × 120
# (téléphones et tablettes gardent leur taille réelle, 68 × 136).
PETIT_MM = (60.0, 120.0)
ECRANS = {"tv", "moniteurs"}
POUCES_MIN_GRAND = 50       # règlement UE 2019/2013 : réduction permise seulement sous 127 cm (50")


def taille_imprimee(article: dict | None, petit: bool) -> tuple[float, float]:
    """Taille de l'étiquette sur la feuille, avec ou sans l'option « 60 × 120 »."""
    t = format_de(article)
    rayon = (article or {}).get("rayon") or ""
    if petit and rayon in FORMATS and t[0] > PETIT_MM[0]:
        return PETIT_MM
    return t


def pouces(nom: str) -> float | None:
    """Diagonale d'un écran d'après son nom : 55", 55'', 139 cm, ou le modèle (UE55…, ED55…, 55PUS…)."""
    import re
    m = re.search(r"(\d{2,3}(?:[.,]\d)?)\s?(?:\"|''|”|″|pouces?\b)", nom or "", re.I)
    if m:
        return float(m.group(1).replace(",", "."))
    m = re.search(r"\b(\d{2,3})\s?cm\b", nom or "", re.I)
    if m:
        return round(int(m.group(1)) / 2.54, 1)
    for jeton in re.findall(r"\b[A-Z0-9-]{4,}\b", nom or ""):
        m = re.match(r"^[A-Z]{0,4}-?(\d{2})[A-Z]", jeton)
        if m and 19 <= int(m.group(1)) <= 100:
            return float(m.group(1))
    return None


def grand_ecran(article: dict | None) -> tuple[bool, float | None]:
    """(étiquette à garder en 96 × 192 ?, pouces). Taille introuvable : on garde en grand par sécurité."""
    if (article or {}).get("rayon") not in ECRANS:
        return False, None
    p = pouces(article.get("nom", ""))
    return (p is None or p >= POUCES_MIN_GRAND), p


class SansEtiquette(Exception):
    """Le site ne publie pas d'étiquette énergie pour ce produit."""


@dataclass
class Etiquette:
    code: str
    nom: str
    fichier: Path
    taille: tuple = (LARG_MM, HAUT_MM)      # largeur, hauteur en mm

    @property
    def officielle(self) -> bool:
        """PDF officiel EPREL (net) plutôt que l'image du site."""
        return self.fichier.suffix.lower() == ".pdf"


def dossier() -> Path:
    d = paths.data_dir() / "photos" / "etiquettes"
    d.mkdir(parents=True, exist_ok=True)
    return d


def fichier_local(code: str) -> Path | None:
    f = dossier() / f"E{code}.png"
    return f if f.is_file() else None


def preparer(data: bytes, dest: Path) -> Path:
    """Contrôle que l'image est bien une étiquette, retire les bords blancs, enregistre en PNG."""
    from PIL import Image
    try:
        im = Image.open(io.BytesIO(data))
        im.load()
    except Exception as e:
        raise SansEtiquette("image illisible") from e
    if max(im.size) < TAILLE_MIN:
        raise SansEtiquette("pas d'étiquette énergie sur le site pour ce produit")
    im = im.convert("RGB")
    masque = im.convert("L").point(lambda v: 255 if v < 235 else 0)
    boite = masque.getbbox()
    if not boite:
        raise SansEtiquette("image vide")
    im = im.crop(boite)
    w, h = im.size
    if not 1.6 <= h / w <= 2.4:          # une étiquette fait environ 1 × 2
        raise SansEtiquette("l'image du site n'a pas la forme d'une étiquette énergie")
    dest.parent.mkdir(parents=True, exist_ok=True)
    im.save(dest)
    return dest


def telecharger(client, code: str) -> Path:
    """Télécharge l'étiquette du produit et la garde (sert ensuite sans Internet)."""
    try:
        r = client._get(URL_ETIQUETTE.format(code=code), accept="image/avif,image/webp,image/png,image/jpeg,*/*;q=0.5")
    except ErreurRecherche:
        raise
    if r.status_code == 404 or not r.content:
        raise SansEtiquette("pas d'étiquette énergie sur le site pour ce produit")
    if r.status_code != 200:
        raise ErreurRecherche(f"Étiquette énergie indisponible ({r.status_code}).")
    return preparer(r.content, dossier() / f"E{code}.png")


def fichier_eprel(numero: str) -> Path:
    return dossier() / f"EPREL_{numero}.pdf"


def _pdf_eprel(numero: str) -> Path:
    from . import eprel
    f = fichier_eprel(numero)
    return f if f.is_file() else eprel.telecharger_pdf(numero, f)


def obtenir_image_site(client, code: str, forcer: bool = False) -> Path:
    """Image de l'étiquette publiée par Electro Dépôt (gardée sur l'ordinateur)."""
    f = None if forcer else fichier_local(code)
    if f is not None:
        return f
    return telecharger(client, code)


def _reconditionne(article: dict) -> bool:
    attr = article.get("attributs") or {}
    return attr.get("flap_reconditionne") == "Oui" or "reconditionn" in (article.get("nom") or "").lower()


def obtenir(client, code: str, forcer: bool = False, article: dict | None = None) -> Path:
    """Étiquette à imprimer : le PDF officiel EPREL quand le modèle est sûr, sinon l'image du site.
    Pas d'étiquette sur le site : on cherche quand même sur EPREL (produits neufs).

    article : ligne du catalogue (nom, marque, classe énergétique) — sans elle, pas de recherche EPREL."""
    from . import eprel
    choix = eprel.choix(code)
    if choix and choix != "site":                       # numéro EPREL choisi dans « Modifier »
        try:
            return _pdf_eprel(choix)
        except (eprel.EprelInjoignable, LookupError, OSError):
            pass                                        # sans Internet : l'image du site en attendant
    image, absente = None, None
    try:
        image = obtenir_image_site(client, code, forcer)
    except SansEtiquette as e:
        absente = e
    if (choix == "site" or not article or (image is None and _reconditionne(article))
            or article.get("rayon") in ETIQUETTES_SEULES):     # EPREL : téléphones et tablettes seulement
        if image is None:
            raise absente
        return image

    def repli(raison: str) -> Path:
        if image is not None:
            return image
        raise SansEtiquette(f"ni sur le site, ni sur EPREL ({raison})" if raison else "ni sur le site, ni sur EPREL")

    info = eprel.memoire().get(code) or {}
    if info.get("numero") and not forcer:
        try:
            return _pdf_eprel(info["numero"])
        except (eprel.EprelInjoignable, LookupError, OSError):
            return repli("EPREL injoignable")
    if info.get("aucun") and not forcer and not eprel.a_retenter(info):
        return repli(_raison(info))
    try:
        fiches = eprel.candidats(article)
    except eprel.EprelInjoignable:
        return repli("EPREL injoignable")               # on réessaiera la prochaine fois
    except Exception as e:                              # jamais de plantage pour une étiquette
        eprel.noter(code, aucun=f"erreur : {e}")
        return repli("erreur")
    if len(fiches) != 1:
        eprel.noter(code, aucun="aucune fiche EPREL" if not fiches else f"{len(fiches)} fiches EPREL possibles",
                    possibles=[f.numero for f in fiches])
        return repli(_raison(eprel.memoire().get(code) or {}))
    try:
        f = _pdf_eprel(fiches[0].numero)
    except (eprel.EprelInjoignable, LookupError, OSError):
        return repli("EPREL injoignable")
    eprel.noter(code, numero=fiches[0].numero, modele=fiches[0].modele)
    return f


def _raison(info: dict) -> str:
    n = len(info.get("possibles") or [])
    return f"{n} modèles possibles : à choisir dans Modifier" if n > 1 else ""


def origine(code: str) -> str:
    """D'où vient l'étiquette déjà gardée : 'EPREL', 'site' ou ''."""
    from . import eprel
    info = eprel.memoire().get(code) or {}
    num = info.get("choix") if info.get("choix") not in (None, "", "site") else info.get("numero")
    if num and info.get("choix") != "site" and fichier_eprel(num).is_file():
        return "EPREL"
    return "site" if fichier_local(code) else ""


_cadres: dict[str, tuple] = {}


def _cadre_pdf(fichier: Path):
    """Zone utile de la page EPREL (marges blanches retirées), calculée une fois."""
    import pymupdf
    cle = str(fichier)
    if cle not in _cadres:
        with pymupdf.open(fichier) as src:
            page = src[0]
            pix = page.get_pixmap(dpi=150, colorspace=pymupdf.csGRAY)
            l, t, r, b = pix.width, pix.height, -1, -1
            data = pix.samples
            for y in range(pix.height):
                ligne = data[y * pix.stride:y * pix.stride + pix.width]
                xs = [x for x, v in enumerate(ligne) if v < 235]
                if xs:
                    l, r = min(l, xs[0]), max(r, xs[-1])
                    t, b = min(t, y), max(b, y)
            k = page.rect.width / pix.width
            if r < 0:
                _cadres[cle] = page.rect
            else:
                _cadres[cle] = pymupdf.Rect(max(0, (l - 0.25) * k), max(0, (t - 0.25) * k),
                                            min(page.rect.width, (r + 1.25) * k), min(page.rect.height, (b + 1.25) * k))
    return _cadres[cle]


MARGE_MM = 7.0             # mode « Avec marges » : rien à moins de 7 mm du bord (imprimantes qui coupent)


def disposition(larg: float, haut: float, marge: float = 0.0) -> tuple[float, float, int, int]:
    """Feuille A4 la mieux remplie (portrait ou paysage) : largeur, hauteur de page (mm), colonnes, rangs.
    68 × 136 : 6 en portrait ; 96 × 192 et 85 × 170 : 3 en paysage ; 60 × 120 : 6 en portrait."""
    choix = None
    for W, H in ((210.0, 297.0), (297.0, 210.0)):
        cols = int((W - 2 * marge) // larg)
        rangs = int((H - 2 * marge + 0.01) // (haut + ESPACE_MM))
        if cols and rangs and (choix is None or cols * rangs > choix[2] * choix[3]):
            choix = (W, H, cols, rangs)
    return choix or (210.0, 297.0, 1, 1)


def creer_pdf(etiquettes: list[Etiquette], dest: Path | None = None, marges: bool = False,
              texte: bool = True, pointilles: bool = True):
    """Feuilles A4 : étiquettes en taille réelle, collées en haut à gauche, pointillés de coupe,
    code et nom sous chaque étiquette. Une taille d'étiquette par feuille (téléphones, TV, fours…).
    Renvoie le document (et l'enregistre si dest)."""
    import pymupdf
    from .affiche import police
    mm = 72 / 25.4
    gris = (0.5, 0.5, 0.5)
    doc = pymupdf.open()
    groupes: dict[tuple, list] = {}
    for e in etiquettes:
        groupes.setdefault(tuple(e.taille), []).append(e)
    for (lmm, hmm), liste in groupes.items():
        marge_mm = MARGE_MM if marges else 0.0
        Wmm, Hmm, colonnes, rangs_max = disposition(lmm, hmm, marge_mm)
        W, H = Wmm * mm, Hmm * mm
        lw, lh, esp = lmm * mm, hmm * mm, ESPACE_MM * mm
        par_page = colonnes * rangs_max
        for debut in range(0, len(liste), par_page):
            lot = liste[debut:debut + par_page]
            pg = doc.new_page(width=W, height=H)
            rangs = -(-len(lot) // colonnes)
            cols = min(colonnes, len(lot))
            if marges:                                 # bloc centré, à 7 mm du haut au moins
                ox = (W - colonnes * lw) / 2
                oy = marge_mm * mm
            else:                                      # collées en haut à gauche : 3 coupes seulement
                ox = oy = 0.0
            for k, e in enumerate(lot):
                c, r = k % colonnes, k // colonnes
                x0, y0 = ox + c * lw, oy + r * (lh + esp)
                zone = pymupdf.Rect(x0, y0, x0 + lw, y0 + lh)
                if e.officielle:                       # PDF EPREL : vectoriel, inséré tel quel
                    with pymupdf.open(e.fichier) as src:
                        pg.show_pdf_page(zone, src, 0, clip=_cadre_pdf(e.fichier), keep_proportion=True)
                else:
                    pg.insert_image(zone, filename=str(e.fichier), keep_proportion=False)
                if marges and pointilles:              # le code et le nom restent dans la découpe
                    pg.draw_rect(pymupdf.Rect(x0, y0, x0 + lw, y0 + lh + (esp if texte else 0)),
                                 color=gris, width=0.6, dashes="[4 3] 0")
                if not texte:
                    continue
                legende = f"{e.code} · {e.nom}"
                taille = 6.3
                f = police()
                while f.text_length(legende, taille) > lw - 6 and taille > 4.2:
                    taille -= 0.2
                while f.text_length(legende, taille) > lw - 4 and len(legende) > 10:   # petites étiquettes
                    legende = legende[:-2].rstrip() + "…"
                    legende = legende.replace("……", "…")
                tw = pymupdf.TextWriter(pg.rect, color=(0.35, 0.37, 0.4))
                tw.append((x0 + (lw - f.text_length(legende, taille)) / 2, y0 + lh + 2 * mm + taille * 0.7),
                          legende, font=f, fontsize=taille)
                tw.write_text(pg)
            bas = oy + rangs * lh + (rangs - 1) * esp
            if pointilles and not marges:
                # avec le texte : la coupe passe sous le code et le nom (ils restent avec l'étiquette)
                bas_coupe = rangs * (lh + esp) if texte else bas
                for x in [c * lw for c in range(1, cols + 1)]:
                    pg.draw_line((x, 0), (x, bas_coupe), color=gris, width=0.6, dashes="[4 3] 0")
                for r in range(rangs):
                    ys = (r * (lh + esp) + lh + esp,) if texte else \
                        (r * (lh + esp) + lh,) + ((r * (lh + esp),) if r else ())
                    for y in ys:
                        pg.draw_line((0, y), (cols * lw, y), color=gris, width=0.6, dashes="[4 3] 0")
                bas = max(bas, bas_coupe)
            f = police()
            notes = (("Découper le long des pointillés. " if pointilles else "") + "Imprimer à 100 %"
                     + (", en paysage." if W > H else "."),
                     f"Taille réelle : {lmm:g} × {hmm:g} mm.")
            for i, ligne in enumerate(notes):
                t = 7.5
                tw = pymupdf.TextWriter(pg.rect, color=gris)
                tw.append(((W - f.text_length(ligne, t)) / 2, min(bas + 9 * mm, H - 7 * mm) + i * 11), ligne,
                          font=f, fontsize=t)
                tw.write_text(pg)
    if dest is not None:
        dest.parent.mkdir(parents=True, exist_ok=True)
        doc.save(dest)
    return doc
